;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 3.5.0 #9253 (Jun 20 2015) (MINGW64)
; This file was generated Thu Sep 12 23:57:20 2019
;--------------------------------------------------------
	.module diskio_select
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _deselect
	.globl _wait_ready
	.globl _rcvr_mmc
	.globl _select
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
_sgmPSGAddressWrite	=	0x0050
_sgmPSGDataWrite	=	0x0051
_sgmPSGDataRead	=	0x0052
_sgmConfig	=	0x0053
_phRAMBankSelect	=	0x0054
_phBankingScheme	=	0x0055
_phSDControl	=	0x0056
_phSDData	=	0x0057
_phMachineID	=	0x0058
_phCartMask	=	0x0059
_sgmBIOSMap	=	0x007f
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\diskio_select.c:27: int select (void)	/* 1:OK, 0:Timeout */
;	---------------------------------
; Function select
; ---------------------------------
_select::
	dec	sp
;fatFs\diskio_select.c:31: CS_L();				        /* Set CS# low */
	ld	a,(#_csLow + 0)
	out	(_phSDControl),a
;fatFs\diskio_select.c:32: rcvr_mmc(&d, 1);	        /* Dummy clock (force DO enabled) */
	ld	hl,#0x0000
	add	hl,sp
	ld	bc,#0x0001
	push	bc
	push	hl
	call	_rcvr_mmc
	pop	af
	pop	af
;fatFs\diskio_select.c:33: if (wait_ready()) return 1;	/* Wait for card ready */
	call	_wait_ready
	ld	a,h
	or	a,l
	jr	Z,00102$
	ld	hl,#0x0001
	jr	00103$
00102$:
;fatFs\diskio_select.c:35: deselect();
	call	_deselect
;fatFs\diskio_select.c:36: return 0;			        /* Failed */
	ld	hl,#0x0000
00103$:
	inc	sp
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
