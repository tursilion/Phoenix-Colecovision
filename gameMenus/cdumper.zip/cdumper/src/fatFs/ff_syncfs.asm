;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 3.5.0 #9253 (Jun 20 2015) (MINGW64)
; This file was generated Thu Sep 12 23:58:01 2019
;--------------------------------------------------------
	.module ff_syncfs
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _memset
	.globl _disk_write
	.globl _disk_ioctl
	.globl _st_dword
	.globl _st_word
	.globl _sync_window
	.globl _sync_fs
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\ff_syncfs.c:43: FRESULT sync_fs (	/* Returns FR_OK or FR_DISK_ERR */
;	---------------------------------
; Function sync_fs
; ---------------------------------
_sync_fs::
	call	___sdcc_enter_ix
	push	af
	push	af
	dec	sp
;fatFs\ff_syncfs.c:50: res = sync_window(fs);
	ld	l,4 (ix)
	ld	h,5 (ix)
	push	hl
	call	_sync_window
	pop	af
	ld	a,l
	ld	-5 (ix),a
;fatFs\ff_syncfs.c:51: if (res == FR_OK) {
	or	a, a
	jp	NZ,00107$
;fatFs\ff_syncfs.c:52: if (fs->fs_type == FS_FAT32 && fs->fsi_flag == 1) {	/* FAT32: Update FSInfo sector if needed */
	ld	c,4 (ix)
	ld	b,5 (ix)
	ld	a,(bc)
	sub	a, #0x03
	jp	NZ,00102$
	ld	hl,#0x0003
	add	hl,bc
	ld	-4 (ix),l
	ld	-3 (ix),h
	ld	l,-4 (ix)
	ld	h,-3 (ix)
	ld	a,(hl)
	dec	a
	jp	NZ,00102$
;fatFs\ff_syncfs.c:54: memset(fs->win, 0, sizeof fs->win);
	ld	hl,#0x002E
	add	hl,bc
	ld	-2 (ix),l
	ld	-1 (ix),h
	ld	l,-2 (ix)
	ld	h,-1 (ix)
	push	bc
	ld	de,#0x0200
	push	de
	ld	de,#0x0000
	push	de
	push	hl
	call	_memset
	pop	af
	pop	af
	pop	af
	pop	bc
;fatFs\ff_syncfs.c:55: st_word(fs->win + BS_55AA, 0xAA55);
	ld	hl,#0x022C
	add	hl,bc
	push	bc
	ld	de,#0xAA55
	push	de
	push	hl
	call	_st_word
	pop	af
	ld	hl, #0x4161
	ex	(sp),hl
	ld	hl,#0x5252
	push	hl
	ld	l,-2 (ix)
	ld	h,-1 (ix)
	push	hl
	call	_st_dword
	pop	af
	pop	af
	pop	af
	pop	bc
;fatFs\ff_syncfs.c:57: st_dword(fs->win + FSI_StrucSig, 0x61417272);
	ld	hl,#0x0212
	add	hl,bc
	ex	de,hl
	push	bc
	ld	hl,#0x6141
	push	hl
	ld	hl,#0x7272
	push	hl
	push	de
	call	_st_dword
	pop	af
	pop	af
	pop	af
	pop	bc
;fatFs\ff_syncfs.c:58: st_dword(fs->win + FSI_Free_Count, fs->free_clst);
	push	bc
	pop	iy
	ld	e,14 (iy)
	ld	d,15 (iy)
	ld	l,16 (iy)
	ld	h,17 (iy)
	ld	iy,#0x0216
	add	iy, bc
	push	bc
	push	hl
	push	de
	push	iy
	call	_st_dword
	pop	af
	pop	af
	pop	af
	pop	bc
;fatFs\ff_syncfs.c:59: st_dword(fs->win + FSI_Nxt_Free, fs->last_clst);
	push	bc
	pop	iy
	ld	e,10 (iy)
	ld	d,11 (iy)
	ld	l,12 (iy)
	ld	h,13 (iy)
	ld	iy,#0x021A
	add	iy, bc
	push	bc
	push	hl
	push	de
	push	iy
	call	_st_dword
	pop	af
	pop	af
	pop	af
	pop	bc
;fatFs\ff_syncfs.c:61: fs->winsect = fs->volbase + 1;
	ld	iy,#0x002A
	add	iy, bc
	ld	l, c
	ld	h, b
	ld	de, #0x001A
	add	hl, de
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	inc	hl
	inc	hl
	ld	a,(hl)
	dec	hl
	ld	l,(hl)
	ld	h,a
	inc	e
	jr	NZ,00130$
	inc	d
	jr	NZ,00130$
	inc	l
	jr	NZ,00130$
	inc	h
00130$:
	ld	0 (iy),e
	ld	1 (iy),d
	ld	2 (iy),l
	ld	3 (iy),h
;fatFs\ff_syncfs.c:63: disk_write(fs->win, fs->winsect, 1);
	ld	bc,#0x0001
	push	bc
	push	hl
	push	de
	ld	l,-2 (ix)
	ld	h,-1 (ix)
	push	hl
	call	_disk_write
	pop	af
	pop	af
	pop	af
	pop	af
;fatFs\ff_syncfs.c:67: fs->fsi_flag = 0;
	ld	l,-4 (ix)
	ld	h,-3 (ix)
	ld	(hl),#0x00
00102$:
;fatFs\ff_syncfs.c:71: if (disk_ioctl(CTRL_SYNC, 0) != RES_OK) res = FR_DISK_ERR;
	ld	hl,#0x0000
	push	hl
	xor	a, a
	push	af
	inc	sp
	call	_disk_ioctl
	pop	af
	inc	sp
	ld	a,l
	or	a, a
	jr	Z,00107$
	ld	-5 (ix),#0x01
00107$:
;fatFs\ff_syncfs.c:77: return res;
	ld	l,-5 (ix)
	ld	sp, ix
	pop	ix
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
