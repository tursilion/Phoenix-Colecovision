;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 3.5.0 #9253 (Jun 20 2015) (MINGW64)
; This file was generated Thu Sep 12 23:57:22 2019
;--------------------------------------------------------
	.module diskio_xmitmmc
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _xmit_mmc
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
_sgmPSGAddressWrite	=	0x0050
_sgmPSGDataWrite	=	0x0051
_sgmPSGDataRead	=	0x0052
_sgmConfig	=	0x0053
_phRAMBankSelect	=	0x0054
_phBankingScheme	=	0x0055
_phSDControl	=	0x0056
_phSDData	=	0x0057
_phMachineID	=	0x0058
_phCartMask	=	0x0059
_sgmBIOSMap	=	0x007f
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\diskio_xmitmmc.c:27: void xmit_mmc (
;	---------------------------------
; Function xmit_mmc
; ---------------------------------
_xmit_mmc::
;fatFs\diskio_xmitmmc.c:32: do {
	pop	bc
	pop	de
	push	de
	push	bc
	ld	hl, #4
	add	hl, sp
	ld	c, (hl)
	inc	hl
	ld	b, (hl)
00101$:
;fatFs\diskio_xmitmmc.c:33: phSDData = *buff++;	/* send a byte */
	ld	a,(de)
	out	(_phSDData),a
	inc	de
;fatFs\diskio_xmitmmc.c:34: } while (--bc);
	dec	bc
	ld	a,b
	or	a,c
	jr	NZ,00101$
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
