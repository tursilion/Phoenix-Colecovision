;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 3.5.0 #9253 (Jun 20 2015) (MINGW64)
; This file was generated Thu Sep 12 23:57:49 2019
;--------------------------------------------------------
	.module ff_getfileinfo
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _ld_dword
	.globl _get_fileinfo
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\ff_getfileinfo.c:44: void get_fileinfo (
;	---------------------------------
; Function get_fileinfo
; ---------------------------------
_get_fileinfo::
	call	___sdcc_enter_ix
	ld	hl,#-13
	add	hl,sp
	ld	sp,hl
;fatFs\ff_getfileinfo.c:64: fno->fname[0] = 0;			/* Invaidate file info */
	ld	c,6 (ix)
	ld	b,7 (ix)
	ld	hl,#0x0009
	add	hl,bc
	ld	(hl),#0x00
;fatFs\ff_getfileinfo.c:65: if (dp->sect == 0) return;	/* Exit if read pointer has reached end of directory */
	ld	e,4 (ix)
	ld	d,5 (ix)
	push	de
	pop	iy
	ld	a,22 (iy)
	ld	-10 (ix),a
	ld	a,23 (iy)
	ld	-9 (ix),a
	ld	a,24 (iy)
	ld	-8 (ix),a
	ld	a,25 (iy)
	ld	-7 (ix), a
	or	a, -8 (ix)
	or	a, -9 (ix)
	or	a,-10 (ix)
	jp	Z,00112$
;fatFs\ff_getfileinfo.c:164: si = di = 0;
	ld	iy,#0x0000
;fatFs\ff_getfileinfo.c:165: while (si < 11) {		/* Copy name body and extension */
	ld	hl,#0x001A
	add	hl,de
	ld	-10 (ix),l
	ld	-9 (ix),h
	ld	hl,#0x0009
	add	hl,bc
	ex	de,hl
	ld	hl,#0x0000
	ex	(sp), hl
00109$:
	ld	a,-13 (ix)
	sub	a, #0x0B
	ld	a,-12 (ix)
	sbc	a, #0x00
	jr	NC,00111$
;fatFs\ff_getfileinfo.c:166: c = (TCHAR)dp->dir[si++];
	ld	l,-10 (ix)
	ld	h,-9 (ix)
	ld	a,(hl)
	ld	-6 (ix),a
	inc	hl
	ld	a,(hl)
	ld	-5 (ix),a
	pop	hl
	push	hl
	inc	-13 (ix)
	jr	NZ,00139$
	inc	-12 (ix)
00139$:
	ld	a,-6 (ix)
	add	a, l
	ld	l,a
	ld	a,-5 (ix)
	adc	a, h
	ld	h,a
	ld	a,(hl)
;fatFs\ff_getfileinfo.c:167: if (c == ' ') continue;		/* Skip padding spaces */
	ld	-11 (ix), a
	sub	a, #0x20
	jr	Z,00109$
;fatFs\ff_getfileinfo.c:168: if (c == RDDEM) c = DDEM;	/* Restore replaced DDEM character */
	ld	a,-11 (ix)
	sub	a, #0x05
	jr	NZ,00106$
	ld	-11 (ix),#0xE5
00106$:
;fatFs\ff_getfileinfo.c:169: if (si == 9) fno->fname[di++] = '.';/* Insert a . if extension is exist */
	ld	a,-13 (ix)
	sub	a, #0x09
	jr	NZ,00108$
	ld	a,-12 (ix)
	or	a, a
	jr	NZ,00108$
	push	iy
	pop	hl
	inc	iy
	add	hl,de
	ld	(hl),#0x2E
00108$:
;fatFs\ff_getfileinfo.c:170: fno->fname[di++] = c;
	push	iy
	pop	hl
	inc	iy
	add	hl,de
	ld	a,-11 (ix)
	ld	(hl),a
	jr	00109$
00111$:
;fatFs\ff_getfileinfo.c:172: fno->fname[di] = 0;
	add	iy, de
	ld	0 (iy), #0x00
;fatFs\ff_getfileinfo.c:175: fno->fattrib = dp->dir[DIR_Attr];					/* Attribute */
	ld	iy,#0x0008
	add	iy, bc
	ld	l,-10 (ix)
	ld	h,-9 (ix)
	ld	a, (hl)
	inc	hl
	ld	h,(hl)
	ld	l,a
	ld	de, #0x000B
	add	hl, de
	ld	a,(hl)
	ld	0 (iy), a
;fatFs\ff_getfileinfo.c:176: fno->fsize = ld_dword(dp->dir + DIR_FileSize);		/* Size */
	ld	l,-10 (ix)
	ld	h,-9 (ix)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	hl,#0x001C
	add	hl,de
	push	bc
	push	hl
	call	_ld_dword
	pop	af
	ld	-1 (ix),d
	ld	-2 (ix),e
	ld	-3 (ix),h
	ld	-4 (ix),l
	pop	bc
	push	bc
	ld	e, c
	ld	d, b
	ld	hl, #0x000B
	add	hl, sp
	ld	bc, #0x0004
	ldir
	pop	bc
;fatFs\ff_getfileinfo.c:178: fno->ftime = ld_word(dp->dir + DIR_ModTime + 0);	/* Time */
	ld	hl,#0x0006
	add	hl,bc
	ld	-4 (ix),l
	ld	-3 (ix),h
	ld	l,-10 (ix)
	ld	h,-9 (ix)
	ld	a, (hl)
	inc	hl
	ld	h,(hl)
	ld	l,a
	push	hl
	pop	iy
	ld	de, #0x0017
	add	hl, de
	ld	d, (hl)
	ld	e,#0x00
	ld	l,22 (iy)
	ld	h,#0x00
	ld	a,e
	or	a, l
	ld	e,a
	ld	a,d
	or	a, h
	ld	d,a
	ld	l,-4 (ix)
	ld	h,-3 (ix)
	ld	(hl),e
	inc	hl
	ld	(hl),d
;fatFs\ff_getfileinfo.c:179: fno->fdate = ld_word(dp->dir + DIR_ModTime + 2);	/* Date */
	inc	bc
	inc	bc
	inc	bc
	inc	bc
	ld	l,-10 (ix)
	ld	h,-9 (ix)
	ld	a, (hl)
	inc	hl
	ld	h,(hl)
	ld	l,a
	push	hl
	pop	iy
	ld	de, #0x0019
	add	hl, de
	ld	d, (hl)
	ld	e,#0x00
	ld	l,24 (iy)
	ld	h,#0x00
	ld	a,e
	or	a, l
	ld	e,a
	ld	a,d
	or	a, h
	ld	d,a
	ld	a,e
	ld	(bc),a
	inc	bc
	ld	a,d
	ld	(bc),a
00112$:
	ld	sp, ix
	pop	ix
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
