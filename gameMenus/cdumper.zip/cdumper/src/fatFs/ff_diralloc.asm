;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 3.5.0 #9253 (Jun 20 2015) (MINGW64)
; This file was generated Thu Sep 12 23:57:27 2019
;--------------------------------------------------------
	.module ff_diralloc
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _dir_next
	.globl _dir_sdi
	.globl _move_window
	.globl _dir_alloc
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\ff_diralloc.c:43: FRESULT dir_alloc (	/* FR_OK(0):succeeded, !=0:error */
;	---------------------------------
; Function dir_alloc
; ---------------------------------
_dir_alloc::
	call	___sdcc_enter_ix
	ld	hl,#-11
	add	hl,sp
	ld	sp,hl
;fatFs\ff_diralloc.c:50: FATFS *fs = dp->obj.fs;
	ld	a,4 (ix)
	ld	-2 (ix),a
	ld	a,5 (ix)
	ld	-1 (ix),a
	ld	l,-2 (ix)
	ld	h,-1 (ix)
	ld	a,(hl)
	ld	-8 (ix),a
	inc	hl
	ld	a,(hl)
	ld	-7 (ix),a
;fatFs\ff_diralloc.c:53: res = dir_sdi(dp, 0);
	ld	hl,#0x0000
	push	hl
	ld	hl,#0x0000
	push	hl
	ld	l,-2 (ix)
	ld	h,-1 (ix)
	push	hl
	call	_dir_sdi
	pop	af
	pop	af
	pop	af
;fatFs\ff_diralloc.c:54: if (res == FR_OK) {
	ld	-9 (ix), l
	ld	a, l
	or	a, a
	jp	NZ,00113$
;fatFs\ff_diralloc.c:55: n = 0;
	ld	hl,#0x0000
	ex	(sp), hl
;fatFs\ff_diralloc.c:56: do {
	ld	a,-2 (ix)
	ld	-4 (ix),a
	ld	a,-1 (ix)
	ld	-3 (ix),a
	ld	a,-2 (ix)
	ld	-6 (ix),a
	ld	a,-1 (ix)
	ld	-5 (ix),a
00109$:
;fatFs\ff_diralloc.c:57: res = move_window(fs, dp->sect);
	ld	l,-6 (ix)
	ld	h,-5 (ix)
	ld	de, #0x0016
	add	hl, de
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	inc	hl
	ld	c,(hl)
	inc	hl
	ld	b,(hl)
	push	bc
	push	de
	ld	l,-8 (ix)
	ld	h,-7 (ix)
	push	hl
	call	_move_window
	pop	af
	pop	af
	pop	af
;fatFs\ff_diralloc.c:58: if (res != FR_OK) break;
	ld	-9 (ix), l
	ld	a, l
	or	a, a
	jr	NZ,00113$
;fatFs\ff_diralloc.c:62: if (dp->dir[DIR_Name] == DDEM || dp->dir[DIR_Name] == 0) {
	ld	l,-4 (ix)
	ld	h,-3 (ix)
	ld	de, #0x001A
	add	hl, de
	ld	a, (hl)
	inc	hl
	ld	h,(hl)
	ld	l,a
	ld	a, (hl)
	cp	a,#0xE5
	jr	Z,00105$
	or	a, a
	jr	NZ,00106$
00105$:
;fatFs\ff_diralloc.c:64: if (++n == nent) break;	/* A block of contiguous free entries is found */
	inc	-11 (ix)
	jr	NZ,00143$
	inc	-10 (ix)
00143$:
	ld	a,6 (ix)
	sub	a, -11 (ix)
	jr	NZ,00107$
	ld	a,7 (ix)
	sub	a, -10 (ix)
	jr	Z,00113$
	jr	00107$
	jr	00113$
00106$:
;fatFs\ff_diralloc.c:66: n = 0;					/* Not a blank entry. Restart to search */
	ld	hl,#0x0000
	ex	(sp), hl
00107$:
;fatFs\ff_diralloc.c:68: res = dir_next(dp, 1);
	ld	hl,#0x0001
	push	hl
	ld	l,-2 (ix)
	ld	h,-1 (ix)
	push	hl
	call	_dir_next
	pop	af
	pop	af
;fatFs\ff_diralloc.c:69: } while (res == FR_OK);	/* Next entry with table stretch enabled */
	ld	-9 (ix), l
	ld	a, l
	or	a, a
	jr	Z,00109$
00113$:
;fatFs\ff_diralloc.c:72: if (res == FR_NO_FILE) res = FR_DENIED;	/* No directory entry to allocate */
	ld	a,-9 (ix)
	sub	a, #0x04
	jr	NZ,00115$
	ld	-9 (ix),#0x07
00115$:
;fatFs\ff_diralloc.c:73: return res;
	ld	l,-9 (ix)
	ld	sp, ix
	pop	ix
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
