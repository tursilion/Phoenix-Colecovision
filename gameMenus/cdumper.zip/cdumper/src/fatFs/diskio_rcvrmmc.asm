;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 3.5.0 #9253 (Jun 20 2015) (MINGW64)
; This file was generated Thu Sep 12 23:57:20 2019
;--------------------------------------------------------
	.module diskio_rcvrmmc
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _rcvr_mmc_dummy
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
_sgmPSGAddressWrite	=	0x0050
_sgmPSGDataWrite	=	0x0051
_sgmPSGDataRead	=	0x0052
_sgmConfig	=	0x0053
_phRAMBankSelect	=	0x0054
_phBankingScheme	=	0x0055
_phSDControl	=	0x0056
_phSDData	=	0x0057
_phMachineID	=	0x0058
_phCartMask	=	0x0059
_sgmBIOSMap	=	0x007f
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\diskio_rcvrmmc.c:40: void rcvr_mmc_dummy() {
;	---------------------------------
; Function rcvr_mmc_dummy
; ---------------------------------
_rcvr_mmc_dummy::
;fatFs\diskio_rcvrmmc.c:97: __endasm;
; stack has ret, buff, bc
; for INIR we need port in C, dest in HL and count in B
	_rcvr_mmc::
; save regs
	push hl
	push bc
	push de
	push af
; point sp at buf
	ld hl,#10
	add hl,sp
	ld sp,hl ; sp pointing at buf
; get dest into hl
	pop hl ; sp pointing at cnt
; get count into de
	pop de ; sp above stack frame
; get port into c
	ld c,#_phSDData
; outer loop
	$0001:
	inc d ; zero test - http:
	dec d
	jr Z,$0002 ; if no
; since were > 256 but can only do 256 at a time, just run it that way
	xor a
	ld b,a
	inir ; runs 256
	dec d ; subtract 256
	jr $0001
; last pass
	$0002:
	inc e
	dec e
	jr Z,$0003 ; 0 bytes remaining
	ld b,e ; get remaining count
	inir
; restore the stack and return
	$0003:
	ld hl,#-14 ; pointing at af
	add hl,sp
	ld sp,hl
	pop af
	pop de
	pop bc
	pop hl
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
