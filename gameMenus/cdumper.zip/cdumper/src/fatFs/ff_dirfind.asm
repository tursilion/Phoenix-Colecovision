;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 3.5.0 #9253 (Jun 20 2015) (MINGW64)
; This file was generated Thu Sep 12 23:57:28 2019
;--------------------------------------------------------
	.module ff_dirfind
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _dir_next
	.globl _dir_sdi
	.globl _move_window
	.globl _mem_cmp
	.globl _dir_find
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\ff_dirfind.c:42: FRESULT dir_find (	/* FR_OK(0):succeeded, !=0:error */
;	---------------------------------
; Function dir_find
; ---------------------------------
_dir_find::
	call	___sdcc_enter_ix
	push	af
	push	af
	push	af
	dec	sp
;fatFs\ff_dirfind.c:47: FATFS *fs = dp->obj.fs;
	ld	c,4 (ix)
	ld	b,5 (ix)
	ld	a,(bc)
	ld	-6 (ix),a
	inc	bc
	ld	a,(bc)
	ld	-5 (ix),a
	dec	bc
;fatFs\ff_dirfind.c:53: res = dir_sdi(dp, 0);			/* Rewind directory object */
	push	bc
	ld	hl,#0x0000
	push	hl
	ld	hl,#0x0000
	push	hl
	push	bc
	call	_dir_sdi
	pop	af
	pop	af
	pop	af
	pop	bc
;fatFs\ff_dirfind.c:54: if (res != FR_OK) return res;
	ld	a,l
	or	a, a
;fatFs\ff_dirfind.c:79: do {
	jp	NZ,00113$
	ld	hl,#0x001C
	add	hl,bc
	ld	-4 (ix),l
	ld	-3 (ix),h
	ld	-2 (ix),c
	ld	-1 (ix),b
00110$:
;fatFs\ff_dirfind.c:80: res = move_window(fs, dp->sect);
	ld	l,-2 (ix)
	ld	h,-1 (ix)
	ld	de, #0x0016
	add	hl, de
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	inc	hl
	inc	hl
	ld	a,(hl)
	dec	hl
	ld	l,(hl)
	ld	h,a
	push	bc
	push	hl
	push	de
	ld	l,-6 (ix)
	ld	h,-5 (ix)
	push	hl
	call	_move_window
	pop	af
	pop	af
	pop	af
	pop	bc
;fatFs\ff_dirfind.c:81: if (res != FR_OK) break;
	ld	-7 (ix), l
	ld	a, l
	or	a, a
	jr	NZ,00112$
;fatFs\ff_dirfind.c:82: c = dp->dir[DIR_Name];
	ld	hl,#0x001A
	add	hl,bc
	ld	e,l
	ld	d,h
	ld	a, (hl)
	inc	hl
	ld	h,(hl)
	ld	l,a
	ld	a,(hl)
;fatFs\ff_dirfind.c:83: if (c == 0) { res = FR_NO_FILE; break; }	/* Reached to end of table */
	or	a, a
	jr	NZ,00106$
	ld	-7 (ix),#0x04
	jr	00112$
00106$:
;fatFs\ff_dirfind.c:106: dp->obj.attr = dp->dir[DIR_Attr] & AM_MASK;
	ld	iy,#0x0004
	add	iy, bc
	push	bc
	ld	bc, #0x000B
	add	hl, bc
	pop	bc
	ld	a,(hl)
	and	a, #0x3F
	ld	0 (iy), a
;fatFs\ff_dirfind.c:107: if (!(dp->dir[DIR_Attr] & AM_VOL) && !mem_cmp(dp->dir, dp->fn, 11)) break;	/* Is it a valid entry? */
	ex	de,hl
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	push	de
	pop	iy
	bit	3,11 (iy)
	jr	NZ,00108$
	ld	l,-4 (ix)
	ld	h,-3 (ix)
	push	de
	pop	iy
	push	bc
	ld	de,#0x000B
	push	de
	push	hl
	push	iy
	call	_mem_cmp
	pop	af
	pop	af
	pop	af
	pop	bc
	ld	a,h
	or	a,l
	jr	Z,00112$
00108$:
;fatFs\ff_dirfind.c:109: res = dir_next(dp, 0);	/* Next entry */
	push	bc
	ld	hl,#0x0000
	push	hl
	push	bc
	call	_dir_next
	pop	af
	pop	af
	pop	bc
;fatFs\ff_dirfind.c:110: } while (res == FR_OK);
	ld	-7 (ix), l
	ld	a, l
	or	a, a
	jp	Z,00110$
00112$:
;fatFs\ff_dirfind.c:112: return res;
	ld	l,-7 (ix)
00113$:
	ld	sp, ix
	pop	ix
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
