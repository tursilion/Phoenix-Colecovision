;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 3.5.0 #9253 (Jun 20 2015) (MINGW64)
; This file was generated Thu Sep 12 23:57:18 2019
;--------------------------------------------------------
	.module diskio_diskstatus
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _disk_status
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
_sgmPSGAddressWrite	=	0x0050
_sgmPSGDataWrite	=	0x0051
_sgmPSGDataRead	=	0x0052
_sgmConfig	=	0x0053
_phRAMBankSelect	=	0x0054
_phBankingScheme	=	0x0055
_phSDControl	=	0x0056
_phSDData	=	0x0057
_phMachineID	=	0x0058
_phCartMask	=	0x0059
_sgmBIOSMap	=	0x007f
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\diskio_diskstatus.c:27: DSTATUS disk_status (
;	---------------------------------
; Function disk_status
; ---------------------------------
_disk_status::
;fatFs\diskio_diskstatus.c:39: if (phSDControl & PH_SD_CARD_DETECT) {
	in	a,(_phSDControl)
	rlca
	jr	NC,00102$
;fatFs\diskio_diskstatus.c:41: return Stat;
	ld	iy,#_Stat
	ld	l,0 (iy)
	ret
00102$:
;fatFs\diskio_diskstatus.c:44: return STA_NODISK;
	ld	l,#0x02
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
