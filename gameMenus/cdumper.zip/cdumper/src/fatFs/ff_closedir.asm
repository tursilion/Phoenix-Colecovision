;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 3.5.0 #9253 (Jun 20 2015) (MINGW64)
; This file was generated Thu Sep 12 23:57:24 2019
;--------------------------------------------------------
	.module ff_closedir
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _validate
	.globl _f_closedir
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\ff_closedir.c:42: FRESULT f_closedir (
;	---------------------------------
; Function f_closedir
; ---------------------------------
_f_closedir::
	push	af
;fatFs\ff_closedir.c:50: res = validate(&dp->obj, &fs);	/* Check validity of the file object */
	ld	hl,#0x0000
	add	hl,sp
	ld	iy,#4
	add	iy,sp
	ld	e,0 (iy)
	ld	d,1 (iy)
	push	de
	push	hl
	push	de
	call	_validate
	pop	af
	pop	af
	ld	a,l
	pop	de
	ld	b,a
;fatFs\ff_closedir.c:51: if (res == FR_OK) {
;fatFs\ff_closedir.c:56: dp->obj.fs = 0;	/* Invalidate directory object */
	or	a,a
	jr	NZ,00102$
	ld	(de),a
	inc	de
	ld	a,#0x00
	ld	(de),a
00102$:
;fatFs\ff_closedir.c:62: return res;
	ld	l,b
	pop	af
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
