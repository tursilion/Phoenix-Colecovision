;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 3.5.0 #9253 (Jun 20 2015) (MINGW64)
; This file was generated Thu Sep 12 23:57:22 2019
;--------------------------------------------------------
	.module ff_chkchr
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _chk_chr
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\ff_chkchr.c:39: int chk_chr (const char* str, int chr)	/* NZ:contained, ZR:not contained */
;	---------------------------------
; Function chk_chr
; ---------------------------------
_chk_chr::
;fatFs\ff_chkchr.c:41: while (*str && *str != chr) str++;
	pop	bc
	pop	de
	push	de
	push	bc
00102$:
	ld	a,(de)
	ld	b,a
	push	af
	rla
	sbc	a, a
	ld	c,a
	pop	af
	or	a, a
	jr	Z,00104$
	ld	iy,#4
	add	iy,sp
	ld	a,0 (iy)
	sub	a, b
	jr	NZ,00120$
	ld	a,1 (iy)
	sub	a, c
	jr	Z,00104$
00120$:
	inc	de
	jr	00102$
00104$:
;fatFs\ff_chkchr.c:42: return *str;
	ld	l, b
	ld	h, c
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
