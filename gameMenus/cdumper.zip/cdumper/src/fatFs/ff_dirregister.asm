;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 3.5.0 #9253 (Jun 20 2015) (MINGW64)
; This file was generated Thu Sep 12 23:57:30 2019
;--------------------------------------------------------
	.module ff_dirregister
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _memcpy
	.globl _memset
	.globl _dir_alloc
	.globl _move_window
	.globl _dir_register
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\ff_dirregister.c:43: FRESULT dir_register (	/* FR_OK:succeeded, FR_DENIED:no free entry or too many SFN collision, FR_DISK_ERR:disk error */
;	---------------------------------
; Function dir_register
; ---------------------------------
_dir_register::
	call	___sdcc_enter_ix
	push	af
	push	af
	push	af
;fatFs\ff_dirregister.c:48: FATFS *fs = dp->obj.fs;
	ld	e,4 (ix)
	ld	d,5 (ix)
	ld	a,(de)
	ld	-6 (ix),a
	inc	de
	ld	a,(de)
	ld	-5 (ix),a
	dec	de
;fatFs\ff_dirregister.c:120: res = dir_alloc(dp, 1);		/* Allocate an entry for SFN */
	push	de
	ld	hl,#0x0001
	push	hl
	push	de
	call	_dir_alloc
	pop	af
	pop	af
	pop	de
	ld	c,l
;fatFs\ff_dirregister.c:125: if (res == FR_OK) {
	ld	a,c
	or	a, a
	jp	NZ,00104$
;fatFs\ff_dirregister.c:126: res = move_window(fs, dp->sect);
	push	de
	pop	iy
	ld	c,22 (iy)
	ld	b,23 (iy)
	ld	l,24 (iy)
	ld	h,25 (iy)
	push	de
	push	hl
	push	bc
	ld	l,-6 (ix)
	ld	h,-5 (ix)
	push	hl
	call	_move_window
	pop	af
	pop	af
	pop	af
	pop	de
	ld	c,l
;fatFs\ff_dirregister.c:127: if (res == FR_OK) {
	ld	a,c
	or	a, a
	jr	NZ,00104$
;fatFs\ff_dirregister.c:128: memset(dp->dir, 0, SZDIRE);	/* Clean the entry */
	ld	hl,#0x001A
	add	hl,de
	ld	-2 (ix),l
	ld	-1 (ix),h
	ld	l,-2 (ix)
	ld	h,-1 (ix)
	ld	a, (hl)
	inc	hl
	ld	h,(hl)
	ld	l,a
	push	hl
	pop	iy
	push	bc
	push	de
	ld	hl,#0x0020
	push	hl
	ld	l, #0x00
	push	hl
	push	iy
	call	_memset
	pop	af
	pop	af
	pop	af
	pop	de
	pop	bc
;fatFs\ff_dirregister.c:129: memcpy(dp->dir + DIR_Name, dp->fn, 11);	/* Put SFN */
	ld	hl,#0x001C
	add	hl,de
	ld	-4 (ix),l
	ld	-3 (ix),h
	ld	l,-2 (ix)
	ld	h,-1 (ix)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	push	bc
	ld	hl,#0x000B
	push	hl
	ld	l,-4 (ix)
	ld	h,-3 (ix)
	push	hl
	push	de
	call	_memcpy
	pop	af
	pop	af
	pop	af
	pop	bc
;fatFs\ff_dirregister.c:133: fs->wflag = 1;
	pop	hl
	push	hl
	inc	hl
	inc	hl
	ld	(hl),#0x01
00104$:
;fatFs\ff_dirregister.c:137: return res;
	ld	l,c
	ld	sp, ix
	pop	ix
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
