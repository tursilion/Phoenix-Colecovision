;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 3.5.0 #9253 (Jun 20 2015) (MINGW64)
; This file was generated Thu Sep 12 23:57:54 2019
;--------------------------------------------------------
	.module ff_movewindow
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _disk_read
	.globl _sync_window
	.globl _move_window
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
_VDPRD	=	0x00be
_VDPST	=	0x00bf
_VDPWA	=	0x00bf
_VDPWD	=	0x00be
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\ff_movewindow.c:39: FRESULT move_window (	/* Returns FR_OK or FR_DISK_ERR */
;	---------------------------------
; Function move_window
; ---------------------------------
_move_window::
	call	___sdcc_enter_ix
	push	af
	push	af
	dec	sp
;fatFs\ff_movewindow.c:44: FRESULT res = FR_OK;
	ld	-5 (ix),#0x00
;fatFs\ff_movewindow.c:46: if (sector != fs->winsect) {	/* Window offset changed? */
	ld	c,4 (ix)
	ld	b,5 (ix)
	ld	hl,#0x002A
	add	hl,bc
	ex	de,hl
	push	de
	push	bc
	ld	hl, #0x0005
	add	hl, sp
	ex	de, hl
	ld	bc, #0x0004
	ldir
	pop	bc
	pop	de
	ld	a,6 (ix)
	sub	a, -4 (ix)
	jr	NZ,00121$
	ld	a,7 (ix)
	sub	a, -3 (ix)
	jr	NZ,00121$
	ld	a,8 (ix)
	sub	a, -2 (ix)
	jr	NZ,00121$
	ld	a,9 (ix)
	sub	a, -1 (ix)
	jr	Z,00106$
00121$:
;fatFs\ff_movewindow.c:48: res = sync_window(fs);		/* Write-back changes */
	push	bc
	push	de
	push	bc
	call	_sync_window
	pop	af
	ld	a,l
	pop	de
	pop	bc
	ld	-5 (ix),a
;fatFs\ff_movewindow.c:50: if (res == FR_OK) {			/* Fill sector window with new data */
	or	a, a
	jr	NZ,00106$
;fatFs\ff_movewindow.c:54: if (disk_read(fs->win, sector, 1) != RES_OK) {
	ld	hl,#0x002E
	add	hl,bc
	ld	c,l
	ld	b,h
	push	de
	ld	hl,#0x0001
	push	hl
	ld	l,8 (ix)
	ld	h,9 (ix)
	push	hl
	ld	l,6 (ix)
	ld	h,7 (ix)
	push	hl
	push	bc
	call	_disk_read
	pop	af
	pop	af
	pop	af
	pop	af
	ld	a,l
	pop	de
	or	a, a
	jr	Z,00102$
;fatFs\ff_movewindow.c:56: sector = 0xFFFFFFFF;	/* Invalidate window if read data is not valid */
	ld	6 (ix),#0xFF
	ld	7 (ix),#0xFF
	ld	8 (ix),#0xFF
	ld	9 (ix),#0xFF
;fatFs\ff_movewindow.c:57: res = FR_DISK_ERR;
	ld	-5 (ix),#0x01
00102$:
;fatFs\ff_movewindow.c:59: fs->winsect = sector;
	ld	hl, #0x000B
	add	hl, sp
	ld	bc, #0x0004
	ldir
00106$:
;fatFs\ff_movewindow.c:62: return res;
	ld	l,-5 (ix)
	ld	sp, ix
	pop	ix
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
