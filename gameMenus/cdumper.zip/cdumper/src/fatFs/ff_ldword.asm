;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 3.5.0 #9253 (Jun 20 2015) (MINGW64)
; This file was generated Thu Sep 12 23:57:51 2019
;--------------------------------------------------------
	.module ff_ldword
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _ld_word_old
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\ff_ldword.c:42: WORD ld_word_old (const BYTE* ptr)	/*	 Load a 2-byte little-endian word */
;	---------------------------------
; Function ld_word_old
; ---------------------------------
_ld_word_old::
	call	___sdcc_enter_ix
;fatFs\ff_ldword.c:46: rv = ptr[1];
	ld	l,4 (ix)
	ld	h,5 (ix)
	inc	hl
;fatFs\ff_ldword.c:47: rv = rv << 8 | ptr[0];
	ld	d, (hl)
	ld	e,#0x00
	ld	l,4 (ix)
	ld	h,5 (ix)
	ld	l,(hl)
	ld	h,#0x00
	ld	a,l
	or	a, e
	ld	l,a
	ld	a,h
	or	a, d
	ld	h,a
;fatFs\ff_ldword.c:48: return rv;
	pop	ix
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
