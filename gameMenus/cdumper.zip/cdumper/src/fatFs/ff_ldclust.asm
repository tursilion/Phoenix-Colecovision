;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 3.5.0 #9253 (Jun 20 2015) (MINGW64)
; This file was generated Thu Sep 12 23:57:51 2019
;--------------------------------------------------------
	.module ff_ldclust
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _ld_clust
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\ff_ldclust.c:42: DWORD ld_clust (	/* Returns the top cluster value of the SFN entry */
;	---------------------------------
; Function ld_clust
; ---------------------------------
_ld_clust::
	call	___sdcc_enter_ix
	push	af
	push	af
;fatFs\ff_ldclust.c:49: cl = ld_word(dir + DIR_FstClusLO);
	ld	a,6 (ix)
	add	a, #0x1A
	ld	c,a
	ld	a,7 (ix)
	adc	a, #0x00
	ld	b,a
	ld	l, c
	ld	h, b
	inc	hl
	ld	d, (hl)
	ld	e,#0x00
	ld	a,(bc)
	ld	l,a
	ld	h,#0x00
	ld	a,l
	or	a, e
	ld	l,a
	ld	a,h
	or	a, d
	ld	h,a
	ld	-4 (ix),l
	ld	-3 (ix),h
	ld	a,h
	rla
	sbc	a, a
	ld	-2 (ix),a
	ld	-1 (ix),a
;fatFs\ff_ldclust.c:50: if (fs->fs_type == FS_FAT32) {
	ld	l,4 (ix)
	ld	h,5 (ix)
	ld	a,(hl)
	sub	a, #0x03
	jr	NZ,00102$
;fatFs\ff_ldclust.c:51: cl |= (DWORD)ld_word(dir + DIR_FstClusHI) << 16;
	ld	a,6 (ix)
	add	a, #0x14
	ld	c,a
	ld	a,7 (ix)
	adc	a, #0x00
	ld	b,a
	ld	l, c
	ld	h, b
	inc	hl
	ld	d, (hl)
	ld	e,#0x00
	ld	a,(bc)
	ld	l,a
	ld	h,#0x00
	ld	a,l
	or	a, e
	ld	l,a
	ld	a,h
	or	a, d
	ld	h,a
	rla
	sbc	a, a
	ld	e,a
	ld	d,a
	ld	b,#0x10
00111$:
	add	hl, hl
	rl	e
	rl	d
	djnz	00111$
	ld	a,-4 (ix)
	or	a, l
	ld	-4 (ix),a
	ld	a,-3 (ix)
	or	a, h
	ld	-3 (ix),a
	ld	a,-2 (ix)
	or	a, e
	ld	-2 (ix),a
	ld	a,-1 (ix)
	or	a, d
	ld	-1 (ix),a
00102$:
;fatFs\ff_ldclust.c:54: return cl;
	ld	l,-4 (ix)
	ld	h,-3 (ix)
	ld	e,-2 (ix)
	ld	d,-1 (ix)
	ld	sp, ix
	pop	ix
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
