;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 3.5.0 #9253 (Jun 20 2015) (MINGW64)
; This file was generated Thu Sep 12 23:57:27 2019
;--------------------------------------------------------
	.module ff_createname
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _memset
	.globl _chk_chr
	.globl _create_name
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\ff_createname.c:42: FRESULT create_name (	    /* FR_OK: successful, FR_INVALID_NAME: could not create */
;	---------------------------------
; Function create_name
; ---------------------------------
_create_name::
	call	___sdcc_enter_ix
	ld	hl,#-15
	add	hl,sp
	ld	sp,hl
;fatFs\ff_createname.c:186: p = *path; sfn = dp->fn;
	ld	a,6 (ix)
	ld	-2 (ix),a
	ld	a,7 (ix)
	ld	-1 (ix),a
	ld	l,-2 (ix)
	ld	h,-1 (ix)
	ld	a,(hl)
	ld	-15 (ix),a
	inc	hl
	ld	a,(hl)
	ld	-14 (ix),a
	ld	e,4 (ix)
	ld	d,5 (ix)
	ld	hl,#0x001C
	add	hl,de
	ld	-7 (ix),l
	ld	-6 (ix),h
;fatFs\ff_createname.c:187: memset(sfn, ' ', 11);
	ld	l,-7 (ix)
	ld	h,-6 (ix)
	ld	bc,#0x000B
	push	bc
	ld	bc,#0x0020
	push	bc
	push	hl
	call	_memset
	pop	af
	pop	af
	pop	af
;fatFs\ff_createname.c:188: si = i = 0; ni = 8;
	ld	-13 (ix),#0x00
	ld	-12 (ix),#0x00
	ld	-9 (ix),#0x08
	ld	-8 (ix),#0x00
	ld	-11 (ix),#0x00
	ld	-10 (ix),#0x00
00135$:
;fatFs\ff_createname.c:203: c = (BYTE)p[si++];				/* Get a byte */
	ld	l,-11 (ix)
	ld	h,-10 (ix)
	inc	-11 (ix)
	jr	NZ,00197$
	inc	-10 (ix)
00197$:
	ld	a,-11 (ix)
	ld	-5 (ix),a
	ld	a,-10 (ix)
	ld	-4 (ix),a
	pop	de
	push	de
	add	hl,de
	ld	e,(hl)
;fatFs\ff_createname.c:204: if (c <= ' ') break; 			/* Break if end of the path name */
	ld	a,#0x20
	sub	a, e
	ld	a,#0x00
	rla
	ld	-3 (ix), a
	or	a, a
	jp	Z,00130$
;fatFs\ff_createname.c:205: if (c == '/' || c == '\\') {	/* Break if a separator is found */
	ld	a,e
	cp	a,#0x2F
	jr	Z,00143$
	sub	a, #0x5C
	jr	NZ,00108$
;fatFs\ff_createname.c:206: while (p[si] == '/' || p[si] == '\\') si++;	/* Skip duplicated separator if exist */
00143$:
	ld	c,-5 (ix)
	ld	b,-4 (ix)
00104$:
	pop	hl
	push	hl
	add	hl,bc
	ld	a, (hl)
	cp	a,#0x2F
	jr	Z,00105$
	sub	a, #0x5C
	jp	NZ,00154$
00105$:
	inc	bc
	jr	00104$
;fatFs\ff_createname.c:207: break;
00108$:
;fatFs\ff_createname.c:209: if (c == '.' || i >= ni) {		/* End of body or field overflow? */
	ld	a,e
	sub	a, #0x2E
	jr	NZ,00204$
	ld	a,#0x01
	jr	00205$
00204$:
	xor	a,a
00205$:
	ld	h,a
	or	a, a
	jr	NZ,00113$
	ld	a,-13 (ix)
	sub	a, -9 (ix)
	ld	a,-12 (ix)
	sbc	a, -8 (ix)
	jr	C,00114$
00113$:
;fatFs\ff_createname.c:210: if (ni == 11 || c != '.') return FR_INVALID_NAME;	/* Field overflow or invalid dot? */
	ld	a,-9 (ix)
	sub	a, #0x0B
	jr	NZ,00206$
	ld	a,-8 (ix)
	or	a, a
	jr	Z,00110$
00206$:
	ld	a,h
	or	a, a
	jr	NZ,00111$
00110$:
	ld	l,#0x06
	jp	00136$
00111$:
;fatFs\ff_createname.c:211: i = 8; ni = 11;				/* Enter file extension field */
	ld	-13 (ix),#0x08
	ld	-12 (ix),#0x00
	ld	-9 (ix),#0x0B
	ld	-8 (ix),#0x00
;fatFs\ff_createname.c:212: continue;
	jp	00135$
00114$:
;fatFs\ff_createname.c:219: if (c >= 0x80) {				/* Is SBC extended character? */
	ld	a,e
	sub	a, #0x80
	jr	C,00127$
;fatFs\ff_createname.c:220: c = ExCvt[c & 0x7F];		/* To upper SBC extended character */
	res	7, e
	ld	hl,#_ExCvt
	ld	d,#0x00
	add	hl, de
	ld	e,(hl)
;fatFs\ff_createname.c:227: sfn[i++] = d;
00127$:
;fatFs\ff_createname.c:229: if (chk_chr("\"*+,:;<=>\?[]|\x7F", c)) return FR_INVALID_NAME;	/* Reject illegal chrs for SFN */
	ld	l,e
	ld	h,#0x00
	ld	bc,#___str_0
	push	de
	push	hl
	push	bc
	call	_chk_chr
	pop	af
	pop	af
	pop	de
	ld	a,h
	or	a,l
	jr	Z,00122$
	ld	l,#0x06
	jp	00136$
00122$:
;fatFs\ff_createname.c:231: if (IsLower(c)) c -= 0x20;	/* To upper */
	ld	a,e
	sub	a, #0x61
	jr	C,00124$
	ld	a,#0x7A
	sub	a, e
	jr	C,00124$
	ld	a,e
	add	a,#0xE0
	ld	e,a
00124$:
;fatFs\ff_createname.c:233: sfn[i++] = c;
	pop	bc
	pop	hl
	push	hl
	push	bc
	inc	-13 (ix)
	jr	NZ,00207$
	inc	-12 (ix)
00207$:
	ld	c,-7 (ix)
	ld	b,-6 (ix)
	add	hl,bc
	ld	(hl),e
	jp	00135$
00154$:
	ld	-5 (ix),c
	ld	-4 (ix),b
00130$:
;fatFs\ff_createname.c:236: *path = p + si;						/* Return pointer to the next segment */
	ld	a,-15 (ix)
	add	a, -5 (ix)
	ld	d,a
	ld	a,-14 (ix)
	adc	a, -4 (ix)
	ld	e,a
	ld	l,-2 (ix)
	ld	h,-1 (ix)
	ld	(hl),d
	inc	hl
	ld	(hl),e
;fatFs\ff_createname.c:237: if (i == 0) return FR_INVALID_NAME;	/* Reject nul string */
	ld	a,-12 (ix)
	or	a,-13 (ix)
	jr	NZ,00132$
	ld	l,#0x06
	jr	00136$
00132$:
;fatFs\ff_createname.c:239: if (sfn[0] == DDEM) sfn[0] = RDDEM;	/* If the first character collides with DDEM, replace it with RDDEM */
	ld	l,-7 (ix)
	ld	h,-6 (ix)
	ld	a,(hl)
	sub	a, #0xE5
	jr	NZ,00134$
	ld	l,-7 (ix)
	ld	h,-6 (ix)
	ld	(hl),#0x05
00134$:
;fatFs\ff_createname.c:240: sfn[NSFLAG] = (c <= ' ') ? NS_LAST : 0;		/* Set last segment flag if end of the path */
	ld	a,-7 (ix)
	add	a, #0x0B
	ld	-5 (ix),a
	ld	a,-6 (ix)
	adc	a, #0x00
	ld	-4 (ix),a
	ld	a,-3 (ix)
	or	a, a
	jr	NZ,00138$
	ld	-3 (ix),#0x04
	jr	00139$
00138$:
	ld	-3 (ix),#0x00
00139$:
	ld	l,-5 (ix)
	ld	h,-4 (ix)
	ld	a,-3 (ix)
	ld	(hl),a
;fatFs\ff_createname.c:242: return FR_OK;
	ld	l,#0x00
00136$:
	ld	sp, ix
	pop	ix
	ret
___str_0:
	.db 0x22
	.ascii "*+,:;<=>?[]|"
	.db 0x7F
	.db 0x00
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
