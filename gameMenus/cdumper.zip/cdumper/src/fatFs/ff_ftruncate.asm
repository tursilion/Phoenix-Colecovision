;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 3.5.0 #9253 (Jun 20 2015) (MINGW64)
; This file was generated Thu Sep 12 23:57:43 2019
;--------------------------------------------------------
	.module ff_ftruncate
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _disk_write
	.globl _remove_chain
	.globl _validate
	.globl _get_fat
	.globl _f_truncate
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\ff_ftruncate.c:43: FRESULT f_truncate (
;	---------------------------------
; Function f_truncate
; ---------------------------------
_f_truncate::
	call	___sdcc_enter_ix
	ld	hl,#-25
	add	hl,sp
	ld	sp,hl
;fatFs\ff_ftruncate.c:52: res = validate(&fp->obj, &fs);	/* Check validity of the file object */
	ld	hl,#0x0000
	add	hl,sp
	ld	a,4 (ix)
	ld	-2 (ix),a
	ld	a,5 (ix)
	ld	-1 (ix),a
	push	hl
	ld	l,-2 (ix)
	ld	h,-1 (ix)
	push	hl
	call	_validate
	pop	af
	pop	af
;fatFs\ff_ftruncate.c:53: if (res != FR_OK || (res = (FRESULT)fp->err) != FR_OK) LEAVE_FF(fs, res);
	ld	-19 (ix), l
	ld	a, l
	or	a, a
	jr	NZ,00101$
	ld	a,-2 (ix)
	add	a, #0x0F
	ld	-4 (ix),a
	ld	a,-1 (ix)
	adc	a, #0x00
	ld	-3 (ix),a
	ld	l,-4 (ix)
	ld	h,-3 (ix)
	ld	a,(hl)
	ld	-19 (ix),a
	or	a, a
	jr	Z,00102$
00101$:
	ld	l,-19 (ix)
	jp	00126$
00102$:
;fatFs\ff_ftruncate.c:54: if (!(fp->flag & FA_WRITE)) LEAVE_FF(fs, FR_DENIED);	/* Check access mode */
	ld	a,-2 (ix)
	add	a, #0x0E
	ld	-6 (ix),a
	ld	a,-1 (ix)
	adc	a, #0x00
	ld	-5 (ix),a
	ld	l,-6 (ix)
	ld	h,-5 (ix)
	bit	1,(hl)
	jr	NZ,00105$
	ld	l,#0x07
	jp	00126$
00105$:
;fatFs\ff_ftruncate.c:56: if (fp->fptr < fp->obj.objsize) {	/* Process when fptr is not on the eof */
	ld	a,-2 (ix)
	add	a, #0x10
	ld	-8 (ix),a
	ld	a,-1 (ix)
	adc	a, #0x00
	ld	-7 (ix),a
	ld	e,-8 (ix)
	ld	d,-7 (ix)
	ld	hl, #0x0007
	add	hl, sp
	ex	de, hl
	ld	bc, #0x0004
	ldir
	ld	a,-2 (ix)
	add	a, #0x0A
	ld	-10 (ix),a
	ld	a,-1 (ix)
	adc	a, #0x00
	ld	-9 (ix),a
	ld	e,-10 (ix)
	ld	d,-9 (ix)
	ld	hl, #0x000B
	add	hl, sp
	ex	de, hl
	ld	bc, #0x0004
	ldir
	ld	a,-18 (ix)
	sub	a, -14 (ix)
	ld	a,-17 (ix)
	sbc	a, -13 (ix)
	ld	a,-16 (ix)
	sbc	a, -12 (ix)
	ld	a,-15 (ix)
	sbc	a, -11 (ix)
	jp	NC,00125$
;fatFs\ff_ftruncate.c:57: if (fp->fptr == 0) {	/* When set file size to zero, remove entire cluster chain */
	ld	a,-15 (ix)
	or	a, -16 (ix)
	or	a, -17 (ix)
	or	a,-18 (ix)
	jr	NZ,00114$
;fatFs\ff_ftruncate.c:58: res = remove_chain(&fp->obj, fp->obj.sclust, 0);
	ld	a,-2 (ix)
	add	a, #0x06
	ld	-14 (ix),a
	ld	a,-1 (ix)
	adc	a, #0x00
	ld	-13 (ix),a
	ld	l,-14 (ix)
	ld	h,-13 (ix)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	inc	hl
	ld	c,(hl)
	inc	hl
	ld	b,(hl)
	ld	hl,#0x0000
	push	hl
	ld	hl,#0x0000
	push	hl
	push	bc
	push	de
	ld	l,-2 (ix)
	ld	h,-1 (ix)
	push	hl
	call	_remove_chain
	ld	iy,#10
	add	iy,sp
	ld	sp,iy
	ld	-19 (ix),l
;fatFs\ff_ftruncate.c:59: fp->obj.sclust = 0;
	ld	l,-14 (ix)
	ld	h,-13 (ix)
	xor	a, a
	ld	(hl), a
	inc	hl
	ld	(hl), a
	inc	hl
	xor	a, a
	ld	(hl), a
	inc	hl
	ld	(hl), a
	jp	00115$
00114$:
;fatFs\ff_ftruncate.c:61: ncl = get_fat(&fp->obj, fp->clust);
	ld	a,-2 (ix)
	add	a, #0x14
	ld	-14 (ix),a
	ld	a,-1 (ix)
	adc	a, #0x00
	ld	-13 (ix),a
	ld	l,-14 (ix)
	ld	h,-13 (ix)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	inc	hl
	ld	c,(hl)
	inc	hl
	ld	b,(hl)
	push	bc
	push	de
	ld	l,-2 (ix)
	ld	h,-1 (ix)
	push	hl
	call	_get_fat
	pop	af
	pop	af
	pop	af
	ld	-23 (ix),l
	ld	-22 (ix),h
	ld	-21 (ix),e
	ld	-20 (ix),d
;fatFs\ff_ftruncate.c:62: res = FR_OK;
	ld	-19 (ix),#0x00
;fatFs\ff_ftruncate.c:63: if (ncl == 0xFFFFFFFF) res = FR_DISK_ERR;
	ld	a,-23 (ix)
	inc	a
	jr	NZ,00107$
	ld	a,-22 (ix)
	inc	a
	jr	NZ,00107$
	ld	a,-21 (ix)
	inc	a
	jr	NZ,00107$
	ld	a,-20 (ix)
	inc	a
	jr	NZ,00107$
	ld	-19 (ix),#0x01
00107$:
;fatFs\ff_ftruncate.c:64: if (ncl == 1) res = FR_INT_ERR;
	ld	a,-23 (ix)
	dec	a
	jr	NZ,00109$
	ld	a,-22 (ix)
	or	a, a
	jr	NZ,00109$
	ld	a,-21 (ix)
	or	a, a
	jr	NZ,00109$
	ld	a,-20 (ix)
	or	a, a
	jr	NZ,00109$
	ld	-19 (ix),#0x02
00109$:
;fatFs\ff_ftruncate.c:65: if (res == FR_OK && ncl < fs->n_fatent) {
	ld	a,-19 (ix)
	or	a, a
	jr	NZ,00115$
	pop	hl
	push	hl
	ld	de, #0x0012
	add	hl, de
	ld	d,(hl)
	inc	hl
	ld	e,(hl)
	inc	hl
	ld	c,(hl)
	inc	hl
	ld	b,(hl)
	ld	a,-23 (ix)
	sub	a, d
	ld	a,-22 (ix)
	sbc	a, e
	ld	a,-21 (ix)
	sbc	a, c
	ld	a,-20 (ix)
	sbc	a, b
	jr	NC,00115$
;fatFs\ff_ftruncate.c:66: res = remove_chain(&fp->obj, ncl, fp->clust);
	ld	l,-14 (ix)
	ld	h,-13 (ix)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	inc	hl
	ld	c,(hl)
	inc	hl
	ld	b,(hl)
	push	bc
	push	de
	ld	l,-21 (ix)
	ld	h,-20 (ix)
	push	hl
	ld	l,-23 (ix)
	ld	h,-22 (ix)
	push	hl
	ld	l,-2 (ix)
	ld	h,-1 (ix)
	push	hl
	call	_remove_chain
	ld	iy,#10
	add	iy,sp
	ld	sp,iy
	ld	-19 (ix),l
00115$:
;fatFs\ff_ftruncate.c:69: fp->obj.objsize = fp->fptr;	/* Set file size to current read/write point */
	ld	l,-8 (ix)
	ld	h,-7 (ix)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	inc	hl
	ld	b,(hl)
	inc	hl
	ld	c,(hl)
	ld	l,-10 (ix)
	ld	h,-9 (ix)
	ld	(hl),e
	inc	hl
	ld	(hl),d
	inc	hl
	ld	(hl),b
	inc	hl
	ld	(hl),c
;fatFs\ff_ftruncate.c:70: fp->flag |= FA_MODIFIED;
	ld	l,-6 (ix)
	ld	h,-5 (ix)
	ld	a,(hl)
	set	6, a
	ld	l,-6 (ix)
	ld	h,-5 (ix)
	ld	(hl),a
;fatFs\ff_ftruncate.c:72: if (res == FR_OK && (fp->flag & FA_DIRTY)) {
	ld	a,-19 (ix)
	or	a, a
	jr	NZ,00120$
	ld	l,-6 (ix)
	ld	h,-5 (ix)
	ld	a,(hl)
	rlca
	jr	NC,00120$
;fatFs\ff_ftruncate.c:76: if (disk_write(fp->buf, fp->sect, 1) != RES_OK) {
	ld	l,-2 (ix)
	ld	h,-1 (ix)
	ld	de, #0x0018
	add	hl, de
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	inc	hl
	inc	hl
	ld	a,(hl)
	dec	hl
	ld	l,(hl)
	ld	h,a
	ld	iy,#0x0022
	ld	c,-2 (ix)
	ld	b,-1 (ix)
	add	iy, bc
	ld	bc,#0x0001
	push	bc
	push	hl
	push	de
	push	iy
	call	_disk_write
	pop	af
	pop	af
	pop	af
	pop	af
	ld	a,l
	or	a, a
	jr	Z,00117$
;fatFs\ff_ftruncate.c:78: res = FR_DISK_ERR;
	ld	-19 (ix),#0x01
	jr	00120$
00117$:
;fatFs\ff_ftruncate.c:80: fp->flag &= (BYTE)~FA_DIRTY;
	ld	l,-6 (ix)
	ld	h,-5 (ix)
	ld	a,(hl)
	and	a, #0x7F
	ld	l,-6 (ix)
	ld	h,-5 (ix)
	ld	(hl),a
00120$:
;fatFs\ff_ftruncate.c:84: if (res != FR_OK) ABORT(fs, res);
	ld	a,-19 (ix)
	or	a, a
	jr	Z,00125$
	ld	l,-4 (ix)
	ld	h,-3 (ix)
	ld	a,-19 (ix)
	ld	(hl),a
	ld	l,-19 (ix)
	jr	00126$
00125$:
;fatFs\ff_ftruncate.c:87: LEAVE_FF(fs, res);
	ld	l,-19 (ix)
00126$:
	ld	sp, ix
	pop	ix
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
