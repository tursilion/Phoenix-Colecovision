;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 3.5.0 #9253 (Jun 20 2015) (MINGW64)
; This file was generated Thu Sep 12 23:57:36 2019
;--------------------------------------------------------
	.module ff_fmkdir
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _memcpy
	.globl _memset
	.globl _st_dword
	.globl _dir_register
	.globl _st_clust
	.globl _dir_clear
	.globl _create_chain
	.globl _remove_chain
	.globl _sync_fs
	.globl _find_volume
	.globl _follow_path
	.globl _f_mkdir
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\ff_fmkdir.c:43: FRESULT f_mkdir (
;	---------------------------------
; Function f_mkdir
; ---------------------------------
_f_mkdir::
	call	___sdcc_enter_ix
	ld	hl,#-64
	add	hl,sp
	ld	sp,hl
;fatFs\ff_fmkdir.c:58: res = find_volume(&fs, FA_WRITE);	/* Get logical drive */
	ld	hl,#0x0000
	add	hl,sp
	ex	de,hl
	ld	a,#0x02
	push	af
	inc	sp
	push	de
	call	_find_volume
	pop	af
	inc	sp
	ld	e,l
;fatFs\ff_fmkdir.c:60: if (res == FR_OK) {
	ld	a,e
	or	a, a
	jp	NZ,00128$
;fatFs\ff_fmkdir.c:61: dj.obj.fs = fs;
	ld	hl,#0x0002
	add	hl,sp
	ld	a,-64 (ix)
	ld	(hl),a
	inc	hl
	ld	a,-63 (ix)
	ld	(hl),a
;fatFs\ff_fmkdir.c:63: res = follow_path(&dj, path);			/* Follow the file path */
	ld	hl,#0x0002
	add	hl,sp
	ld	-2 (ix),l
	ld	-1 (ix),h
	ld	l,-2 (ix)
	ld	h,-1 (ix)
	ld	c,4 (ix)
	ld	b,5 (ix)
	push	bc
	push	hl
	call	_follow_path
	pop	af
	pop	af
	ld	e,l
;fatFs\ff_fmkdir.c:64: if (res == FR_OK) res = FR_EXIST;		/* Name collision? */
	ld	a,e
	or	a, a
	jr	NZ,00104$
	ld	e,#0x08
;fatFs\ff_fmkdir.c:66: res = FR_INVALID_NAME;
00104$:
;fatFs\ff_fmkdir.c:68: if (res == FR_NO_FILE) {				/* It is clear to create a new directory */
	ld	a,e
	sub	a, #0x04
	jp	NZ,00128$
;fatFs\ff_fmkdir.c:69: sobj.fs = fs;						/* New object id to create a new chain */
	ld	hl,#0x002A
	add	hl,sp
	ld	a,-64 (ix)
	ld	(hl),a
	inc	hl
	ld	a,-63 (ix)
	ld	(hl),a
;fatFs\ff_fmkdir.c:70: dcl = create_chain(&sobj, 0);		/* Allocate a cluster for the new directory */
	ld	hl,#0x002A
	add	hl,sp
	ld	c,l
	ld	b,h
	ld	e, c
	ld	d, b
	push	bc
	ld	hl,#0x0000
	push	hl
	ld	hl,#0x0000
	push	hl
	push	de
	call	_create_chain
	pop	af
	pop	af
	pop	af
	pop	bc
	ld	-8 (ix),l
	ld	-7 (ix),h
	ld	-6 (ix),e
	ld	-5 (ix),d
;fatFs\ff_fmkdir.c:71: res = FR_OK;
	ld	e,#0x00
;fatFs\ff_fmkdir.c:72: if (dcl == 0) res = FR_DENIED;		/* No space to allocate a new cluster? */
	ld	a,-5 (ix)
	or	a, -6 (ix)
	or	a, -7 (ix)
	or	a,-8 (ix)
	jr	NZ,00108$
	ld	e,#0x07
00108$:
;fatFs\ff_fmkdir.c:73: if (dcl == 1) res = FR_INT_ERR;		/* Any insanity? */
	ld	a,-8 (ix)
	dec	a
	jr	NZ,00110$
	ld	a,-7 (ix)
	or	a, a
	jr	NZ,00110$
	ld	a,-6 (ix)
	or	a, a
	jr	NZ,00110$
	ld	a,-5 (ix)
	or	a, a
	jr	NZ,00110$
	ld	e,#0x02
00110$:
;fatFs\ff_fmkdir.c:74: if (dcl == 0xFFFFFFFF) res = FR_DISK_ERR;	/* Disk error? */
	ld	a,-8 (ix)
	inc	a
	jr	NZ,00112$
	ld	a,-7 (ix)
	inc	a
	jr	NZ,00112$
	ld	a,-6 (ix)
	inc	a
	jr	NZ,00112$
	ld	a,-5 (ix)
	inc	a
	jr	NZ,00112$
	ld	e,#0x01
00112$:
;fatFs\ff_fmkdir.c:76: if (res == FR_OK) {
	ld	a,e
	or	a, a
	jp	NZ,00119$
;fatFs\ff_fmkdir.c:77: res = dir_clear(fs, dcl);		/* Clean up the new table */
	push	bc
	ld	l,-6 (ix)
	ld	h,-5 (ix)
	push	hl
	ld	l,-8 (ix)
	ld	h,-7 (ix)
	push	hl
	ld	l,-64 (ix)
	ld	h,-63 (ix)
	push	hl
	call	_dir_clear
	pop	af
	pop	af
	pop	af
	pop	bc
	ld	e,l
;fatFs\ff_fmkdir.c:78: if (res == FR_OK) {
	ld	a,e
	or	a, a
	jp	NZ,00119$
;fatFs\ff_fmkdir.c:80: memset(fs->win + DIR_Name, ' ', 11);	/* Create "." entry */
	pop	hl
	push	hl
	ld	de,#0x002E
	add	hl,de
	push	bc
	ld	de,#0x000B
	push	de
	ld	de,#0x0020
	push	de
	push	hl
	call	_memset
	pop	af
	pop	af
	pop	af
	pop	bc
;fatFs\ff_fmkdir.c:81: fs->win[DIR_Name] = '.';
	pop	hl
	push	hl
	ld	de,#0x002E
	add	hl,de
	ld	(hl),#0x2E
;fatFs\ff_fmkdir.c:82: fs->win[DIR_Attr] = AM_DIR;
	pop	hl
	push	hl
	ld	de,#0x0039
	add	hl,de
	ld	(hl),#0x10
;fatFs\ff_fmkdir.c:83: st_dword(fs->win + DIR_ModTime, tm);
	pop	de
	push	de
	ld	hl,#0x0044
	add	hl,de
	ex	de,hl
	push	bc
	ld	hl,#0x4E21
	push	hl
	ld	hl,#0x0000
	push	hl
	push	de
	call	_st_dword
	pop	af
	pop	af
	pop	af
	pop	bc
;fatFs\ff_fmkdir.c:84: st_clust(fs, fs->win, dcl);
	pop	de
	push	de
	ld	iy,#0x002E
	add	iy, de
	push	bc
	ld	l,-6 (ix)
	ld	h,-5 (ix)
	push	hl
	ld	l,-8 (ix)
	ld	h,-7 (ix)
	push	hl
	push	iy
	push	de
	call	_st_clust
	pop	af
	pop	af
	pop	af
	pop	af
	pop	bc
;fatFs\ff_fmkdir.c:85: memcpy(fs->win + SZDIRE, fs->win, SZDIRE); /* Create ".." entry */
	pop	de
	push	de
	ld	hl,#0x002E
	add	hl,de
	ld	iy,#0x004E
	add	iy, de
	push	bc
	ld	de,#0x0020
	push	de
	push	hl
	push	iy
	call	_memcpy
	pop	af
	pop	af
	pop	af
	pop	bc
;fatFs\ff_fmkdir.c:86: fs->win[SZDIRE + 1] = '.'; pcl = dj.obj.sclust;
	pop	hl
	push	hl
	ld	de,#0x004F
	add	hl,de
	ld	(hl),#0x2E
	ld	l,-2 (ix)
	ld	h,-1 (ix)
	ld	de, #0x0006
	add	hl, de
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	inc	hl
	inc	hl
	ld	a,(hl)
	dec	hl
	ld	l,(hl)
	ld	h,a
;fatFs\ff_fmkdir.c:87: st_clust(fs, fs->win + SZDIRE, pcl);
	ld	a,-64 (ix)
	ld	-4 (ix),a
	ld	a,-63 (ix)
	ld	-3 (ix),a
	ld	iy,#0x004E
	push	bc
	ld	c,-4 (ix)
	ld	b,-3 (ix)
	add	iy, bc
	push	hl
	push	de
	push	iy
	ld	l,-4 (ix)
	ld	h,-3 (ix)
	push	hl
	call	_st_clust
	pop	af
	pop	af
	pop	af
	pop	af
	pop	bc
;fatFs\ff_fmkdir.c:88: fs->wflag = 1;
	pop	hl
	push	hl
	inc	hl
	inc	hl
	ld	(hl),#0x01
;fatFs\ff_fmkdir.c:90: res = dir_register(&dj);	/* Register the object to the parent directoy */
	ld	l,-2 (ix)
	ld	h,-1 (ix)
	push	bc
	push	hl
	call	_dir_register
	pop	af
	pop	bc
	ld	e,l
00119$:
;fatFs\ff_fmkdir.c:93: if (res == FR_OK) {
	ld	a,e
	or	a, a
	jr	NZ,00123$
;fatFs\ff_fmkdir.c:106: st_dword(dj.dir + DIR_ModTime, tm);	/* Created time */
	ld	a,-2 (ix)
	add	a, #0x1A
	ld	-4 (ix),a
	ld	a,-1 (ix)
	adc	a, #0x00
	ld	-3 (ix),a
	ld	l,-4 (ix)
	ld	h,-3 (ix)
	ld	c,(hl)
	inc	hl
	ld	b,(hl)
	ld	hl,#0x0016
	add	hl,bc
	ld	c,l
	ld	b,h
	push	de
	ld	hl,#0x4E21
	push	hl
	ld	hl,#0x0000
	push	hl
	push	bc
	call	_st_dword
	pop	af
	pop	af
	pop	af
	pop	de
;fatFs\ff_fmkdir.c:107: st_clust(fs, dj.dir, dcl);			/* Table start cluster */
	ld	l,-4 (ix)
	ld	h,-3 (ix)
	ld	c,(hl)
	inc	hl
	ld	b,(hl)
	push	de
	ld	l,-6 (ix)
	ld	h,-5 (ix)
	push	hl
	ld	l,-8 (ix)
	ld	h,-7 (ix)
	push	hl
	push	bc
	ld	l,-64 (ix)
	ld	h,-63 (ix)
	push	hl
	call	_st_clust
	pop	af
	pop	af
	pop	af
	pop	af
	pop	de
;fatFs\ff_fmkdir.c:108: dj.dir[DIR_Attr] = AM_DIR;			/* Attribute */
	ld	l,-4 (ix)
	ld	h,-3 (ix)
	ld	c,(hl)
	inc	hl
	ld	b,(hl)
	ld	hl,#0x000B
	add	hl,bc
	ld	(hl),#0x10
;fatFs\ff_fmkdir.c:109: fs->wflag = 1;
	pop	hl
	push	hl
	inc	hl
	inc	hl
	ld	(hl),#0x01
;fatFs\ff_fmkdir.c:111: if (res == FR_OK) {
	ld	a,e
	or	a, a
	jr	NZ,00128$
;fatFs\ff_fmkdir.c:112: res = sync_fs(fs);
	pop	hl
	push	hl
	push	hl
	call	_sync_fs
	pop	af
	ld	e,l
	jr	00128$
00123$:
;fatFs\ff_fmkdir.c:115: remove_chain(&sobj, dcl, 0);		/* Could not register, remove the allocated cluster */
	push	de
	ld	hl,#0x0000
	push	hl
	ld	hl,#0x0000
	push	hl
	ld	l,-6 (ix)
	ld	h,-5 (ix)
	push	hl
	ld	l,-8 (ix)
	ld	h,-7 (ix)
	push	hl
	push	bc
	call	_remove_chain
	ld	hl,#10
	add	hl,sp
	ld	sp,hl
	pop	de
00128$:
;fatFs\ff_fmkdir.c:121: LEAVE_FF(fs, res);
	ld	l,e
	ld	sp, ix
	pop	ix
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
