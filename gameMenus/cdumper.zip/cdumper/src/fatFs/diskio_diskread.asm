;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 3.5.0 #9253 (Jun 20 2015) (MINGW64)
; This file was generated Thu Sep 12 23:57:18 2019
;--------------------------------------------------------
	.module diskio_diskread
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _send_cmd
	.globl _rcvr_datablock
	.globl _deselect
	.globl _disk_status
	.globl _disk_read
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
_sgmPSGAddressWrite	=	0x0050
_sgmPSGDataWrite	=	0x0051
_sgmPSGDataRead	=	0x0052
_sgmConfig	=	0x0053
_phRAMBankSelect	=	0x0054
_phBankingScheme	=	0x0055
_phSDControl	=	0x0056
_phSDData	=	0x0057
_phMachineID	=	0x0058
_phCartMask	=	0x0059
_sgmBIOSMap	=	0x007f
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\diskio_diskread.c:27: DRESULT disk_read (
;	---------------------------------
; Function disk_read
; ---------------------------------
_disk_read::
	call	___sdcc_enter_ix
	push	af
	dec	sp
;fatFs\diskio_diskread.c:41: if (disk_status() & STA_NOINIT) return RES_NOTRDY;
	call	_disk_status
	ld	a,l
	rrca
	jr	NC,00102$
	ld	l,#0x03
	jp	00114$
00102$:
;fatFs\diskio_diskread.c:44: if (!(CardType & CT_BLOCK)) {
	ld	hl,#_CardType+0
	bit	3, (hl)
	jr	NZ,00104$
;fatFs\diskio_diskread.c:45: sector *= 512;	/* Convert LBA to byte address if needed */
	push	af
	pop	af
	ld	b,#0x09
00155$:
	sla	6 (ix)
	rl	7 (ix)
	rl	8 (ix)
	rl	9 (ix)
	djnz	00155$
00104$:
;fatFs\diskio_diskread.c:48: cmd = count > 1 ? CMD18 : CMD17;			/*  READ_MULTIPLE_BLOCK : READ_SINGLE_BLOCK */
	ld	a,#0x01
	cp	a, 10 (ix)
	ld	a,#0x00
	sbc	a, 11 (ix)
	jr	NC,00116$
	ld	a,#0x12
	jr	00117$
00116$:
	ld	a,#0x11
00117$:
	ld	-3 (ix),a
;fatFs\diskio_diskread.c:49: if (send_cmd(cmd, sector) == 0) {
	ld	l,8 (ix)
	ld	h,9 (ix)
	push	hl
	ld	l,6 (ix)
	ld	h,7 (ix)
	push	hl
	ld	a,-3 (ix)
	push	af
	inc	sp
	call	_send_cmd
	pop	af
	pop	af
	inc	sp
	ld	a,l
	or	a, a
	jr	NZ,00113$
;fatFs\diskio_diskread.c:50: do {
	ld	l,4 (ix)
	ld	h,5 (ix)
	ld	e,10 (ix)
	ld	d,11 (ix)
00107$:
;fatFs\diskio_diskread.c:51: if (!rcvr_datablock(buff, 512)) {
	push	hl
	push	de
	ld	bc,#0x0200
	push	bc
	push	hl
	call	_rcvr_datablock
	pop	af
	pop	af
	ld	-1 (ix),h
	ld	-2 (ix),l
	pop	de
	pop	hl
	ld	a,-1 (ix)
	or	a,-2 (ix)
	jr	Z,00127$
;fatFs\diskio_diskread.c:54: buff += 512;
	ld	bc,#0x0200
	add	hl,bc
;fatFs\diskio_diskread.c:55: } while (--count);
	dec	de
	ld	a,d
	or	a,e
	jr	NZ,00107$
00127$:
	ld	10 (ix),e
	ld	11 (ix),d
;fatFs\diskio_diskread.c:56: if (cmd == CMD18) send_cmd(CMD12, 0);	/* STOP_TRANSMISSION */
	ld	a,-3 (ix)
	sub	a, #0x12
	jr	NZ,00113$
	ld	hl,#0x0000
	push	hl
	ld	hl,#0x0000
	push	hl
	ld	a,#0x0C
	push	af
	inc	sp
	call	_send_cmd
	pop	af
	pop	af
	inc	sp
00113$:
;fatFs\diskio_diskread.c:58: deselect();
	call	_deselect
;fatFs\diskio_diskread.c:60: return count ? RES_ERROR : RES_OK;
	ld	a,11 (ix)
	or	a,10 (ix)
	jr	Z,00118$
	ld	l,#0x01
	jr	00119$
00118$:
	ld	l,#0x00
00119$:
00114$:
	ld	sp, ix
	pop	ix
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
