;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 3.5.0 #9253 (Jun 20 2015) (MINGW64)
; This file was generated Thu Sep 12 23:57:42 2019
;--------------------------------------------------------
	.module ff_frename
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _memcpy
	.globl _dir_remove
	.globl _dir_register
	.globl _st_clust
	.globl _sync_fs
	.globl _find_volume
	.globl _follow_path
	.globl _ld_clust
	.globl _clst2sect
	.globl _move_window
	.globl _f_rename
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\ff_frename.c:43: FRESULT f_rename (
;	---------------------------------
; Function f_rename
; ---------------------------------
_f_rename::
	call	___sdcc_enter_ix
	ld	hl,#-134
	add	hl,sp
	ld	sp,hl
;fatFs\ff_frename.c:60: res = find_volume(&fs, FA_WRITE);	/* Get logical drive of the old object */
	ld	hl,#0x0070
	add	hl,sp
	ex	de,hl
	ld	a,#0x02
	push	af
	inc	sp
	push	de
	call	_find_volume
	pop	af
	inc	sp
	ld	c,l
;fatFs\ff_frename.c:62: if (res == FR_OK) {
	ld	a,c
	or	a, a
	jp	NZ,00128$
;fatFs\ff_frename.c:63: djo.obj.fs = fs;
	ld	hl,#0x0048
	add	hl,sp
	ld	a,-22 (ix)
	ld	(hl),a
	inc	hl
	ld	a,-21 (ix)
	ld	(hl),a
;fatFs\ff_frename.c:65: res = follow_path(&djo, path_old);		/* Check old object */
	ld	hl,#0x0048
	add	hl,sp
	ld	-2 (ix),l
	ld	-1 (ix),h
	ld	l,-2 (ix)
	ld	h,-1 (ix)
	ld	c,4 (ix)
	ld	b,5 (ix)
	push	bc
	push	hl
	call	_follow_path
	pop	af
	pop	af
	ld	c,l
;fatFs\ff_frename.c:66: if (res == FR_OK && (djo.fn[NSFLAG] & (NS_DOT | NS_NONAME))) res = FR_INVALID_NAME;	/* Check validity of name */
	ld	a,c
	or	a, a
	jr	NZ,00102$
	ld	l,-2 (ix)
	ld	h,-1 (ix)
	ld	de, #0x0027
	add	hl, de
	ld	a,(hl)
	and	a, #0xA0
	jr	Z,00102$
	ld	c,#0x06
00102$:
;fatFs\ff_frename.c:72: if (res == FR_OK) {						/* Object to be renamed is found */
	ld	a,c
	or	a, a
	jp	NZ,00128$
;fatFs\ff_frename.c:100: memcpy(buf, djo.dir, SZDIRE);			/* Save directory entry of the object */
	ld	l,-2 (ix)
	ld	h,-1 (ix)
	ld	de, #0x001A
	add	hl, de
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	hl,#0x0000
	add	hl,sp
	ld	-20 (ix),l
	ld	-19 (ix),h
	ld	l,-20 (ix)
	ld	h,-19 (ix)
	ld	bc,#0x0020
	push	bc
	push	de
	push	hl
	call	_memcpy
	pop	af
	pop	af
	pop	af
;fatFs\ff_frename.c:101: memcpy(&djn, &djo, sizeof (DIR));		/* Duplicate the directory object */
	ld	c,-2 (ix)
	ld	b,-1 (ix)
	ld	hl,#0x0020
	add	hl,sp
	ex	de,hl
	push	de
	pop	iy
	push	de
	ld	hl,#0x0028
	push	hl
	push	bc
	push	iy
	call	_memcpy
	pop	af
	pop	af
	pop	af
	pop	de
;fatFs\ff_frename.c:102: res = follow_path(&djn, path_new);		/* Make sure if new object name is not in use */
	ld	l, e
	ld	h, d
	push	de
	ld	c,6 (ix)
	ld	b,7 (ix)
	push	bc
	push	hl
	call	_follow_path
	pop	af
	pop	af
	pop	de
	ld	c,l
;fatFs\ff_frename.c:104: res = (djn.obj.sclust == djo.obj.sclust && djn.dptr == djo.dptr) ? FR_NO_FILE : FR_EXIST;
	ld	hl,#0x0006
	add	hl,de
	ld	-12 (ix),l
	ld	-11 (ix),h
	ld	a,-2 (ix)
	add	a, #0x06
	ld	-18 (ix),a
	ld	a,-1 (ix)
	adc	a, #0x00
	ld	-17 (ix),a
;fatFs\ff_frename.c:103: if (res == FR_OK) {						/* Is new name already in use by any other object? */
	ld	a,c
	or	a, a
	jp	NZ,00105$
;fatFs\ff_frename.c:104: res = (djn.obj.sclust == djo.obj.sclust && djn.dptr == djo.dptr) ? FR_NO_FILE : FR_EXIST;
	push	de
	ld	e,-12 (ix)
	ld	d,-11 (ix)
	ld	hl, #0x0082
	add	hl, sp
	ex	de, hl
	ld	bc, #0x0004
	ldir
	ld	e,-18 (ix)
	ld	d,-17 (ix)
	ld	hl, #0x007E
	add	hl, sp
	ex	de, hl
	ld	bc, #0x0004
	ldir
	pop	de
	ld	a,-6 (ix)
	sub	a, -10 (ix)
	jp	NZ,00131$
	ld	a,-5 (ix)
	sub	a, -9 (ix)
	jr	NZ,00131$
	ld	a,-4 (ix)
	sub	a, -8 (ix)
	jr	NZ,00131$
	ld	a,-3 (ix)
	sub	a, -7 (ix)
	jr	NZ,00131$
	push	de
	pop	iy
	ld	a,14 (iy)
	ld	-10 (ix),a
	ld	a,15 (iy)
	ld	-9 (ix),a
	ld	a,16 (iy)
	ld	-8 (ix),a
	ld	a,17 (iy)
	ld	-7 (ix),a
	ld	c,-2 (ix)
	ld	b,-1 (ix)
	push	bc
	pop	iy
	ld	a,14 (iy)
	ld	-6 (ix),a
	ld	a,15 (iy)
	ld	-5 (ix),a
	ld	a,16 (iy)
	ld	-4 (ix),a
	ld	a,17 (iy)
	ld	-3 (ix),a
	ld	a,-10 (ix)
	sub	a, -6 (ix)
	jr	NZ,00131$
	ld	a,-9 (ix)
	sub	a, -5 (ix)
	jr	NZ,00131$
	ld	a,-8 (ix)
	sub	a, -4 (ix)
	jr	NZ,00131$
	ld	a,-7 (ix)
	sub	a, -3 (ix)
	jr	NZ,00131$
	ld	c,#0x04
	jr	00132$
00131$:
	ld	c,#0x08
00132$:
00105$:
;fatFs\ff_frename.c:106: if (res == FR_NO_FILE) { 				/* It is a valid path and no name collision */
	ld	a,c
	sub	a, #0x04
	jp	NZ,00120$
;fatFs\ff_frename.c:107: res = dir_register(&djn);			/* Register the new entry */
	ld	l, e
	ld	h, d
	push	de
	push	hl
	call	_dir_register
	pop	af
	pop	de
	ld	c,l
;fatFs\ff_frename.c:108: if (res == FR_OK) {
	ld	a,c
	or	a, a
	jp	NZ,00120$
;fatFs\ff_frename.c:109: dir = djn.dir;					/* Copy directory entry of the object except name */
	push	de
	pop	iy
	ld	a,26 (iy)
	ld	-10 (ix),a
	ld	a,27 (iy)
	ld	-9 (ix),a
;fatFs\ff_frename.c:110: memcpy(dir + 13, buf + 13, SZDIRE - 13);
	ld	a,-20 (ix)
	add	a, #0x0D
	ld	l,a
	ld	a,-19 (ix)
	adc	a, #0x00
	ld	h,a
	ld	iy,#0x000D
	ld	e,-10 (ix)
	ld	d,-9 (ix)
	add	iy, de
	push	bc
	ld	de,#0x0013
	push	de
	push	hl
	push	iy
	call	_memcpy
	pop	af
	pop	af
	pop	af
	pop	bc
;fatFs\ff_frename.c:111: dir[DIR_Attr] = buf[DIR_Attr];
	ld	a,-10 (ix)
	add	a, #0x0B
	ld	e,a
	ld	a,-9 (ix)
	adc	a, #0x00
	ld	d,a
	ld	l,-20 (ix)
	ld	h,-19 (ix)
	push	bc
	ld	bc, #0x000B
	add	hl, bc
	pop	bc
	ld	b,(hl)
	ld	a,b
	ld	(de),a
;fatFs\ff_frename.c:112: if (!(dir[DIR_Attr] & AM_DIR)) dir[DIR_Attr] |= AM_ARC;	/* Set archive attribute if it is a file */
	ld	a,(de)
	bit	4, b
	jr	NZ,00107$
	set	5, a
	ld	(de),a
00107$:
;fatFs\ff_frename.c:113: fs->wflag = 1;
	ld	l,-22 (ix)
	ld	h,-21 (ix)
	inc	hl
	inc	hl
	ld	(hl),#0x01
;fatFs\ff_frename.c:114: if ((dir[DIR_Attr] & AM_DIR) && djo.obj.sclust != djn.obj.sclust) {	/* Update .. entry in the sub-directory if needed */
	ld	a,(de)
	bit	4, a
	jp	Z,00120$
	push	bc
	ld	e,-18 (ix)
	ld	d,-17 (ix)
	ld	hl, #0x0082
	add	hl, sp
	ex	de, hl
	ld	bc, #0x0004
	ldir
	pop	bc
	push	bc
	ld	e,-12 (ix)
	ld	d,-11 (ix)
	ld	hl, #0x0078
	add	hl, sp
	ex	de, hl
	ld	bc, #0x0004
	ldir
	pop	bc
	ld	a,-6 (ix)
	sub	a, -16 (ix)
	jr	NZ,00213$
	ld	a,-5 (ix)
	sub	a, -15 (ix)
	jr	NZ,00213$
	ld	a,-4 (ix)
	sub	a, -14 (ix)
	jr	NZ,00213$
	ld	a,-3 (ix)
	sub	a, -13 (ix)
	jp	Z,00120$
00213$:
;fatFs\ff_frename.c:115: dw = clst2sect(fs, ld_clust(fs, dir));
	ld	l,-10 (ix)
	ld	h,-9 (ix)
	push	hl
	ld	l,-22 (ix)
	ld	h,-21 (ix)
	push	hl
	call	_ld_clust
	pop	af
	pop	af
	ex	de, hl
	push	hl
	push	de
	ld	l,-22 (ix)
	ld	h,-21 (ix)
	push	hl
	call	_clst2sect
	pop	af
	pop	af
	pop	af
	ld	-16 (ix),l
	ld	-15 (ix),h
	ld	-14 (ix),e
	ld	-13 (ix),d
;fatFs\ff_frename.c:116: if (dw == 0) {
	ld	a,d
	or	a, e
	or	a, h
	or	a,l
	jr	NZ,00112$
;fatFs\ff_frename.c:117: res = FR_INT_ERR;
	ld	c,#0x02
	jr	00120$
00112$:
;fatFs\ff_frename.c:120: res = move_window(fs, dw);
	ld	l,-14 (ix)
	ld	h,-13 (ix)
	push	hl
	ld	l,-16 (ix)
	ld	h,-15 (ix)
	push	hl
	ld	l,-22 (ix)
	ld	h,-21 (ix)
	push	hl
	call	_move_window
	pop	af
	pop	af
	pop	af
	ld	c,l
;fatFs\ff_frename.c:121: dir = fs->win + SZDIRE * 1;	/* Ptr to .. entry */
	ld	e,-22 (ix)
	ld	d,-21 (ix)
	ld	iy,#0x004E
	add	iy, de
;fatFs\ff_frename.c:122: if (res == FR_OK && dir[1] == '.') {
	ld	a,c
	or	a, a
	jr	NZ,00120$
	push	iy
	pop	hl
	inc	hl
	ld	a,(hl)
	sub	a, #0x2E
	jr	NZ,00120$
;fatFs\ff_frename.c:123: st_clust(fs, dir, djn.obj.sclust);
	push	de
	push	bc
	ld	e,-12 (ix)
	ld	d,-11 (ix)
	ld	hl, #0x007A
	add	hl, sp
	ex	de, hl
	ld	bc, #0x0004
	ldir
	pop	bc
	pop	de
	push	bc
	ld	l,-14 (ix)
	ld	h,-13 (ix)
	push	hl
	ld	l,-16 (ix)
	ld	h,-15 (ix)
	push	hl
	push	iy
	push	de
	call	_st_clust
	pop	af
	pop	af
	pop	af
	pop	af
	pop	bc
;fatFs\ff_frename.c:124: fs->wflag = 1;
	ld	l,-22 (ix)
	ld	h,-21 (ix)
	inc	hl
	inc	hl
	ld	(hl),#0x01
00120$:
;fatFs\ff_frename.c:131: if (res == FR_OK) {
	ld	a,c
	or	a, a
	jr	NZ,00128$
;fatFs\ff_frename.c:132: res = dir_remove(&djo);		/* Remove old entry */
	ld	l,-2 (ix)
	ld	h,-1 (ix)
	push	hl
	call	_dir_remove
	pop	af
	ld	c,l
;fatFs\ff_frename.c:133: if (res == FR_OK) {
	ld	a,c
	or	a, a
	jr	NZ,00128$
;fatFs\ff_frename.c:134: res = sync_fs(fs);
	ld	l,-22 (ix)
	ld	h,-21 (ix)
	push	hl
	call	_sync_fs
	pop	af
	ld	c,l
00128$:
;fatFs\ff_frename.c:142: LEAVE_FF(fs, res);
	ld	l,c
	ld	sp, ix
	pop	ix
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
