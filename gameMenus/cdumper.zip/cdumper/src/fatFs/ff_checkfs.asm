;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 3.5.0 #9253 (Jun 20 2015) (MINGW64)
; This file was generated Thu Sep 12 23:57:22 2019
;--------------------------------------------------------
	.module ff_checkfs
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _move_window
	.globl _mem_cmp
	.globl _check_fs
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\ff_checkfs.c:42: BYTE check_fs (	/* 0:FAT, 1:exFAT, 2:Valid BS but not FAT, 3:Not a BS, 4:Disk error */
;	---------------------------------
; Function check_fs
; ---------------------------------
_check_fs::
	call	___sdcc_enter_ix
	push	af
;fatFs\ff_checkfs.c:47: fs->wflag = 0; fs->winsect = 0xFFFFFFFF;		/* Invaidate window */
	ld	c,4 (ix)
	ld	b,5 (ix)
	ld	l, c
	ld	h, b
	inc	hl
	inc	hl
	ld	(hl),#0x00
	ld	hl,#0x002A
	add	hl,bc
	ld	(hl),#0xFF
	inc	hl
	ld	(hl),#0xFF
	inc	hl
	ld	(hl),#0xFF
	inc	hl
	ld	(hl),#0xFF
;fatFs\ff_checkfs.c:48: if (move_window(fs, sect) != FR_OK) {
	push	bc
	ld	l,8 (ix)
	ld	h,9 (ix)
	push	hl
	ld	l,6 (ix)
	ld	h,7 (ix)
	push	hl
	push	bc
	call	_move_window
	pop	af
	pop	af
	pop	af
	ld	e,l
	pop	bc
	ld	a,e
	or	a, a
	jr	Z,00102$
;fatFs\ff_checkfs.c:49: return 4;	/* Load boot record */
	ld	l,#0x04
	jp	00113$
00102$:
;fatFs\ff_checkfs.c:52: if (ld_word(fs->win + BS_55AA) != 0xAA55) {
	push	bc
	pop	iy
	ld	e, c
	ld	d, b
	ld	l, c
	ld	h, b
	push	bc
	ld	bc, #0x022D
	add	hl, bc
	pop	bc
	ld	l,(hl)
	ld	-1 (ix),l
	ld	-2 (ix),#0x00
	ex	de,hl
	ld	de, #0x022C
	add	hl, de
	ld	l,(hl)
	ld	h,#0x00
	ld	a,l
	or	a, -2 (ix)
	ld	l,a
	ld	a,h
	or	a, -1 (ix)
	ld	h,a
	ld	a,l
	sub	a, #0x55
	jr	NZ,00139$
	ld	a,h
	sub	a, #0xAA
	jr	Z,00104$
00139$:
;fatFs\ff_checkfs.c:53: return 3;	/* Check boot record signature (always here regardless of the sector size) */
	ld	l,#0x03
	jr	00113$
00104$:
;fatFs\ff_checkfs.c:59: if (fs->win[BS_JmpBoot] == 0xE9 || fs->win[BS_JmpBoot] == 0xEB || fs->win[BS_JmpBoot] == 0xE8) {	/* Valid JumpBoot code? */
	ld	a, 46 (iy)
	cp	a,#0xE9
	jr	Z,00109$
	cp	a,#0xEB
	jr	Z,00109$
	sub	a, #0xE8
	jr	NZ,00110$
00109$:
;fatFs\ff_checkfs.c:60: if (!mem_cmp(fs->win + BS_FilSysType, "FAT", 3)) {
	ld	hl,#0x0064
	add	hl,bc
	push	bc
	ld	de,#0x0003
	push	de
	ld	de,#___str_0
	push	de
	push	hl
	call	_mem_cmp
	pop	af
	pop	af
	pop	af
	pop	bc
	ld	a,h
;fatFs\ff_checkfs.c:61: return 0;		/* Is it an FAT VBR? */
	or	a,l
	jr	NZ,00106$
	ld	l,a
	jr	00113$
00106$:
;fatFs\ff_checkfs.c:63: if (!mem_cmp(fs->win + BS_FilSysType32, "FAT32", 5)) {
	ld	de,#___str_1+0
	ld	hl,#0x0080
	add	hl,bc
	ld	bc,#0x0005
	push	bc
	push	de
	push	hl
	call	_mem_cmp
	pop	af
	pop	af
	pop	af
	ld	a,h
;fatFs\ff_checkfs.c:64: return 0;	/* Is it an FAT32 VBR? */
	or	a,l
	jr	NZ,00110$
	ld	l,a
	jr	00113$
00110$:
;fatFs\ff_checkfs.c:67: return 2;	/* Valid BS but not FAT */
	ld	l,#0x02
00113$:
	pop	af
	pop	ix
	ret
___str_0:
	.ascii "FAT"
	.db 0x00
___str_1:
	.ascii "FAT32"
	.db 0x00
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
