;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 3.5.0 #9253 (Jun 20 2015) (MINGW64)
; This file was generated Thu Sep 12 23:57:19 2019
;--------------------------------------------------------
	.module diskio_rcvrdatablock
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _dly_50us
	.globl _rcvr_mmc
	.globl _rcvr_datablock
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
_sgmPSGAddressWrite	=	0x0050
_sgmPSGDataWrite	=	0x0051
_sgmPSGDataRead	=	0x0052
_sgmConfig	=	0x0053
_phRAMBankSelect	=	0x0054
_phBankingScheme	=	0x0055
_phSDControl	=	0x0056
_phSDData	=	0x0057
_phMachineID	=	0x0058
_phCartMask	=	0x0059
_sgmBIOSMap	=	0x007f
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\diskio_rcvrdatablock.c:27: int rcvr_datablock (	/* 1:OK, 0:Failed */
;	---------------------------------
; Function rcvr_datablock
; ---------------------------------
_rcvr_datablock::
	call	___sdcc_enter_ix
	push	af
;fatFs\diskio_rcvrdatablock.c:35: for (tmr = 1000; tmr; tmr--) {	/* Wait for data packet in timeout of 100ms */
	ld	de,#0x03E8
	ld	hl,#0x0000
	add	hl,sp
	ld	c,l
	ld	b,h
00106$:
;fatFs\diskio_rcvrdatablock.c:36: rcvr_mmc(d, 1);
	push	bc
	pop	iy
	push	bc
	push	de
	ld	hl,#0x0001
	push	hl
	push	iy
	call	_rcvr_mmc
	pop	af
	pop	af
	pop	de
	pop	bc
;fatFs\diskio_rcvrdatablock.c:37: if (d[0] != 0xFF) break;
	ld	a,(bc)
	inc	a
	jr	NZ,00103$
;fatFs\diskio_rcvrdatablock.c:38: dly_50us(2);
	push	bc
	push	de
	ld	a,#0x02
	push	af
	inc	sp
	call	_dly_50us
	inc	sp
	pop	de
	pop	bc
;fatFs\diskio_rcvrdatablock.c:35: for (tmr = 1000; tmr; tmr--) {	/* Wait for data packet in timeout of 100ms */
	ex	de,hl
	dec	hl
	ld	e, l
	ld	a,h
	ld	d,a
	or	a,l
	jr	NZ,00106$
00103$:
;fatFs\diskio_rcvrdatablock.c:40: if (d[0] != 0xFE) return 0;		/* If not valid data token, return with error */
	ld	a,(bc)
	sub	a, #0xFE
	jr	Z,00105$
	ld	hl,#0x0000
	jr	00108$
00105$:
;fatFs\diskio_rcvrdatablock.c:42: rcvr_mmc(buff, btr);			/* Receive the data block into buffer */
	push	bc
	ld	l,6 (ix)
	ld	h,7 (ix)
	push	hl
	ld	l,4 (ix)
	ld	h,5 (ix)
	push	hl
	call	_rcvr_mmc
	pop	af
	pop	af
	pop	bc
;fatFs\diskio_rcvrdatablock.c:43: rcvr_mmc(d, 2);					/* Discard CRC */
	ld	hl,#0x0002
	push	hl
	push	bc
	call	_rcvr_mmc
	pop	af
	pop	af
;fatFs\diskio_rcvrdatablock.c:45: return 1;						/* Return with success */
	ld	hl,#0x0001
00108$:
	pop	af
	pop	ix
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
