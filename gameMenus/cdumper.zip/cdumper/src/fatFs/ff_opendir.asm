;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 3.5.0 #9253 (Jun 20 2015) (MINGW64)
; This file was generated Thu Sep 12 23:57:54 2019
;--------------------------------------------------------
	.module ff_opendir
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _find_volume
	.globl _follow_path
	.globl _ld_clust
	.globl _dir_sdi
	.globl _f_opendir
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\ff_opendir.c:45: FRESULT f_opendir (
;	---------------------------------
; Function f_opendir
; ---------------------------------
_f_opendir::
	call	___sdcc_enter_ix
	push	af
	push	af
	push	af
	push	af
;fatFs\ff_opendir.c:54: if (!dp) return FR_INVALID_OBJECT;
	ld	a,5 (ix)
	or	a,4 (ix)
	jr	NZ,00102$
	ld	l,#0x09
	jp	00118$
00102$:
;fatFs\ff_opendir.c:60: res = find_volume(&fs, 0);
	ld	hl,#0x0000
	add	hl,sp
	ex	de,hl
	xor	a, a
	push	af
	inc	sp
	push	de
	call	_find_volume
	pop	af
	inc	sp
	ld	b,l
;fatFs\ff_opendir.c:63: dp->obj.fs = fs;
	ld	e,4 (ix)
	ld	d,5 (ix)
;fatFs\ff_opendir.c:62: if (res == FR_OK) {
	ld	a,b
	or	a, a
	jp	NZ,00115$
;fatFs\ff_opendir.c:63: dp->obj.fs = fs;
	ld	l, e
	ld	h, d
	ld	a,-8 (ix)
	ld	(hl),a
	inc	hl
	ld	a,-7 (ix)
	ld	(hl),a
;fatFs\ff_opendir.c:65: res = follow_path(dp, path);			/* Follow the path to the directory */
	push	de
	ld	l,6 (ix)
	ld	h,7 (ix)
	push	hl
	push	de
	call	_follow_path
	pop	af
	pop	af
	pop	de
	ld	b,l
;fatFs\ff_opendir.c:66: if (res == FR_OK) {						/* Follow completed */
	ld	a,b
	or	a, a
	jp	NZ,00111$
;fatFs\ff_opendir.c:67: if (!(dp->fn[NSFLAG] & NS_NONAME)) {	/* It is not the origin directory itself */
	push	de
	pop	iy
	ld	a,39 (iy)
	rlca
	jr	C,00107$
;fatFs\ff_opendir.c:68: if (dp->obj.attr & AM_DIR) {		/* This object is a sub-directory */
	push	de
	pop	iy
	bit	4,4 (iy)
	jr	Z,00104$
;fatFs\ff_opendir.c:78: dp->obj.sclust = ld_clust(fs, dp->dir);	/* Get object allocation info */
	ld	hl,#0x0006
	add	hl,de
	ld	-6 (ix),l
	ld	-5 (ix),h
	push	de
	pop	iy
	ld	l,26 (iy)
	ld	h,27 (iy)
	push	bc
	push	de
	push	hl
	ld	l,-8 (ix)
	ld	h,-7 (ix)
	push	hl
	call	_ld_clust
	pop	af
	pop	af
	ld	-1 (ix),d
	ld	-2 (ix),e
	ld	-3 (ix),h
	ld	-4 (ix),l
	pop	de
	pop	bc
	push	de
	push	bc
	ld	e,-6 (ix)
	ld	d,-5 (ix)
	ld	hl, #0x0008
	add	hl, sp
	ld	bc, #0x0004
	ldir
	pop	bc
	pop	de
	jr	00107$
00104$:
;fatFs\ff_opendir.c:81: res = FR_NO_PATH;
	ld	b,#0x05
00107$:
;fatFs\ff_opendir.c:84: if (res == FR_OK) {
	ld	a,b
	or	a, a
	jr	NZ,00111$
;fatFs\ff_opendir.c:85: dp->obj.id = fs->id;
	push	de
	pop	iy
	inc	iy
	inc	iy
	pop	hl
	push	hl
	ld	bc, #0x0004
	add	hl, bc
	ld	c,(hl)
	inc	hl
	ld	b,(hl)
	ld	0 (iy),c
	ld	1 (iy),b
;fatFs\ff_opendir.c:86: res = dir_sdi(dp, 0);			/* Rewind directory */
	push	de
	ld	hl,#0x0000
	push	hl
	ld	hl,#0x0000
	push	hl
	push	de
	call	_dir_sdi
	pop	af
	pop	af
	pop	af
	pop	de
	ld	b,l
00111$:
;fatFs\ff_opendir.c:100: if (res == FR_NO_FILE) res = FR_NO_PATH;
	ld	a,b
	sub	a, #0x04
	jr	NZ,00115$
	ld	b,#0x05
00115$:
;fatFs\ff_opendir.c:102: if (res != FR_OK) dp->obj.fs = 0;		/* Invalidate the directory object if function faild */
	ld	a,b
	or	a, a
	jr	Z,00117$
	ld	a,#0x00
	ld	(de),a
	inc	de
	ld	a,#0x00
	ld	(de),a
00117$:
;fatFs\ff_opendir.c:104: LEAVE_FF(fs, res);
	ld	l,b
00118$:
	ld	sp, ix
	pop	ix
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
