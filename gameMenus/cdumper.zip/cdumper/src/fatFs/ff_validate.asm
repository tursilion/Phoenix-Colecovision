;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 3.5.0 #9253 (Jun 20 2015) (MINGW64)
; This file was generated Thu Sep 12 23:58:02 2019
;--------------------------------------------------------
	.module ff_validate
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _disk_status
	.globl _validate
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\ff_validate.c:42: FRESULT validate (	/* Returns FR_OK or FR_INVALID_OBJECT */
;	---------------------------------
; Function validate
; ---------------------------------
_validate::
	call	___sdcc_enter_ix
	push	af
	dec	sp
;fatFs\ff_validate.c:47: FRESULT res = FR_INVALID_OBJECT;
	ld	-3 (ix),#0x09
;fatFs\ff_validate.c:50: if (obj && obj->fs && obj->fs->fs_type && obj->id == obj->fs->id) {	/* Test if the object is valid */
	ld	c,4 (ix)
	ld	b,5 (ix)
	ld	a,5 (ix)
	or	a,4 (ix)
	jr	Z,00104$
	ld	l, c
	ld	h, b
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,d
	or	a,e
	jr	Z,00104$
	ld	a,(de)
	or	a, a
	jr	Z,00104$
	push	bc
	pop	iy
	ld	a,2 (iy)
	ld	-2 (ix),a
	ld	a,3 (iy)
	ld	-1 (ix),a
	ex	de,hl
	ld	de, #0x0004
	add	hl, de
	ld	d,(hl)
	inc	hl
	ld	e,(hl)
	ld	a,-2 (ix)
	sub	a, d
	jr	NZ,00104$
	ld	a,-1 (ix)
	sub	a, e
	jr	NZ,00104$
;fatFs\ff_validate.c:69: if (!(disk_status() & STA_NOINIT)) { /* Test if the phsical drive is kept initialized */
	push	bc
	call	_disk_status
	ld	a,l
	pop	bc
	rrca
	jr	C,00104$
;fatFs\ff_validate.c:71: res = FR_OK;
	ld	-3 (ix),#0x00
00104$:
;fatFs\ff_validate.c:75: *rfs = (res == FR_OK) ? obj->fs : 0;	/* Corresponding filesystem object */
	ld	d,6 (ix)
	ld	e,7 (ix)
	ld	a,-3 (ix)
	or	a, a
	jr	NZ,00110$
	ld	l, c
	ld	h, b
	ld	c,(hl)
	inc	hl
	ld	b,(hl)
	jr	00111$
00110$:
	ld	bc,#0x0000
00111$:
	ld	l, d
	ld	h, e
	ld	(hl),c
	inc	hl
	ld	(hl),b
;fatFs\ff_validate.c:76: return res;
	ld	l,-3 (ix)
	ld	sp, ix
	pop	ix
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
