;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 3.5.0 #9253 (Jun 20 2015) (MINGW64)
; This file was generated Thu Sep 12 23:57:17 2019
;--------------------------------------------------------
	.module diskio_diskioctl
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _send_cmd
	.globl _rcvr_datablock
	.globl _select
	.globl _deselect
	.globl _disk_status
	.globl _disk_ioctl
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
_sgmPSGAddressWrite	=	0x0050
_sgmPSGDataWrite	=	0x0051
_sgmPSGDataRead	=	0x0052
_sgmConfig	=	0x0053
_phRAMBankSelect	=	0x0054
_phBankingScheme	=	0x0055
_phSDControl	=	0x0056
_phSDData	=	0x0057
_phMachineID	=	0x0058
_phCartMask	=	0x0059
_sgmBIOSMap	=	0x007f
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\diskio_diskioctl.c:34: DRESULT disk_ioctl (
;	---------------------------------
; Function disk_ioctl
; ---------------------------------
_disk_ioctl::
	call	___sdcc_enter_ix
	ld	hl,#-26
	add	hl,sp
	ld	sp,hl
;fatFs\diskio_diskioctl.c:48: if (disk_status() & STA_NOINIT) return RES_NOTRDY;	/* Check if card is in the socket */
	call	_disk_status
	ld	a,l
	rrca
	jr	NC,00102$
	ld	l,#0x03
	jp	00116$
00102$:
;fatFs\diskio_diskioctl.c:51: res = RES_ERROR;
	ld	-9 (ix),#0x01
;fatFs\diskio_diskioctl.c:52: switch (ctrl) {
	ld	a,4 (ix)
	or	a, a
	jr	Z,00103$
;fatFs\diskio_diskioctl.c:61: *(DWORD*)buff = cs << 10;
	ld	a,5 (ix)
	ld	-2 (ix),a
	ld	a,6 (ix)
	ld	-1 (ix),a
;fatFs\diskio_diskioctl.c:52: switch (ctrl) {
	ld	a,4 (ix)
	dec	a
	jr	Z,00106$
	ld	a,4 (ix)
	sub	a, #0x03
	jp	Z,00113$
	jp	00114$
;fatFs\diskio_diskioctl.c:53: case CTRL_SYNC :		/* Make sure that no pending write process */
00103$:
;fatFs\diskio_diskioctl.c:54: if (select()) res = RES_OK;
	call	_select
	ld	a,h
	or	a,l
	jp	Z,00115$
	ld	-9 (ix),#0x00
;fatFs\diskio_diskioctl.c:55: break;
	jp	00115$
;fatFs\diskio_diskioctl.c:57: case GET_SECTOR_COUNT :	/* Get number of sectors on the disk (DWORD) */
00106$:
;fatFs\diskio_diskioctl.c:58: if ((send_cmd(CMD9, 0) == 0) && rcvr_datablock(csd, 16)) {
	ld	hl,#0x0000
	push	hl
	ld	hl,#0x0000
	push	hl
	ld	a,#0x09
	push	af
	inc	sp
	call	_send_cmd
	pop	af
	pop	af
	inc	sp
	ld	a,l
	or	a, a
	jp	NZ,00115$
	ld	hl,#0x0001
	add	hl,sp
	push	hl
	ld	de,#0x0010
	push	de
	push	hl
	call	_rcvr_datablock
	pop	af
	pop	af
	pop	bc
	ld	a,h
	or	a,l
	jp	Z,00115$
;fatFs\diskio_diskioctl.c:59: if ((csd[0] >> 6) == 1) {	/* SDC ver 2.00 */
	ld	a,(bc)
	rlca
	rlca
	and	a,#0x03
	ld	-8 (ix),a
;fatFs\diskio_diskioctl.c:60: cs = csd[9] + ((WORD)csd[8] << 8) + ((DWORD)(csd[7] & 63) << 16) + 1;
	ld	l, c
	ld	h, b
	ld	e, c
	ld	d, b
	push	bc
	pop	iy
	push	bc
	ld	bc, #0x0009
	add	hl, bc
	pop	bc
	ld	a,(hl)
	ld	-7 (ix),a
	ex	de,hl
	ld	de, #0x0008
	add	hl, de
	ld	e,(hl)
	ld	d,7 (iy)
;fatFs\diskio_diskioctl.c:59: if ((csd[0] >> 6) == 1) {	/* SDC ver 2.00 */
	ld	a,-8 (ix)
	dec	a
	jr	NZ,00108$
;fatFs\diskio_diskioctl.c:60: cs = csd[9] + ((WORD)csd[8] << 8) + ((DWORD)(csd[7] & 63) << 16) + 1;
	ld	c,-7 (ix)
	ld	b,#0x00
	ld	h,e
	ld	l,#0x00
	add	hl,bc
	ld	c,l
	ld	b,h
	ld	a,d
	and	a, #0x3F
	ld	e,a
	ld	d,#0x00
	ld	hl,#0x0000
	ld	a,#0x10
00156$:
	sla	e
	rl	d
	adc	hl, hl
	dec	a
	jr	NZ,00156$
	ld	-6 (ix),c
	ld	-5 (ix),b
	ld	-4 (ix),#0x00
	ld	-3 (ix),#0x00
	ld	a,-6 (ix)
	add	a, e
	ld	e,a
	ld	a,-5 (ix)
	adc	a, d
	ld	d,a
	ld	a,-4 (ix)
	adc	a, l
	ld	c,a
	ld	a,-3 (ix)
	adc	a, h
	ld	b,a
	inc	e
	jr	NZ,00158$
	inc	d
	jr	NZ,00158$
	inc	c
	jr	NZ,00158$
	inc	b
00158$:
;fatFs\diskio_diskioctl.c:61: *(DWORD*)buff = cs << 10;
	ld	a,#0x0A
00159$:
	sla	e
	rl	d
	rl	c
	rl	b
	dec	a
	jr	NZ,00159$
	ld	l,-2 (ix)
	ld	h,-1 (ix)
	ld	(hl),e
	inc	hl
	ld	(hl),d
	inc	hl
	ld	(hl),c
	inc	hl
	ld	(hl),b
	jr	00109$
00108$:
;fatFs\diskio_diskioctl.c:63: n = (csd[5] & 15) + ((csd[10] & 128) >> 7) + ((csd[9] & 3) << 1) + 2;
	push	bc
	pop	iy
	ld	a,5 (iy)
	and	a, #0x0F
	ld	-6 (ix),a
	push	bc
	pop	iy
	ld	a,10 (iy)
	and	a, #0x80
	rlca
	and	a,#0x01
	ld	h,a
	ld	a,-6 (ix)
	add	a, h
	ld	h,a
	ld	a,-7 (ix)
	and	a, #0x03
	add	a, a
	add	a,h
	add	a, #0x02
	ld	-26 (ix),a
;fatFs\diskio_diskioctl.c:64: cs = (csd[8] >> 6) + ((WORD)csd[7] << 2) + ((WORD)(csd[6] & 3) << 10) + 1;
	ld	a,e
	rlca
	rlca
	and	a,#0x03
	ld	l,a
	ld	h,#0x00
	ld	e,d
	ld	d,#0x00
	sla	e
	rl	d
	sla	e
	rl	d
	add	hl,de
	ex	de,hl
	push	bc
	pop	iy
	ld	a,6 (iy)
	and	a, #0x03
	add	a, a
	add	a, a
	ld	h,a
	ld	l,#0x00
	add	hl,de
	inc	hl
	ex	de,hl
	ld	bc,#0x0000
;fatFs\diskio_diskioctl.c:65: *(DWORD*)buff = cs << (n - 9);
	ld	a, -26 (ix)
	ld	h, #0x00
	add	a,#0xF7
	ld	l,a
	ld	a,h
	adc	a,#0xFF
	inc	l
	jr	00164$
00163$:
	sla	e
	rl	d
	rl	c
	rl	b
00164$:
	dec	l
	jr	NZ,00163$
	ld	l,-2 (ix)
	ld	h,-1 (ix)
	ld	(hl),e
	inc	hl
	ld	(hl),d
	inc	hl
	ld	(hl),c
	inc	hl
	ld	(hl),b
00109$:
;fatFs\diskio_diskioctl.c:67: res = RES_OK;
	ld	-9 (ix),#0x00
;fatFs\diskio_diskioctl.c:69: break;
	jr	00115$
;fatFs\diskio_diskioctl.c:71: case GET_BLOCK_SIZE :	/* Get erase block size in unit of sector (DWORD) */
00113$:
;fatFs\diskio_diskioctl.c:72: *(DWORD*)buff = 128;
	ld	l,-2 (ix)
	ld	h,-1 (ix)
	ld	(hl),#0x80
	inc	hl
	xor	a, a
	ld	(hl), a
	inc	hl
	ld	(hl), a
	inc	hl
	ld	(hl),#0x00
;fatFs\diskio_diskioctl.c:73: res = RES_OK;
	ld	-9 (ix),#0x00
;fatFs\diskio_diskioctl.c:74: break;
	jr	00115$
;fatFs\diskio_diskioctl.c:76: default:
00114$:
;fatFs\diskio_diskioctl.c:77: res = RES_PARERR;
	ld	-9 (ix),#0x04
;fatFs\diskio_diskioctl.c:78: }
00115$:
;fatFs\diskio_diskioctl.c:80: deselect();
	call	_deselect
;fatFs\diskio_diskioctl.c:82: return res;
	ld	l,-9 (ix)
00116$:
	ld	sp, ix
	pop	ix
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
