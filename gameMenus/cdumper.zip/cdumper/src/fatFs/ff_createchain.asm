;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 3.5.0 #9253 (Jun 20 2015) (MINGW64)
; This file was generated Fri Sep 13 00:04:20 2019
;--------------------------------------------------------
	.module ff_createchain
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _put_fat
	.globl _get_fat
	.globl _create_chain
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
_VDPRD	=	0x00be
_VDPST	=	0x00bf
_VDPWA	=	0x00bf
_VDPWD	=	0x00be
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\ff_createchain.c:45: DWORD create_chain (	/* 0:No free cluster, 1:Internal error, 0xFFFFFFFF:Disk error, >=2:New cluster# */
;	---------------------------------
; Function create_chain
; ---------------------------------
_create_chain::
	call	___sdcc_enter_ix
	ld	hl,#-33
	add	hl,sp
	ld	sp,hl
;fatFs\ff_createchain.c:52: FATFS *fs = obj->fs;
	ld	a,4 (ix)
	ld	-2 (ix),a
	ld	a,5 (ix)
	ld	-1 (ix),a
	ld	l,-2 (ix)
	ld	h,-1 (ix)
	ld	a,(hl)
	ld	-33 (ix),a
	inc	hl
	ld	a,(hl)
	ld	-32 (ix),a
;fatFs\ff_createchain.c:55: scl = fs->last_clst;				/* Suggested cluster to start to find */
	ld	a,-33 (ix)
	add	a, #0x0A
	ld	-14 (ix),a
	ld	a,-32 (ix)
	adc	a, #0x00
	ld	-13 (ix),a
;fatFs\ff_createchain.c:56: if (scl == 0 || scl >= fs->n_fatent) scl = 1;
	ld	a,-33 (ix)
	add	a, #0x12
	ld	-4 (ix),a
	ld	a,-32 (ix)
	adc	a, #0x00
	ld	-3 (ix),a
;fatFs\ff_createchain.c:54: if (clst == 0) {	/* Create a new chain */
	ld	a,9 (ix)
	or	a, 8 (ix)
	or	a, 7 (ix)
	or	a,6 (ix)
	jr	NZ,00111$
;fatFs\ff_createchain.c:55: scl = fs->last_clst;				/* Suggested cluster to start to find */
	ld	e,-14 (ix)
	ld	d,-13 (ix)
	ld	hl, #0x000B
	add	hl, sp
	ex	de, hl
	ld	bc, #0x0004
	ldir
;fatFs\ff_createchain.c:99: if (ncl >= fs->n_fatent) ncl = 2;
	ld	e,-4 (ix)
	ld	d,-3 (ix)
	ld	hl, #0x0019
	add	hl, sp
	ex	de, hl
	ld	bc, #0x0004
	ldir
;fatFs\ff_createchain.c:56: if (scl == 0 || scl >= fs->n_fatent) scl = 1;
	ld	a,-19 (ix)
	or	a, -20 (ix)
	or	a, -21 (ix)
	or	a,-22 (ix)
	jr	Z,00101$
	ld	a,-22 (ix)
	sub	a, -8 (ix)
	ld	a,-21 (ix)
	sbc	a, -7 (ix)
	ld	a,-20 (ix)
	sbc	a, -6 (ix)
	ld	a,-19 (ix)
	sbc	a, -5 (ix)
	jp	C,00112$
00101$:
	ld	-22 (ix),#0x01
	xor	a, a
	ld	-21 (ix),a
	ld	-20 (ix),a
	ld	-19 (ix),a
	jp	00112$
00111$:
;fatFs\ff_createchain.c:59: cs = get_fat(obj, clst);			/* Check the cluster status */
	ld	l,8 (ix)
	ld	h,9 (ix)
	push	hl
	ld	l,6 (ix)
	ld	h,7 (ix)
	push	hl
	ld	l,-2 (ix)
	ld	h,-1 (ix)
	push	hl
	call	_get_fat
	pop	af
	pop	af
	pop	af
	ld	b,l
	ld	c,h
;fatFs\ff_createchain.c:60: if (cs < 2) return 1;				/* Test for insanity */
	ld	a,b
	sub	a, #0x02
	ld	a,c
	sbc	a, #0x00
	ld	a,e
	sbc	a, #0x00
	ld	a,d
	sbc	a, #0x00
	jr	NC,00105$
	ld	hl,#0x0001
	ld	de,#0x0000
	jp	00151$
00105$:
;fatFs\ff_createchain.c:61: if (cs == 0xFFFFFFFF) {
	ld	a,b
	inc	a
	jr	NZ,00107$
	ld	a,c
	inc	a
	jr	NZ,00107$
	ld	a,e
	inc	a
	jr	NZ,00107$
	ld	a,d
	inc	a
	jr	NZ,00107$
;fatFs\ff_createchain.c:62: return cs;	/* Test for disk error */
	ld	l,b
	ld	h,c
	jp	00151$
00107$:
;fatFs\ff_createchain.c:99: if (ncl >= fs->n_fatent) ncl = 2;
	push	de
	push	bc
	ld	e,-4 (ix)
	ld	d,-3 (ix)
	ld	hl, #0x001D
	add	hl, sp
	ex	de, hl
	ld	bc, #0x0004
	ldir
	pop	bc
	pop	de
;fatFs\ff_createchain.c:64: if (cs < fs->n_fatent) return cs;	/* It is already followed by next cluster */
	ld	a,b
	sub	a, -8 (ix)
	ld	a,c
	sbc	a, -7 (ix)
	ld	a,e
	sbc	a, -6 (ix)
	ld	a,d
	sbc	a, -5 (ix)
	jr	NC,00109$
	ld	l,b
	ld	h,c
	jp	00151$
00109$:
;fatFs\ff_createchain.c:65: scl = clst;							/* Cluster to start to find */
	ld	hl, #11
	add	hl, sp
	ex	de, hl
	ld	hl, #39
	add	hl, sp
	ld	bc, #4
	ldir
00112$:
;fatFs\ff_createchain.c:67: if (fs->free_clst == 0) return 0;		/* No free cluster */
	ld	a,-33 (ix)
	add	a, #0x0E
	ld	-10 (ix),a
	ld	a,-32 (ix)
	adc	a, #0x00
	ld	-9 (ix),a
	ld	l,-10 (ix)
	ld	h,-9 (ix)
	ld	d,(hl)
	inc	hl
	ld	e,(hl)
	inc	hl
	ld	b,(hl)
	inc	hl
	ld	a, (hl)
	or	a, b
	or	a, e
	or	a,d
	jr	NZ,00114$
	ld	hl,#0x0000
	ld	e,l
	ld	d,h
	jp	00151$
00114$:
;fatFs\ff_createchain.c:96: ncl = 0;
	xor	a, a
	ld	-26 (ix),a
	ld	-25 (ix),a
	ld	-24 (ix),a
	ld	-23 (ix),a
;fatFs\ff_createchain.c:97: if (scl == clst) {						/* Stretching an existing chain? */
	ld	a,-22 (ix)
	sub	a, 6 (ix)
	jp	NZ,00126$
	ld	a,-21 (ix)
	sub	a, 7 (ix)
	jp	NZ,00126$
	ld	a,-20 (ix)
	sub	a, 8 (ix)
	jp	NZ,00126$
	ld	a,-19 (ix)
	sub	a, 9 (ix)
	jp	NZ,00126$
;fatFs\ff_createchain.c:98: ncl = scl + 1;						/* Test if next cluster is free */
	ld	a,-22 (ix)
	add	a, #0x01
	ld	-26 (ix),a
	ld	a,-21 (ix)
	adc	a, #0x00
	ld	-25 (ix),a
	ld	a,-20 (ix)
	adc	a, #0x00
	ld	-24 (ix),a
	ld	a,-19 (ix)
	adc	a, #0x00
	ld	-23 (ix),a
;fatFs\ff_createchain.c:99: if (ncl >= fs->n_fatent) ncl = 2;
	ld	a,-26 (ix)
	sub	a, -8 (ix)
	ld	a,-25 (ix)
	sbc	a, -7 (ix)
	ld	a,-24 (ix)
	sbc	a, -6 (ix)
	ld	a,-23 (ix)
	sbc	a, -5 (ix)
	jr	C,00116$
	ld	-26 (ix),#0x02
	xor	a, a
	ld	-25 (ix),a
	ld	-24 (ix),a
	ld	-23 (ix),a
00116$:
;fatFs\ff_createchain.c:100: cs = get_fat(obj, ncl);				/* Get next cluster status */
	ld	l,-24 (ix)
	ld	h,-23 (ix)
	push	hl
	ld	l,-26 (ix)
	ld	h,-25 (ix)
	push	hl
	ld	l,-2 (ix)
	ld	h,-1 (ix)
	push	hl
	call	_get_fat
	pop	af
	pop	af
	pop	af
	ld	c,l
	ld	b,h
;fatFs\ff_createchain.c:101: if (cs == 1 || cs == 0xFFFFFFFF) {
	ld	a,c
	dec	a
	jr	NZ,00255$
	ld	a,b
	or	a,a
	jr	NZ,00255$
	or	a,e
	jr	NZ,00255$
	or	a,d
	jr	Z,00117$
00255$:
	ld	a,c
	inc	a
	jr	NZ,00118$
	ld	a,b
	inc	a
	jr	NZ,00118$
	ld	a,e
	inc	a
	jr	NZ,00118$
	ld	a,d
	inc	a
	jr	NZ,00118$
00117$:
;fatFs\ff_createchain.c:102: return cs;	/* Test for error */
	ld	l,c
	ld	h,b
	jp	00151$
00118$:
;fatFs\ff_createchain.c:104: if (cs != 0) {						/* Not free? */
	ld	a,d
	or	a, e
	or	a, b
	or	a,c
	jr	Z,00126$
;fatFs\ff_createchain.c:105: cs = fs->last_clst;				/* Start at suggested cluster if it is valid */
	ld	e,-14 (ix)
	ld	d,-13 (ix)
	ld	hl, #0x0002
	add	hl, sp
	ex	de, hl
	ld	bc, #0x0004
	ldir
;fatFs\ff_createchain.c:106: if (cs >= 2 && cs < fs->n_fatent) scl = cs;
	ld	a,-31 (ix)
	sub	a, #0x02
	ld	a,-30 (ix)
	sbc	a, #0x00
	ld	a,-29 (ix)
	sbc	a, #0x00
	ld	a,-28 (ix)
	sbc	a, #0x00
	jr	C,00121$
	ld	l,-4 (ix)
	ld	h,-3 (ix)
	ld	d,(hl)
	inc	hl
	ld	e,(hl)
	inc	hl
	ld	b,(hl)
	inc	hl
	ld	h,(hl)
	ld	a,-31 (ix)
	sub	a, d
	ld	a,-30 (ix)
	sbc	a, e
	ld	a,-29 (ix)
	sbc	a, b
	ld	a,-28 (ix)
	sbc	a, h
	jr	NC,00121$
	ld	hl, #11
	add	hl, sp
	ex	de, hl
	ld	hl, #2
	add	hl, sp
	ld	bc, #4
	ldir
00121$:
;fatFs\ff_createchain.c:107: ncl = 0;
	xor	a, a
	ld	-26 (ix),a
	ld	-25 (ix),a
	ld	-24 (ix),a
	ld	-23 (ix),a
00126$:
;fatFs\ff_createchain.c:110: if (ncl == 0) {	/* The new cluster cannot be contiguous and find another fragment */
	ld	a,-23 (ix)
	or	a, -24 (ix)
	or	a, -25 (ix)
	or	a,-26 (ix)
	jp	NZ,00140$
;fatFs\ff_createchain.c:111: ncl = scl;	/* Start cluster */
	ld	hl, #7
	add	hl, sp
	ex	de, hl
	ld	hl, #11
	add	hl, sp
	ld	bc, #4
	ldir
	ld	a,-22 (ix)
	sub	a, #0x02
	ld	a,-21 (ix)
	sbc	a, #0x00
	ld	a,-20 (ix)
	sbc	a, #0x00
	ld	a,-19 (ix)
	sbc	a, #0x00
	ld	a,#0x00
	rla
	ld	-8 (ix),a
	ld	a,-4 (ix)
	ld	-12 (ix),a
	ld	a,-3 (ix)
	ld	-11 (ix),a
00149$:
;fatFs\ff_createchain.c:113: ncl++;							/* Next cluster */
	inc	-26 (ix)
	jr	NZ,00258$
	inc	-25 (ix)
	jr	NZ,00258$
	inc	-24 (ix)
	jr	NZ,00258$
	inc	-23 (ix)
00258$:
;fatFs\ff_createchain.c:114: if (ncl >= fs->n_fatent) {		/* Check wrap-around */
	ld	l,-12 (ix)
	ld	h,-11 (ix)
	ld	d,(hl)
	inc	hl
	ld	e,(hl)
	inc	hl
	ld	c,(hl)
	inc	hl
	ld	h,(hl)
	ld	a,-26 (ix)
	sub	a, d
	ld	a,-25 (ix)
	sbc	a, e
	ld	a,-24 (ix)
	sbc	a, c
	ld	a,-23 (ix)
	sbc	a, h
	jr	C,00130$
;fatFs\ff_createchain.c:115: ncl = 2;
	ld	-26 (ix),#0x02
	xor	a, a
	ld	-25 (ix),a
	ld	-24 (ix),a
	ld	-23 (ix),a
;fatFs\ff_createchain.c:116: if (ncl > scl) return 0;	/* No free cluster found? */
	ld	a,-8 (ix)
	or	a, a
	jr	Z,00130$
	ld	hl,#0x0000
	ld	e,l
	ld	d,h
	jp	00151$
00130$:
;fatFs\ff_createchain.c:118: cs = get_fat(obj, ncl);			/* Get the cluster status */
	ld	l,-24 (ix)
	ld	h,-23 (ix)
	push	hl
	ld	l,-26 (ix)
	ld	h,-25 (ix)
	push	hl
	ld	l,-2 (ix)
	ld	h,-1 (ix)
	push	hl
	call	_get_fat
	pop	af
	pop	af
	pop	af
;fatFs\ff_createchain.c:119: if (cs == 0) break;				/* Found a free cluster? */
	ld	a,d
	or	a, e
	or	a, h
	or	a,l
	jr	Z,00140$
;fatFs\ff_createchain.c:120: if (cs == 1 || cs == 0xFFFFFFFF) {
	ld	a,l
	dec	a
	jr	NZ,00259$
	ld	a,h
	or	a,a
	jr	NZ,00259$
	or	a,e
	jr	NZ,00259$
	or	a,d
	jp	Z,00151$
00259$:
	ld	a,l
	inc	a
	jr	NZ,00134$
	ld	a,h
	inc	a
	jr	NZ,00134$
	ld	a,e
	inc	a
	jr	NZ,00134$
	ld	a,d
	inc	a
;fatFs\ff_createchain.c:121: return cs;	/* Test for error */
	jp	Z,00151$
00134$:
;fatFs\ff_createchain.c:123: if (ncl == scl) return 0;		/* No free cluster found? */
	ld	a,-26 (ix)
	sub	a, -22 (ix)
	jp	NZ,00149$
	ld	a,-25 (ix)
	sub	a, -21 (ix)
	jp	NZ,00149$
	ld	a,-24 (ix)
	sub	a, -20 (ix)
	jp	NZ,00149$
	ld	a,-23 (ix)
	sub	a, -19 (ix)
	jp	NZ,00149$
	ld	hl,#0x0000
	ld	e,l
	ld	d,h
	jp	00151$
00140$:
;fatFs\ff_createchain.c:126: res = put_fat(fs, ncl, 0xFFFFFFFF);		/* Mark the new cluster 'EOC' */
	ld	hl,#0xFFFF
	push	hl
	ld	hl,#0xFFFF
	push	hl
	ld	l,-24 (ix)
	ld	h,-23 (ix)
	push	hl
	ld	l,-26 (ix)
	ld	h,-25 (ix)
	push	hl
	ld	l,-33 (ix)
	ld	h,-32 (ix)
	push	hl
	call	_put_fat
	ld	iy,#10
	add	iy,sp
	ld	sp,iy
;fatFs\ff_createchain.c:127: if (res == FR_OK && clst != 0) {
	ld	-27 (ix), l
	ld	a, l
	or	a, a
	jr	NZ,00142$
	ld	a,9 (ix)
	or	a, 8 (ix)
	or	a, 7 (ix)
	or	a,6 (ix)
	jr	Z,00142$
;fatFs\ff_createchain.c:128: res = put_fat(fs, clst, ncl);		/* Link it from the previous one if needed */
	ld	l,-24 (ix)
	ld	h,-23 (ix)
	push	hl
	ld	l,-26 (ix)
	ld	h,-25 (ix)
	push	hl
	ld	l,8 (ix)
	ld	h,9 (ix)
	push	hl
	ld	l,6 (ix)
	ld	h,7 (ix)
	push	hl
	ld	l,-33 (ix)
	ld	h,-32 (ix)
	push	hl
	call	_put_fat
	ld	iy,#10
	add	iy,sp
	ld	sp,iy
	ld	-27 (ix),l
00142$:
;fatFs\ff_createchain.c:132: if (res == FR_OK) {			/* Update FSINFO if function succeeded. */
	ld	a,-27 (ix)
	or	a, a
	jp	NZ,00147$
;fatFs\ff_createchain.c:133: fs->last_clst = ncl;
	ld	e,-14 (ix)
	ld	d,-13 (ix)
	ld	hl, #0x0007
	add	hl, sp
	ld	bc, #0x0004
	ldir
;fatFs\ff_createchain.c:134: if (fs->free_clst <= fs->n_fatent - 2) fs->free_clst--;
	ld	e,-10 (ix)
	ld	d,-9 (ix)
	ld	hl, #0x0019
	add	hl, sp
	ex	de, hl
	ld	bc, #0x0004
	ldir
	ld	e,-4 (ix)
	ld	d,-3 (ix)
	ld	hl, #0x000F
	add	hl, sp
	ex	de, hl
	ld	bc, #0x0004
	ldir
	ld	a,-18 (ix)
	add	a,#0xFE
	ld	-18 (ix),a
	ld	a,-17 (ix)
	adc	a,#0xFF
	ld	-17 (ix),a
	ld	a,-16 (ix)
	adc	a,#0xFF
	ld	-16 (ix),a
	ld	a,-15 (ix)
	adc	a,#0xFF
	ld	-15 (ix),a
	ld	a,-18 (ix)
	sub	a, -8 (ix)
	ld	a,-17 (ix)
	sbc	a, -7 (ix)
	ld	a,-16 (ix)
	sbc	a, -6 (ix)
	ld	a,-15 (ix)
	sbc	a, -5 (ix)
	jr	C,00145$
	ld	a,-8 (ix)
	add	a,#0xFF
	ld	-18 (ix),a
	ld	a,-7 (ix)
	adc	a,#0xFF
	ld	-17 (ix),a
	ld	a,-6 (ix)
	adc	a,#0xFF
	ld	-16 (ix),a
	ld	a,-5 (ix)
	adc	a,#0xFF
	ld	-15 (ix),a
	ld	e,-10 (ix)
	ld	d,-9 (ix)
	ld	hl, #0x000F
	add	hl, sp
	ld	bc, #0x0004
	ldir
00145$:
;fatFs\ff_createchain.c:135: fs->fsi_flag |= 1;
	pop	hl
	push	hl
	inc	hl
	inc	hl
	inc	hl
	set	0, (hl)
	ld	a, (hl)
	jr	00148$
00147$:
;fatFs\ff_createchain.c:137: ncl = (res == FR_DISK_ERR) ? 0xFFFFFFFF : 1;	/* Failed. Generate error status */
	ld	a,-27 (ix)
	dec	a
	jr	NZ,00153$
	ld	-18 (ix),#0xFF
	ld	-17 (ix),#0xFF
	ld	-16 (ix),#0xFF
	ld	-15 (ix),#0xFF
	jr	00154$
00153$:
	ld	-18 (ix),#0x01
	xor	a, a
	ld	-17 (ix),a
	ld	-16 (ix),a
	ld	-15 (ix),a
00154$:
	ld	hl, #7
	add	hl, sp
	ex	de, hl
	ld	hl, #15
	add	hl, sp
	ld	bc, #4
	ldir
00148$:
;fatFs\ff_createchain.c:140: return ncl;		/* Return new cluster number or error status */
	ld	l,-26 (ix)
	ld	h,-25 (ix)
	ld	e,-24 (ix)
	ld	d,-23 (ix)
00151$:
	ld	sp, ix
	pop	ix
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
