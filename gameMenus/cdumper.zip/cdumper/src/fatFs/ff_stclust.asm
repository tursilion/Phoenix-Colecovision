;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 3.5.0 #9253 (Jun 20 2015) (MINGW64)
; This file was generated Thu Sep 12 23:57:57 2019
;--------------------------------------------------------
	.module ff_stclust
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _st_word
	.globl _st_clust
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\ff_stclust.c:39: void st_clust (
;	---------------------------------
; Function st_clust
; ---------------------------------
_st_clust::
	call	___sdcc_enter_ix
;fatFs\ff_stclust.c:45: st_word(dir + DIR_FstClusLO, (WORD)cl);
	ld	e,8 (ix)
	ld	d,9 (ix)
	ld	a,6 (ix)
	add	a, #0x1A
	ld	l,a
	ld	a,7 (ix)
	adc	a, #0x00
	ld	h,a
	push	de
	push	hl
	call	_st_word
	pop	af
	pop	af
;fatFs\ff_stclust.c:46: if (fs->fs_type == FS_FAT32) {
	ld	l,4 (ix)
	ld	h,5 (ix)
	ld	a,(hl)
	sub	a, #0x03
	jr	NZ,00103$
;fatFs\ff_stclust.c:47: st_word(dir + DIR_FstClusHI, (WORD)(cl >> 16));
	push	af
	ld	e,8 (ix)
	ld	d,9 (ix)
	ld	l,10 (ix)
	ld	h,11 (ix)
	pop	af
	ld	b,#0x10
00111$:
	srl	h
	rr	l
	rr	d
	rr	e
	djnz	00111$
	ld	a,6 (ix)
	add	a, #0x14
	ld	l,a
	ld	a,7 (ix)
	adc	a, #0x00
	ld	h,a
	push	de
	push	hl
	call	_st_word
	pop	af
	pop	af
00103$:
	pop	ix
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
