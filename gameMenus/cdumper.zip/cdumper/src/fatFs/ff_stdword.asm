;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 3.5.0 #9253 (Jun 20 2015) (MINGW64)
; This file was generated Thu Sep 12 23:57:58 2019
;--------------------------------------------------------
	.module ff_stdword
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _st_dword
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\ff_stdword.c:39: void st_dword (BYTE* ptr, DWORD val)	/* Store a 4-byte word in little-endian */
;	---------------------------------
; Function st_dword
; ---------------------------------
_st_dword::
	call	___sdcc_enter_ix
;fatFs\ff_stdword.c:41: *ptr++ = (BYTE)val; val >>= 8;
	ld	l,4 (ix)
	ld	h,5 (ix)
	ld	a,6 (ix)
	ld	(hl),a
	inc	hl
	ld	4 (ix),l
	ld	5 (ix),h
	push	af
	pop	af
	ld	b,#0x08
00103$:
	srl	9 (ix)
	rr	8 (ix)
	rr	7 (ix)
	rr	6 (ix)
	djnz	00103$
;fatFs\ff_stdword.c:42: *ptr++ = (BYTE)val; val >>= 8;
	ld	l,4 (ix)
	ld	h,5 (ix)
	ld	a,6 (ix)
	ld	(hl),a
	inc	hl
	ld	4 (ix),l
	ld	5 (ix),h
	push	af
	pop	af
	ld	b,#0x08
00105$:
	srl	9 (ix)
	rr	8 (ix)
	rr	7 (ix)
	rr	6 (ix)
	djnz	00105$
;fatFs\ff_stdword.c:43: *ptr++ = (BYTE)val; val >>= 8;
	ld	l,4 (ix)
	ld	h,5 (ix)
	ld	a,6 (ix)
	ld	(hl),a
	inc	hl
	ld	4 (ix),l
	ld	5 (ix),h
	push	af
	pop	af
	ld	b,#0x08
00107$:
	srl	9 (ix)
	rr	8 (ix)
	rr	7 (ix)
	rr	6 (ix)
	djnz	00107$
;fatFs\ff_stdword.c:44: *ptr++ = (BYTE)val;
	ld	l,4 (ix)
	ld	h,5 (ix)
	ld	a,6 (ix)
	ld	(hl),a
	pop	ix
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
