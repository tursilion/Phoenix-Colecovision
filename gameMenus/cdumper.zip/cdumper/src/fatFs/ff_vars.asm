;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 3.5.0 #9253 (Jun 20 2015) (MINGW64)
; This file was generated Thu Sep 12 23:58:03 2019
;--------------------------------------------------------
	.module ff_vars
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _ExCvt
	.globl _Fsid
	.globl _FatFs
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
_FatFs::
	.ds 2
_Fsid::
	.ds 2
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
	.area _CODE
_ExCvt:
	.db #0x80	; 128
	.db #0x9A	; 154
	.db #0x45	; 69	'E'
	.db #0x41	; 65	'A'
	.db #0x8E	; 142
	.db #0x41	; 65	'A'
	.db #0x8F	; 143
	.db #0x80	; 128
	.db #0x45	; 69	'E'
	.db #0x45	; 69	'E'
	.db #0x45	; 69	'E'
	.db #0x49	; 73	'I'
	.db #0x49	; 73	'I'
	.db #0x49	; 73	'I'
	.db #0x8E	; 142
	.db #0x8F	; 143
	.db #0x90	; 144
	.db #0x92	; 146
	.db #0x92	; 146
	.db #0x4F	; 79	'O'
	.db #0x99	; 153
	.db #0x4F	; 79	'O'
	.db #0x55	; 85	'U'
	.db #0x55	; 85	'U'
	.db #0x59	; 89	'Y'
	.db #0x99	; 153
	.db #0x9A	; 154
	.db #0x9B	; 155
	.db #0x9C	; 156
	.db #0x9D	; 157
	.db #0x9E	; 158
	.db #0x9F	; 159
	.db #0x41	; 65	'A'
	.db #0x49	; 73	'I'
	.db #0x4F	; 79	'O'
	.db #0x55	; 85	'U'
	.db #0xA5	; 165
	.db #0xA5	; 165
	.db #0xA6	; 166
	.db #0xA7	; 167
	.db #0xA8	; 168
	.db #0xA9	; 169
	.db #0xAA	; 170
	.db #0xAB	; 171
	.db #0xAC	; 172
	.db #0xAD	; 173
	.db #0xAE	; 174
	.db #0xAF	; 175
	.db #0xB0	; 176
	.db #0xB1	; 177
	.db #0xB2	; 178
	.db #0xB3	; 179
	.db #0xB4	; 180
	.db #0xB5	; 181
	.db #0xB6	; 182
	.db #0xB7	; 183
	.db #0xB8	; 184
	.db #0xB9	; 185
	.db #0xBA	; 186
	.db #0xBB	; 187
	.db #0xBC	; 188
	.db #0xBD	; 189
	.db #0xBE	; 190
	.db #0xBF	; 191
	.db #0xC0	; 192
	.db #0xC1	; 193
	.db #0xC2	; 194
	.db #0xC3	; 195
	.db #0xC4	; 196
	.db #0xC5	; 197
	.db #0xC6	; 198
	.db #0xC7	; 199
	.db #0xC8	; 200
	.db #0xC9	; 201
	.db #0xCA	; 202
	.db #0xCB	; 203
	.db #0xCC	; 204
	.db #0xCD	; 205
	.db #0xCE	; 206
	.db #0xCF	; 207
	.db #0xD0	; 208
	.db #0xD1	; 209
	.db #0xD2	; 210
	.db #0xD3	; 211
	.db #0xD4	; 212
	.db #0xD5	; 213
	.db #0xD6	; 214
	.db #0xD7	; 215
	.db #0xD8	; 216
	.db #0xD9	; 217
	.db #0xDA	; 218
	.db #0xDB	; 219
	.db #0xDC	; 220
	.db #0xDD	; 221
	.db #0xDE	; 222
	.db #0xDF	; 223
	.db #0xE0	; 224
	.db #0xE1	; 225
	.db #0xE2	; 226
	.db #0xE3	; 227
	.db #0xE4	; 228
	.db #0xE5	; 229
	.db #0xE6	; 230
	.db #0xE7	; 231
	.db #0xE8	; 232
	.db #0xE9	; 233
	.db #0xEA	; 234
	.db #0xEB	; 235
	.db #0xEC	; 236
	.db #0xED	; 237
	.db #0xEE	; 238
	.db #0xEF	; 239
	.db #0xF0	; 240
	.db #0xF1	; 241
	.db #0xF2	; 242
	.db #0xF3	; 243
	.db #0xF4	; 244
	.db #0xF5	; 245
	.db #0xF6	; 246
	.db #0xF7	; 247
	.db #0xF8	; 248
	.db #0xF9	; 249
	.db #0xFA	; 250
	.db #0xFB	; 251
	.db #0xFC	; 252
	.db #0xFD	; 253
	.db #0xFE	; 254
	.db #0xFF	; 255
	.area _INITIALIZER
	.area _CABS (ABS)
