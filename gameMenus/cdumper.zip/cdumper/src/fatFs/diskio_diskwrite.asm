;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 3.5.0 #9253 (Jun 20 2015) (MINGW64)
; This file was generated Thu Sep 12 23:57:19 2019
;--------------------------------------------------------
	.module diskio_diskwrite
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _send_cmd
	.globl _xmit_datablock
	.globl _deselect
	.globl _disk_status
	.globl _disk_write
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
_sgmPSGAddressWrite	=	0x0050
_sgmPSGDataWrite	=	0x0051
_sgmPSGDataRead	=	0x0052
_sgmConfig	=	0x0053
_phRAMBankSelect	=	0x0054
_phBankingScheme	=	0x0055
_phSDControl	=	0x0056
_phSDData	=	0x0057
_phMachineID	=	0x0058
_phCartMask	=	0x0059
_sgmBIOSMap	=	0x007f
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\diskio_diskwrite.c:30: DRESULT disk_write (
;	---------------------------------
; Function disk_write
; ---------------------------------
_disk_write::
	call	___sdcc_enter_ix
;fatFs\diskio_diskwrite.c:42: if (disk_status() & STA_NOINIT) return RES_NOTRDY;
	call	_disk_status
	ld	a,l
	rrca
	jr	NC,00102$
	ld	l,#0x03
	jp	00122$
00102$:
;fatFs\diskio_diskwrite.c:44: if (!(CardType & CT_BLOCK)) sector *= 512;	/* Convert LBA to byte address if needed */
	ld	hl,#_CardType+0
	bit	3, (hl)
	jr	NZ,00104$
	push	af
	pop	af
	ld	b,#0x09
00173$:
	sla	6 (ix)
	rl	7 (ix)
	rl	8 (ix)
	rl	9 (ix)
	djnz	00173$
00104$:
;fatFs\diskio_diskwrite.c:46: if (count == 1) {	/* Single block write */
	ld	a,10 (ix)
	dec	a
	jr	NZ,00120$
	ld	a,11 (ix)
	or	a, a
	jr	NZ,00120$
;fatFs\diskio_diskwrite.c:47: if ((send_cmd(CMD24, sector) == 0)	/* WRITE_BLOCK */
	ld	l,8 (ix)
	ld	h,9 (ix)
	push	hl
	ld	l,6 (ix)
	ld	h,7 (ix)
	push	hl
	ld	a,#0x18
	push	af
	inc	sp
	call	_send_cmd
	pop	af
	pop	af
	inc	sp
	ld	a,l
	or	a, a
	jp	NZ,00121$
;fatFs\diskio_diskwrite.c:48: && xmit_datablock(buff, 0xFE))
	ld	a,#0xFE
	push	af
	inc	sp
	ld	l,4 (ix)
	ld	h,5 (ix)
	push	hl
	call	_xmit_datablock
	pop	af
	inc	sp
	ld	a,h
	or	a,l
	jp	Z,00121$
;fatFs\diskio_diskwrite.c:49: count = 0;
	ld	10 (ix),#0x00
	ld	11 (ix),#0x00
	jp	00121$
00120$:
;fatFs\diskio_diskwrite.c:52: if (CardType & CT_SDC) send_cmd(ACMD23, count);
	ld	a,(#_CardType + 0)
	and	a, #0x06
	jr	Z,00109$
	ld	e,10 (ix)
	ld	d,11 (ix)
	ld	hl,#0x0000
	push	hl
	push	de
	ld	a,#0x97
	push	af
	inc	sp
	call	_send_cmd
	pop	af
	pop	af
	inc	sp
00109$:
;fatFs\diskio_diskwrite.c:53: if (send_cmd(CMD25, sector) == 0) {	/* WRITE_MULTIPLE_BLOCK */
	ld	l,8 (ix)
	ld	h,9 (ix)
	push	hl
	ld	l,6 (ix)
	ld	h,7 (ix)
	push	hl
	ld	a,#0x19
	push	af
	inc	sp
	call	_send_cmd
	pop	af
	pop	af
	inc	sp
	ld	a,l
	or	a, a
	jr	NZ,00121$
;fatFs\diskio_diskwrite.c:54: do {
	ld	e,4 (ix)
	ld	d,5 (ix)
	ld	c,10 (ix)
	ld	b,11 (ix)
00112$:
;fatFs\diskio_diskwrite.c:55: if (!xmit_datablock(buff, 0xFC)) break;
	push	bc
	push	de
	ld	a,#0xFC
	push	af
	inc	sp
	push	de
	call	_xmit_datablock
	pop	af
	inc	sp
	pop	de
	pop	bc
	ld	a,h
	or	a,l
	jr	Z,00136$
;fatFs\diskio_diskwrite.c:56: buff += 512;
	ld	hl,#0x0200
	add	hl,de
	ex	de,hl
;fatFs\diskio_diskwrite.c:57: } while (--count);
	dec	bc
	ld	a,b
	or	a,c
	jr	NZ,00112$
00136$:
	ld	10 (ix),c
	ld	11 (ix),b
;fatFs\diskio_diskwrite.c:58: if (!xmit_datablock(0, 0xFD))	/* STOP_TRAN token */
	ld	a,#0xFD
	push	af
	inc	sp
	ld	hl,#0x0000
	push	hl
	call	_xmit_datablock
	pop	af
	inc	sp
	ld	a,h
	or	a,l
	jr	NZ,00121$
;fatFs\diskio_diskwrite.c:59: count = 1;
	ld	10 (ix),#0x01
	ld	11 (ix),#0x00
00121$:
;fatFs\diskio_diskwrite.c:62: deselect();
	call	_deselect
;fatFs\diskio_diskwrite.c:64: return count ? RES_ERROR : RES_OK;
	ld	a,11 (ix)
	or	a,10 (ix)
	jr	Z,00124$
	ld	l,#0x01
	jr	00125$
00124$:
	ld	l,#0x00
00125$:
00122$:
	pop	ix
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
