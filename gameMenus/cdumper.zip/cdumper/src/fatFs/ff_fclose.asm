;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 3.5.0 #9253 (Jun 20 2015) (MINGW64)
; This file was generated Thu Sep 12 23:57:32 2019
;--------------------------------------------------------
	.module ff_fclose
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _validate
	.globl _f_sync
	.globl _f_close
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\ff_fclose.c:42: FRESULT f_close (
;	---------------------------------
; Function f_close
; ---------------------------------
_f_close::
	push	af
;fatFs\ff_fclose.c:50: res = f_sync(fp);					/* Flush cached data */
	ld	hl, #4
	add	hl, sp
	ld	c, (hl)
	inc	hl
	ld	b, (hl)
	push	bc
	call	_f_sync
	pop	af
	ld	a,l
;fatFs\ff_fclose.c:51: if (res == FR_OK)
	or	a, a
	jr	NZ,00104$
;fatFs\ff_fclose.c:54: res = validate(&fp->obj, &fs);	/* Lock volume */
	ld	hl,#0x0000
	add	hl,sp
	ex	de,hl
	ld	hl, #4
	add	hl, sp
	ld	a, (hl)
	inc	hl
	ld	h, (hl)
	ld	l, a
	push	hl
	push	de
	push	hl
	call	_validate
	pop	af
	pop	af
	ld	a,l
	pop	hl
;fatFs\ff_fclose.c:55: if (res == FR_OK) {
;fatFs\ff_fclose.c:60: fp->obj.fs = 0;	/* Invalidate file object */
	or	a,a
	jr	NZ,00104$
	ld	(hl),a
	inc	hl
	ld	(hl),#0x00
00104$:
;fatFs\ff_fclose.c:67: return res;
	ld	l,a
	pop	af
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
