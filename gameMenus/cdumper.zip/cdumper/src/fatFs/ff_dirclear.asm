;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 3.5.0 #9253 (Jun 20 2015) (MINGW64)
; This file was generated Thu Sep 12 23:57:28 2019
;--------------------------------------------------------
	.module ff_dirclear
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _memset
	.globl _disk_write
	.globl _sync_window
	.globl _clst2sect
	.globl _dir_clear
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\ff_dirclear.c:43: FRESULT dir_clear (	/* Returns FR_OK or FR_DISK_ERR */
;	---------------------------------
; Function dir_clear
; ---------------------------------
_dir_clear::
	call	___sdcc_enter_ix
	ld	hl,#-12
	add	hl,sp
	ld	sp,hl
;fatFs\ff_dirclear.c:52: if (sync_window(fs) != FR_OK) return FR_DISK_ERR;	/* Flush disk access window */
	ld	l,4 (ix)
	ld	h,5 (ix)
	push	hl
	call	_sync_window
	pop	af
	ld	a, l
	or	a, a
	jr	Z,00102$
	ld	l,#0x01
	jp	00108$
00102$:
;fatFs\ff_dirclear.c:53: sect = clst2sect(fs, clst);		/* Top of the cluster */
	ld	l,8 (ix)
	ld	h,9 (ix)
	push	hl
	ld	l,6 (ix)
	ld	h,7 (ix)
	push	hl
	ld	l,4 (ix)
	ld	h,5 (ix)
	push	hl
	call	_clst2sect
	pop	af
	pop	af
	pop	af
	ld	-12 (ix),l
	ld	-11 (ix),h
	ld	-10 (ix),e
	ld	-9 (ix),d
;fatFs\ff_dirclear.c:54: fs->winsect = sect;				/* Set window to top of the cluster */
	ld	e,4 (ix)
	ld	d,5 (ix)
	ld	hl,#0x002A
	add	hl,de
	push	de
	ex	de,hl
	ld	hl, #0x0002
	add	hl, sp
	ld	bc, #0x0004
	ldir
	pop	de
;fatFs\ff_dirclear.c:55: memset(fs->win, 0, sizeof fs->win);	/* Clear window buffer */
	ld	hl,#0x002E
	add	hl,de
	push	hl
	pop	iy
	push	hl
	push	de
	ld	bc,#0x0200
	push	bc
	ld	bc,#0x0000
	push	bc
	push	iy
	call	_memset
	pop	af
	pop	af
	pop	af
	pop	de
	pop	hl
;fatFs\ff_dirclear.c:71: ibuf = fs->win; szb = 1;	/* Use window buffer (many single-sector writes may take a time) */
	ld	-8 (ix),l
	ld	-7 (ix),h
;fatFs\ff_dirclear.c:75: for (n = 0; n < fs->csize && disk_write(ibuf, sect + n, szb) == RES_OK; n += szb) ;	/* Fill the cluster with 0 */
	ld	hl,#0x0008
	add	hl,de
	ld	-2 (ix),l
	ld	-1 (ix),h
	ld	de,#0x0000
00106$:
	ld	l,-2 (ix)
	ld	h,-1 (ix)
	ld	b,(hl)
	inc	hl
	ld	h,(hl)
	ld	a,e
	sub	a, b
	ld	a,d
	sbc	a, h
	jr	NC,00103$
	ld	h,e
	ld	l,d
	ld	bc,#0x0000
	ld	a,-12 (ix)
	add	a, h
	ld	-6 (ix),a
	ld	a,-11 (ix)
	adc	a, l
	ld	-5 (ix),a
	ld	a,-10 (ix)
	adc	a, b
	ld	-4 (ix),a
	ld	a,-9 (ix)
	adc	a, c
	ld	-3 (ix),a
	push	de
	ld	hl,#0x0001
	push	hl
	ld	l,-4 (ix)
	ld	h,-3 (ix)
	push	hl
	ld	l,-6 (ix)
	ld	h,-5 (ix)
	push	hl
	ld	l,-8 (ix)
	ld	h,-7 (ix)
	push	hl
	call	_disk_write
	pop	af
	pop	af
	pop	af
	pop	af
	ld	a,l
	pop	de
	or	a, a
	jr	NZ,00103$
	inc	de
	jr	00106$
00103$:
;fatFs\ff_dirclear.c:78: return (n == fs->csize) ? FR_OK : FR_DISK_ERR;
	ld	l,-2 (ix)
	ld	h,-1 (ix)
	ld	c,(hl)
	inc	hl
	ld	b,(hl)
	ld	a,e
	sub	a, c
	jr	NZ,00110$
	ld	a,d
	sub	a,b
	jr	NZ,00110$
	ld	l,a
	jr	00111$
00110$:
	ld	l,#0x01
00111$:
00108$:
	ld	sp, ix
	pop	ix
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
