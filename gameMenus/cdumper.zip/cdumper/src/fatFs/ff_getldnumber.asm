;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 3.5.0 #9253 (Jun 20 2015) (MINGW64)
; This file was generated Thu Sep 12 23:57:50 2019
;--------------------------------------------------------
	.module ff_getldnumber
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _get_ldnumber_unused
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\ff_getldnumber.c:47: int get_ldnumber (	/* Returns logical drive number (-1:invalid drive number or null pointer) */
;	---------------------------------
; Function get_ldnumber_unused
; ---------------------------------
_get_ldnumber_unused::
	call	___sdcc_enter_ix
	ld	hl,#-12
	add	hl,sp
	ld	sp,hl
;fatFs\ff_getldnumber.c:53: int i, vol = -1;
	ld	hl,#0xFFFF
	ex	(sp), hl
;fatFs\ff_getldnumber.c:59: tt = tp = *path;
	ld	a,4 (ix)
	ld	-2 (ix),a
	ld	a,5 (ix)
	ld	-1 (ix),a
	ld	l,-2 (ix)
	ld	h,-1 (ix)
	ld	a,(hl)
	ld	-4 (ix),a
	inc	hl
	ld	a,(hl)
	ld	-3 (ix),a
	ld	a,-4 (ix)
	ld	-8 (ix),a
	ld	a,-3 (ix)
;fatFs\ff_getldnumber.c:60: if (!tp) return vol;	/* Invalid path name? */
	ld	-7 (ix), a
	or	a,-8 (ix)
	jr	NZ,00119$
	ld	hl,#0xFFFF
	jp	00115$
;fatFs\ff_getldnumber.c:61: do tc = *tt++; while ((UINT)tc >= (FF_USE_LFN ? ' ' : '!') && tc != ':');	/* Find a colon in the path */
00119$:
	ld	e,-4 (ix)
	ld	d,-3 (ix)
00104$:
	ld	a,(de)
	inc	de
	ld	l,a
	push	af
	rla
	sbc	a, a
	ld	b,a
	pop	af
	sub	a, #0x3A
	jr	NZ,00150$
	ld	a,#0x01
	jr	00151$
00150$:
	xor	a,a
00151$:
	ld	h,a
	ld	a,l
	sub	a, #0x21
	ld	a,b
	sbc	a, #0x00
	jr	C,00125$
	ld	a,h
	or	a, a
	jr	Z,00104$
00125$:
	ld	-4 (ix),e
	ld	-3 (ix),d
;fatFs\ff_getldnumber.c:63: if (tc == ':') {	/* DOS/Windows style volume ID? */
	ld	a,h
	or	a, a
	jp	Z,00114$
;fatFs\ff_getldnumber.c:64: i = FF_VOLUMES;
	ld	-10 (ix),#0x01
	ld	-9 (ix),#0x00
;fatFs\ff_getldnumber.c:65: if (IsDigit(*tp) && tp + 2 == tt) {	/* Is there a numeric volume ID + colon? */
	ld	l,-8 (ix)
	ld	h,-7 (ix)
	ld	b,(hl)
	ld	a,b
	xor	a, #0x80
	sub	a, #0xB0
	jr	C,00108$
	ld	a,#0x39
	sub	a, b
	jp	PO, 00152$
	xor	a, #0x80
00152$:
	jp	M,00108$
	ld	a,-8 (ix)
	add	a, #0x02
	ld	-6 (ix),a
	ld	a,-7 (ix)
	adc	a, #0x00
	ld	-5 (ix),a
	ld	a,e
	sub	a, -6 (ix)
	jr	NZ,00108$
	ld	a,d
	sub	a, -5 (ix)
	jr	NZ,00108$
;fatFs\ff_getldnumber.c:66: i = (int)*tp - '0';	/* Get the LD number */
	ld	a,b
	rla
	sbc	a, a
	ld	h,a
	ld	a,b
	add	a,#0xD0
	ld	-10 (ix),a
	ld	a,h
	adc	a,#0xFF
	ld	-9 (ix),a
00108$:
;fatFs\ff_getldnumber.c:83: if (i < FF_VOLUMES) {	/* If a volume ID is found, get the drive number and strip it */
	ld	a,-10 (ix)
	sub	a, #0x01
	ld	a,-9 (ix)
	rla
	ccf
	rra
	sbc	a, #0x80
	jr	NC,00112$
;fatFs\ff_getldnumber.c:84: vol = i;		/* Drive number */
	ld	a,-10 (ix)
	ld	-12 (ix),a
	ld	a,-9 (ix)
	ld	-11 (ix),a
;fatFs\ff_getldnumber.c:85: *path = tt;		/* Snip the drive prefix off */
	ld	l,-2 (ix)
	ld	h,-1 (ix)
	ld	a,-4 (ix)
	ld	(hl),a
	inc	hl
	ld	a,-3 (ix)
	ld	(hl),a
00112$:
;fatFs\ff_getldnumber.c:87: return vol;
	pop	hl
	push	hl
	jr	00115$
00114$:
;fatFs\ff_getldnumber.c:115: return vol;		/* Return the default drive */
	ld	hl,#0x0000
00115$:
	ld	sp, ix
	pop	ix
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
