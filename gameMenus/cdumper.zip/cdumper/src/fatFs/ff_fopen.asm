;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 3.5.0 #9253 (Jun 20 2015) (MINGW64)
; This file was generated Thu Sep 12 23:57:38 2019
;--------------------------------------------------------
	.module ff_fopen
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _memset
	.globl _disk_read
	.globl _st_dword
	.globl _dir_register
	.globl _st_clust
	.globl _remove_chain
	.globl _find_volume
	.globl _follow_path
	.globl _ld_clust
	.globl _get_fat
	.globl _clst2sect
	.globl _move_window
	.globl _ld_dword
	.globl _f_open
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\ff_fopen.c:43: FRESULT f_open (
;	---------------------------------
; Function f_open
; ---------------------------------
_f_open::
	call	___sdcc_enter_ix
	ld	hl,#-77
	add	hl,sp
	ld	sp,hl
;fatFs\ff_fopen.c:59: if (!fp) return FR_INVALID_OBJECT;
	ld	a,5 (ix)
	or	a,4 (ix)
	jr	NZ,00102$
	ld	l,#0x09
	jp	00165$
00102$:
;fatFs\ff_fopen.c:62: mode &= FF_FS_READONLY ? FA_READ : FA_READ | FA_WRITE | FA_CREATE_ALWAYS | FA_CREATE_NEW | FA_OPEN_ALWAYS | FA_OPEN_APPEND;
	ld	a,8 (ix)
	and	a, #0x3F
	ld	8 (ix),a
;fatFs\ff_fopen.c:66: res = find_volume(&fs, mode);
	ld	hl,#0x0031
	add	hl,sp
	ex	de,hl
	ld	a,8 (ix)
	push	af
	inc	sp
	push	de
	call	_find_volume
	pop	af
	inc	sp
	ld	-29 (ix),l
;fatFs\ff_fopen.c:153: fp->dir_sect = fs->winsect;			/* Pointer to the directory entry */
	ld	a,4 (ix)
	ld	-6 (ix),a
	ld	a,5 (ix)
	ld	-5 (ix),a
;fatFs\ff_fopen.c:68: if (res == FR_OK) {
	ld	a,-29 (ix)
	or	a, a
	jp	NZ,00158$
;fatFs\ff_fopen.c:69: dj.obj.fs = fs;
	ld	hl,#0x0008
	add	hl,sp
	ld	a,-28 (ix)
	ld	(hl),a
	inc	hl
	ld	a,-27 (ix)
	ld	(hl),a
;fatFs\ff_fopen.c:71: res = follow_path(&dj, path);	/* Follow the file path */
	ld	hl,#0x0008
	add	hl,sp
	push	hl
	ld	e,6 (ix)
	ld	d,7 (ix)
	push	de
	push	hl
	call	_follow_path
	pop	af
	pop	af
	pop	bc
;fatFs\ff_fopen.c:73: if (res == FR_OK) {
	ld	-29 (ix), l
	ld	a, l
	or	a, a
	jr	NZ,00106$
;fatFs\ff_fopen.c:74: if (dj.fn[NSFLAG] & NS_NONAME) {	/* Origin directory itself? */
	push	bc
	pop	iy
	ld	a,39 (iy)
	rlca
	jr	NC,00106$
;fatFs\ff_fopen.c:75: res = FR_INVALID_NAME;
	ld	-29 (ix),#0x06
00106$:
;fatFs\ff_fopen.c:96: if (dj.obj.attr & (AM_RDO | AM_DIR)) {	/* Cannot overwrite it (R/O or DIR) */
	push	bc
	pop	iy
;fatFs\ff_fopen.c:123: cl = ld_clust(fs, dj.dir);			/* Get current cluster chain */
	ld	hl,#0x001A
	add	hl,bc
	ld	-2 (ix),l
	ld	-1 (ix),h
;fatFs\ff_fopen.c:96: if (dj.obj.attr & (AM_RDO | AM_DIR)) {	/* Cannot overwrite it (R/O or DIR) */
	ld	l,4 (iy)
;fatFs\ff_fopen.c:84: if (mode & (FA_CREATE_ALWAYS | FA_OPEN_ALWAYS | FA_CREATE_NEW)) {
	ld	a,8 (ix)
	and	a, #0x1C
	jp	Z,00133$
;fatFs\ff_fopen.c:85: if (res != FR_OK) {					/* No file, create new */
	ld	a,-29 (ix)
	or	a, a
	jr	Z,00115$
;fatFs\ff_fopen.c:86: if (res == FR_NO_FILE) {		/* There is no file to open, create a new entry */
	ld	a,-29 (ix)
	sub	a, #0x04
	jr	NZ,00108$
;fatFs\ff_fopen.c:90: res = dir_register(&dj);
	ld	e, c
	ld	d, b
	ex	de,hl
	push	bc
	push	hl
	call	_dir_register
	pop	af
	pop	bc
	ld	-29 (ix),l
00108$:
;fatFs\ff_fopen.c:93: mode |= FA_CREATE_ALWAYS;		/* File is created */
	set	3, 8 (ix)
	jr	00116$
00115$:
;fatFs\ff_fopen.c:96: if (dj.obj.attr & (AM_RDO | AM_DIR)) {	/* Cannot overwrite it (R/O or DIR) */
	ld	a,l
	and	a, #0x11
	jr	Z,00112$
;fatFs\ff_fopen.c:97: res = FR_DENIED;
	ld	-29 (ix),#0x07
	jr	00116$
00112$:
;fatFs\ff_fopen.c:99: if (mode & FA_CREATE_NEW) res = FR_EXIST;	/* Cannot create as new file */
	bit	2, 8 (ix)
	jr	Z,00116$
	ld	-29 (ix),#0x08
00116$:
;fatFs\ff_fopen.c:102: if (res == FR_OK && (mode & FA_CREATE_ALWAYS)) {	/* Truncate the file if overwrite mode */
	ld	a,-29 (ix)
	or	a, a
	jp	NZ,00134$
	bit	3, 8 (ix)
	jp	Z,00134$
;fatFs\ff_fopen.c:123: cl = ld_clust(fs, dj.dir);			/* Get current cluster chain */
	ld	l,-2 (ix)
	ld	h,-1 (ix)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	push	bc
	push	de
	ld	l,-28 (ix)
	ld	h,-27 (ix)
	push	hl
	call	_ld_clust
	pop	af
	pop	af
	pop	bc
	ld	-73 (ix),l
	ld	-72 (ix),h
	ld	-71 (ix),e
	ld	-70 (ix),d
;fatFs\ff_fopen.c:124: st_dword(dj.dir + DIR_CrtTime, GET_FATTIME());	/* Set created time */
	ld	l,-2 (ix)
	ld	h,-1 (ix)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	hl,#0x000E
	add	hl,de
	ex	de,hl
	push	bc
	ld	hl,#0x4E21
	push	hl
	ld	hl,#0x0000
	push	hl
	push	de
	call	_st_dword
	pop	af
	pop	af
	pop	af
	pop	bc
;fatFs\ff_fopen.c:125: dj.dir[DIR_Attr] = AM_ARC;			/* Reset attribute */
	ld	l,-2 (ix)
	ld	h,-1 (ix)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	hl,#0x000B
	add	hl,de
	ld	(hl),#0x20
;fatFs\ff_fopen.c:126: st_clust(fs, dj.dir, 0);			/* Reset file allocation info */
	ld	l,-2 (ix)
	ld	h,-1 (ix)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	push	bc
	ld	hl,#0x0000
	push	hl
	ld	hl,#0x0000
	push	hl
	push	de
	ld	l,-28 (ix)
	ld	h,-27 (ix)
	push	hl
	call	_st_clust
	pop	af
	pop	af
	pop	af
	pop	af
	pop	bc
;fatFs\ff_fopen.c:127: st_dword(dj.dir + DIR_FileSize, 0);
	ld	l,-2 (ix)
	ld	h,-1 (ix)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	hl,#0x001C
	add	hl,de
	ex	de,hl
	push	bc
	ld	hl,#0x0000
	push	hl
	ld	hl,#0x0000
	push	hl
	push	de
	call	_st_dword
	pop	af
	pop	af
	pop	af
	pop	bc
;fatFs\ff_fopen.c:128: fs->wflag = 1;
	ld	l,-28 (ix)
	ld	h,-27 (ix)
	inc	hl
	inc	hl
	ld	(hl),#0x01
;fatFs\ff_fopen.c:129: if (cl != 0) {						/* Remove the cluster chain if exist */
	ld	a,-70 (ix)
	or	a, -71 (ix)
	or	a, -72 (ix)
	or	a,-73 (ix)
	jp	Z,00134$
;fatFs\ff_fopen.c:130: dw = fs->winsect;
	ld	l,-28 (ix)
	ld	h,-27 (ix)
	ld	de, #0x002A
	add	hl, de
	ld	a,(hl)
	ld	-22 (ix),a
	inc	hl
	ld	a,(hl)
	ld	-21 (ix),a
	inc	hl
	ld	a,(hl)
	ld	-20 (ix),a
	inc	hl
	ld	a,(hl)
	ld	-19 (ix),a
;fatFs\ff_fopen.c:131: res = remove_chain(&dj.obj, cl, 0);
	ld	hl,#0x0000
	push	hl
	ld	hl,#0x0000
	push	hl
	ld	l,-71 (ix)
	ld	h,-70 (ix)
	push	hl
	ld	l,-73 (ix)
	ld	h,-72 (ix)
	push	hl
	push	bc
	call	_remove_chain
	ld	iy,#10
	add	iy,sp
	ld	sp,iy
;fatFs\ff_fopen.c:132: if (res == FR_OK) {
	ld	-29 (ix), l
	ld	a, l
	or	a, a
	jr	NZ,00134$
;fatFs\ff_fopen.c:133: res = move_window(fs, dw);
	ld	l,-20 (ix)
	ld	h,-19 (ix)
	push	hl
	ld	l,-22 (ix)
	ld	h,-21 (ix)
	push	hl
	ld	l,-28 (ix)
	ld	h,-27 (ix)
	push	hl
	call	_move_window
	pop	af
	pop	af
	pop	af
	ld	-29 (ix),l
;fatFs\ff_fopen.c:134: fs->last_clst = cl - 1;		/* Reuse the cluster hole */
	ld	l,-28 (ix)
	ld	h,-27 (ix)
	ld	bc,#0x000A
	add	hl,bc
	ld	a,-73 (ix)
	add	a,#0xFF
	ld	e,a
	ld	a,-72 (ix)
	adc	a,#0xFF
	ld	d,a
	ld	a,-71 (ix)
	adc	a,#0xFF
	ld	c,a
	ld	a,-70 (ix)
	adc	a,#0xFF
	ld	b,a
	ld	(hl),e
	inc	hl
	ld	(hl),d
	inc	hl
	ld	(hl),c
	inc	hl
	ld	(hl),b
	jr	00134$
00133$:
;fatFs\ff_fopen.c:141: if (res == FR_OK) {					/* Is the object exsiting? */
	ld	a,-29 (ix)
	or	a, a
	jr	NZ,00134$
;fatFs\ff_fopen.c:142: if (dj.obj.attr & AM_DIR) {		/* File open against a directory */
	bit	4, l
	jr	Z,00128$
;fatFs\ff_fopen.c:143: res = FR_NO_FILE;
	ld	-29 (ix),#0x04
	jr	00134$
00128$:
;fatFs\ff_fopen.c:145: if ((mode & FA_WRITE) && (dj.obj.attr & AM_RDO)) { /* Write mode open against R/O file */
	bit	1, 8 (ix)
	jr	Z,00134$
	bit	0, l
	jr	Z,00134$
;fatFs\ff_fopen.c:146: res = FR_DENIED;
	ld	-29 (ix),#0x07
00134$:
;fatFs\ff_fopen.c:151: if (res == FR_OK) {
	ld	a,-29 (ix)
	or	a, a
	jr	NZ,00138$
;fatFs\ff_fopen.c:152: if (mode & FA_CREATE_ALWAYS) mode |= FA_MODIFIED;	/* Set file change flag if created or overwritten */
	bit	3, 8 (ix)
	jr	Z,00136$
	set	6, 8 (ix)
00136$:
;fatFs\ff_fopen.c:153: fp->dir_sect = fs->winsect;			/* Pointer to the directory entry */
	ld	a,-6 (ix)
	add	a, #0x1C
	ld	-18 (ix),a
	ld	a,-5 (ix)
	adc	a, #0x00
	ld	-17 (ix),a
	ld	l,-28 (ix)
	ld	h,-27 (ix)
	ld	de, #0x002A
	add	hl, de
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	inc	hl
	ld	b,(hl)
	inc	hl
	ld	c,(hl)
	ld	l,-18 (ix)
	ld	h,-17 (ix)
	ld	(hl),e
	inc	hl
	ld	(hl),d
	inc	hl
	ld	(hl),b
	inc	hl
	ld	(hl),c
;fatFs\ff_fopen.c:154: fp->dir_ptr = dj.dir;
	ld	a,-6 (ix)
	add	a, #0x20
	ld	d,a
	ld	a,-5 (ix)
	adc	a, #0x00
	ld	e,a
	ld	l,-2 (ix)
	ld	h,-1 (ix)
	ld	b,(hl)
	inc	hl
	ld	c,(hl)
	ld	l, d
	ld	h, e
	ld	(hl),b
	inc	hl
	ld	(hl),c
00138$:
;fatFs\ff_fopen.c:172: if (res == FR_OK) {
	ld	a,-29 (ix)
	or	a, a
	jp	NZ,00158$
;fatFs\ff_fopen.c:182: fp->obj.sclust = ld_clust(fs, dj.dir);					/* Get object allocation info */
	ld	a,-6 (ix)
	ld	-18 (ix),a
	ld	a,-5 (ix)
	ld	-17 (ix),a
	ld	a,-6 (ix)
	add	a, #0x06
	ld	-8 (ix),a
	ld	a,-5 (ix)
	adc	a, #0x00
	ld	-7 (ix),a
	ld	l,-2 (ix)
	ld	h,-1 (ix)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	push	de
	ld	l,-28 (ix)
	ld	h,-27 (ix)
	push	hl
	call	_ld_clust
	pop	af
	pop	af
	ld	c,l
	ld	b,h
	ld	l,-8 (ix)
	ld	h,-7 (ix)
	ld	(hl),c
	inc	hl
	ld	(hl),b
	inc	hl
	ld	(hl),e
	inc	hl
	ld	(hl),d
;fatFs\ff_fopen.c:183: fp->obj.objsize = ld_dword(dj.dir + DIR_FileSize);
	ld	a,-6 (ix)
	add	a, #0x0A
	ld	-10 (ix),a
	ld	a,-5 (ix)
	adc	a, #0x00
	ld	-9 (ix),a
	ld	l,-2 (ix)
	ld	h,-1 (ix)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	hl,#0x001C
	add	hl,de
	push	hl
	call	_ld_dword
	pop	af
	ld	c,l
	ld	b,h
	ld	l,-10 (ix)
	ld	h,-9 (ix)
	ld	(hl),c
	inc	hl
	ld	(hl),b
	inc	hl
	ld	(hl),e
	inc	hl
	ld	(hl),d
;fatFs\ff_fopen.c:188: fp->obj.fs = fs;	 	/* Validate the file object */
	ld	l,-6 (ix)
	ld	h,-5 (ix)
	ld	a,-28 (ix)
	ld	(hl),a
	inc	hl
	ld	a,-27 (ix)
	ld	(hl),a
;fatFs\ff_fopen.c:189: fp->obj.id = fs->id;
	ld	e,-6 (ix)
	ld	d,-5 (ix)
	inc	de
	inc	de
	ld	l,-28 (ix)
	ld	h,-27 (ix)
	ld	bc, #0x0004
	add	hl, bc
	ld	b,(hl)
	inc	hl
	ld	c,(hl)
	ld	a,b
	ld	(de),a
	inc	de
	ld	a,c
	ld	(de),a
;fatFs\ff_fopen.c:190: fp->flag = mode;		/* Set file access mode */
	ld	a,-6 (ix)
	add	a, #0x0E
	ld	l,a
	ld	a,-5 (ix)
	adc	a, #0x00
	ld	h,a
	ld	a,8 (ix)
	ld	(hl),a
;fatFs\ff_fopen.c:191: fp->err = 0;			/* Clear error flag */
	ld	a,-6 (ix)
	add	a, #0x0F
	ld	l,a
	ld	a,-5 (ix)
	adc	a, #0x00
	ld	h,a
	ld	(hl),#0x00
;fatFs\ff_fopen.c:192: fp->sect = 0;			/* Invalidate current data sector */
	ld	a,-6 (ix)
	add	a, #0x18
	ld	-2 (ix),a
	ld	a,-5 (ix)
	adc	a, #0x00
	ld	-1 (ix),a
	ld	l,-2 (ix)
	ld	h,-1 (ix)
	xor	a, a
	ld	(hl), a
	inc	hl
	ld	(hl), a
	inc	hl
	xor	a, a
	ld	(hl), a
	inc	hl
	ld	(hl), a
;fatFs\ff_fopen.c:193: fp->fptr = 0;			/* Set file pointer top of the file */
	ld	a,-6 (ix)
	add	a, #0x10
	ld	-4 (ix),a
	ld	a,-5 (ix)
	adc	a, #0x00
	ld	-3 (ix),a
	ld	l,-4 (ix)
	ld	h,-3 (ix)
	xor	a, a
	ld	(hl), a
	inc	hl
	ld	(hl), a
	inc	hl
	xor	a, a
	ld	(hl), a
	inc	hl
	ld	(hl), a
;fatFs\ff_fopen.c:196: memset(fp->buf, 0, sizeof fp->buf);	/* Clear sector buffer */
	ld	a,-6 (ix)
	add	a, #0x22
	ld	-12 (ix),a
	ld	a,-5 (ix)
	adc	a, #0x00
	ld	-11 (ix),a
	ld	l,-12 (ix)
	ld	h,-11 (ix)
	ld	bc,#0x0200
	push	bc
	ld	bc,#0x0000
	push	bc
	push	hl
	call	_memset
	pop	af
	pop	af
	pop	af
;fatFs\ff_fopen.c:198: if ((mode & FA_SEEKEND) && fp->obj.objsize > 0) {	/* Seek to end of file if FA_OPEN_APPEND is specified */
	bit	5, 8 (ix)
	jp	Z,00158$
	ld	l,-10 (ix)
	ld	h,-9 (ix)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	inc	hl
	ld	b,(hl)
	inc	hl
	ld	c,(hl)
	ld	a,c
	or	a, b
	or	a, d
	or	a,e
	jp	Z,00158$
;fatFs\ff_fopen.c:199: fp->fptr = fp->obj.objsize;			/* Offset to seek */
	ld	l,-4 (ix)
	ld	h,-3 (ix)
	ld	(hl),e
	inc	hl
	ld	(hl),d
	inc	hl
	ld	(hl),b
	inc	hl
	ld	(hl),c
;fatFs\ff_fopen.c:200: bcs = (DWORD)fs->csize * SS(fs);	/* Cluster size in byte */
	ld	l,-28 (ix)
	ld	h,-27 (ix)
	ld	de, #0x0008
	add	hl, de
	ld	c,(hl)
	inc	hl
	ld	b,(hl)
	ld	de,#0x0000
	ld	a,#0x09
00307$:
	sla	c
	rl	b
	rl	e
	rl	d
	dec	a
	jr	NZ,00307$
;fatFs\ff_fopen.c:201: clst = fp->obj.sclust;				/* Follow the cluster chain */
	push	de
	push	bc
	ld	e,-8 (ix)
	ld	d,-7 (ix)
	ld	hl, #0x0037
	add	hl, sp
	ex	de, hl
	ld	bc, #0x0004
	ldir
	pop	bc
	push	bc
	ld	e,-10 (ix)
	ld	d,-9 (ix)
	ld	hl, #0x0004
	add	hl, sp
	ex	de, hl
	ld	bc, #0x0004
	ldir
	pop	bc
	pop	de
00163$:
	ld	a,-29 (ix)
	or	a, a
	jp	NZ,00143$
	ld	a,c
	sub	a, -77 (ix)
	ld	a,b
	sbc	a, -76 (ix)
	ld	a,e
	sbc	a, -75 (ix)
	ld	a,d
	sbc	a, -74 (ix)
	jp	NC,00143$
;fatFs\ff_fopen.c:203: clst = get_fat(&fp->obj, clst);
	push	bc
	push	de
	ld	l,-24 (ix)
	ld	h,-23 (ix)
	push	hl
	ld	l,-26 (ix)
	ld	h,-25 (ix)
	push	hl
	ld	l,-18 (ix)
	ld	h,-17 (ix)
	push	hl
	call	_get_fat
	pop	af
	pop	af
	pop	af
	ld	-13 (ix),d
	ld	-14 (ix),e
	ld	-15 (ix),h
	ld	-16 (ix),l
	pop	de
	pop	bc
	push	de
	push	bc
	ld	hl, #55
	add	hl, sp
	ex	de, hl
	ld	hl, #65
	add	hl, sp
	ld	bc, #4
	ldir
	pop	bc
	pop	de
;fatFs\ff_fopen.c:204: if (clst <= 1) res = FR_INT_ERR;
	ld	a,#0x01
	cp	a, -26 (ix)
	ld	a,#0x00
	sbc	a, -25 (ix)
	ld	a,#0x00
	sbc	a, -24 (ix)
	ld	a,#0x00
	sbc	a, -23 (ix)
	jr	C,00140$
	ld	-29 (ix),#0x02
00140$:
;fatFs\ff_fopen.c:205: if (clst == 0xFFFFFFFF) res = FR_DISK_ERR;
	ld	a,-26 (ix)
	inc	a
	jr	NZ,00164$
	ld	a,-25 (ix)
	inc	a
	jr	NZ,00164$
	ld	a,-24 (ix)
	inc	a
	jr	NZ,00164$
	ld	a,-23 (ix)
	inc	a
	jr	NZ,00164$
	ld	-29 (ix),#0x01
00164$:
;fatFs\ff_fopen.c:202: for (ofs = fp->obj.objsize; res == FR_OK && ofs > bcs; ofs -= bcs) {
	ld	a,-77 (ix)
	sub	a, c
	ld	-77 (ix),a
	ld	a,-76 (ix)
	sbc	a, b
	ld	-76 (ix),a
	ld	a,-75 (ix)
	sbc	a, e
	ld	-75 (ix),a
	ld	a,-74 (ix)
	sbc	a, d
	ld	-74 (ix),a
	jp	00163$
00143$:
;fatFs\ff_fopen.c:207: fp->clust = clst;
	ld	a,-18 (ix)
	add	a, #0x14
	ld	e,a
	ld	a,-17 (ix)
	adc	a, #0x00
	ld	d,a
	ld	hl, #0x0033
	add	hl, sp
	ld	bc, #0x0004
	ldir
;fatFs\ff_fopen.c:208: if (res == FR_OK && ofs % SS(fs)) {	/* Fill sector buffer if not on the sector boundary */
	ld	a,-29 (ix)
	or	a, a
	jp	NZ,00158$
	ld	a,-77 (ix)
	or	a, a
	jr	NZ,00313$
	bit	0, -76 (ix)
	jp	Z,00158$
00313$:
;fatFs\ff_fopen.c:209: if ((sc = clst2sect(fs, clst)) == 0) {
	ld	l,-24 (ix)
	ld	h,-23 (ix)
	push	hl
	ld	l,-26 (ix)
	ld	h,-25 (ix)
	push	hl
	ld	l,-28 (ix)
	ld	h,-27 (ix)
	push	hl
	call	_clst2sect
	pop	af
	pop	af
	pop	af
	ld	-16 (ix),l
	ld	-15 (ix),h
	ld	-14 (ix),e
	ld	-13 (ix),d
	ld	a,d
	or	a, e
	or	a, h
	or	a,l
	jr	NZ,00147$
;fatFs\ff_fopen.c:210: res = FR_INT_ERR;
	ld	-29 (ix),#0x02
	jr	00158$
00147$:
;fatFs\ff_fopen.c:212: fp->sect = sc + (DWORD)(ofs / SS(fs));
	push	af
	ld	l,-77 (ix)
	ld	h,-76 (ix)
	ld	e,-75 (ix)
	ld	d,-74 (ix)
	pop	af
	ld	b,#0x09
00314$:
	srl	d
	rr	e
	rr	h
	rr	l
	djnz	00314$
	ld	a,-16 (ix)
	add	a, l
	ld	c,a
	ld	a,-15 (ix)
	adc	a, h
	ld	b,a
	ld	a,-14 (ix)
	adc	a, e
	ld	e,a
	ld	a,-13 (ix)
	adc	a, d
	ld	d,a
	ld	l,-2 (ix)
	ld	h,-1 (ix)
	ld	(hl),c
	inc	hl
	ld	(hl),b
	inc	hl
	ld	(hl),e
	inc	hl
	ld	(hl),d
;fatFs\ff_fopen.c:217: if (disk_read(fp->buf, fp->sect, 1) != RES_OK) res = FR_DISK_ERR;
	ld	hl,#0x0001
	push	hl
	push	de
	push	bc
	ld	l,-12 (ix)
	ld	h,-11 (ix)
	push	hl
	call	_disk_read
	pop	af
	pop	af
	pop	af
	pop	af
	ld	a,l
	or	a, a
	jr	Z,00158$
	ld	-29 (ix),#0x01
00158$:
;fatFs\ff_fopen.c:229: if (res != FR_OK) fp->obj.fs = 0;	/* Invalidate file object on error */
	ld	a,-29 (ix)
	or	a, a
	jr	Z,00160$
	ld	l,-6 (ix)
	ld	h,-5 (ix)
	xor	a, a
	ld	(hl), a
	inc	hl
	ld	(hl), a
00160$:
;fatFs\ff_fopen.c:231: LEAVE_FF(fs, res);
	ld	l,-29 (ix)
00165$:
	ld	sp, ix
	pop	ix
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
