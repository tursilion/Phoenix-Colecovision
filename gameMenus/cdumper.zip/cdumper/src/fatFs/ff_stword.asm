;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 3.5.0 #9253 (Jun 20 2015) (MINGW64)
; This file was generated Thu Sep 12 23:57:58 2019
;--------------------------------------------------------
	.module ff_stword
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _st_word
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\ff_stword.c:39: void st_word (BYTE* ptr, WORD val)	/* Store a 2-byte word in little-endian */
;	---------------------------------
; Function st_word
; ---------------------------------
_st_word::
	call	___sdcc_enter_ix
;fatFs\ff_stword.c:41: *ptr++ = (BYTE)val; val >>= 8;
	ld	l,4 (ix)
	ld	h,5 (ix)
	ld	a,6 (ix)
	ld	(hl),a
	inc	hl
	ld	4 (ix),l
	ld	5 (ix),h
	ld	a,7 (ix)
	ld	6 (ix),a
	ld	7 (ix),#0x00
;fatFs\ff_stword.c:42: *ptr++ = (BYTE)val;
	ld	l,4 (ix)
	ld	h,5 (ix)
	ld	a,6 (ix)
	ld	(hl),a
	pop	ix
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
