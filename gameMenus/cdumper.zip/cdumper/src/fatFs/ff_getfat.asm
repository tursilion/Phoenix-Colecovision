;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 3.5.0 #9253 (Jun 20 2015) (MINGW64)
; This file was generated Fri Sep 13 01:07:32 2019
;--------------------------------------------------------
	.module ff_getfat
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _move_window
	.globl _ld_dword
	.globl _get_fat
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\ff_getfat.c:42: DWORD get_fat (		/* 0xFFFFFFFF:Disk error, 1:Internal error, 2..0x7FFFFFFF:Cluster status */
;	---------------------------------
; Function get_fat
; ---------------------------------
_get_fat::
	call	___sdcc_enter_ix
	push	af
	push	af
	push	af
	push	af
;fatFs\ff_getfat.c:51: FATFS *fs = obj->fs;
	ld	l,4 (ix)
	ld	h,5 (ix)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
;fatFs\ff_getfat.c:54: if (clst < 2 || clst >= fs->n_fatent) {	/* Check if in valid range */
	ld	a,6 (ix)
	sub	a, #0x02
	ld	a,7 (ix)
	sbc	a, #0x00
	ld	a,8 (ix)
	sbc	a, #0x00
	ld	a,9 (ix)
	sbc	a, #0x00
	jr	C,00109$
	push	de
	pop	iy
	ld	l,18 (iy)
	ld	h,19 (iy)
	ld	c,20 (iy)
	ld	b,21 (iy)
	ld	a,6 (ix)
	sub	a, l
	ld	a,7 (ix)
	sbc	a, h
	ld	a,8 (ix)
	sbc	a, c
	ld	a,9 (ix)
	sbc	a, b
	jr	C,00110$
00109$:
;fatFs\ff_getfat.c:55: val = 1;	/* Internal error */
	ld	-4 (ix),#0x01
	xor	a, a
	ld	-3 (ix),a
	ld	-2 (ix),a
	ld	-1 (ix),a
	jp	00111$
00110$:
;fatFs\ff_getfat.c:58: val = 0xFFFFFFFF;	/* Default value falls on disk error */
	ld	-4 (ix),#0xFF
	ld	-3 (ix),#0xFF
	ld	-2 (ix),#0xFF
	ld	-1 (ix),#0xFF
;fatFs\ff_getfat.c:60: switch (fs->fs_type) {
	ld	a,(de)
	ld	c,a
;fatFs\ff_getfat.c:73: if (move_window(fs, fs->fatbase + (clst / (SS(fs) / 2))) != FR_OK) {
	push	de
	pop	iy
	ld	a,30 (iy)
	ld	-8 (ix),a
	ld	a,31 (iy)
	ld	-7 (ix),a
	ld	a,32 (iy)
	ld	-6 (ix),a
	ld	a,33 (iy)
	ld	-5 (ix),a
;fatFs\ff_getfat.c:60: switch (fs->fs_type) {
	ld	a,c
	sub	a, #0x02
	jr	Z,00101$
	ld	a,c
	sub	a, #0x03
	jp	Z,00104$
	jp	00107$
;fatFs\ff_getfat.c:72: case FS_FAT16 :
00101$:
;fatFs\ff_getfat.c:73: if (move_window(fs, fs->fatbase + (clst / (SS(fs) / 2))) != FR_OK) {
	push	af
	ld	c,6 (ix)
	ld	b,7 (ix)
	ld	l,8 (ix)
	ld	h,9 (ix)
	pop	af
	ld	a,#0x08
00137$:
	srl	h
	rr	l
	rr	b
	rr	c
	dec	a
	jr	NZ,00137$
	ld	a,-8 (ix)
	add	a, c
	ld	c,a
	ld	a,-7 (ix)
	adc	a, b
	ld	b,a
	ld	a,-6 (ix)
	adc	a, l
	ld	l,a
	ld	a,-5 (ix)
	adc	a, h
	ld	h,a
	push	de
	push	hl
	push	bc
	push	de
	call	_move_window
	pop	af
	pop	af
	pop	af
	ld	a,l
	pop	de
	or	a, a
	jp	NZ,00111$
;fatFs\ff_getfat.c:77: val = ld_word(fs->win + clst * 2 % SS(fs));		/* Simple WORD array */
	ld	hl,#0x002E
	add	hl,de
	ex	de,hl
	push	af
	ld	c,6 (ix)
	ld	b,7 (ix)
	ld	l,8 (ix)
	ld	h,9 (ix)
	pop	af
	sla	c
	rl	b
	adc	hl, hl
	ld	a,b
	and	a, #0x01
	ld	b,a
	ld	a,c
	add	a, e
	ld	c,a
	ld	a,b
	adc	a, d
	ld	b,a
	ld	l, c
	ld	h, b
	inc	hl
	ld	d, (hl)
	ld	e,#0x00
	ld	a,(bc)
	ld	l,a
	ld	h,#0x00
	ld	a,l
	or	a, e
	ld	l,a
	ld	a,h
	or	a, d
	ld	h,a
	ld	-4 (ix),l
	ld	-3 (ix),h
	ld	a,h
	rla
	sbc	a, a
	ld	-2 (ix),a
	ld	-1 (ix),a
;fatFs\ff_getfat.c:78: break;
	jp	00111$
;fatFs\ff_getfat.c:80: case FS_FAT32 :
00104$:
;fatFs\ff_getfat.c:81: if (move_window(fs, fs->fatbase + (clst / (SS(fs) / 4))) != FR_OK) break;
	push	af
	ld	c,6 (ix)
	ld	b,7 (ix)
	ld	l,8 (ix)
	ld	h,9 (ix)
	pop	af
	ld	a,#0x07
00141$:
	srl	h
	rr	l
	rr	b
	rr	c
	dec	a
	jr	NZ,00141$
	ld	a,-8 (ix)
	add	a, c
	ld	c,a
	ld	a,-7 (ix)
	adc	a, b
	ld	b,a
	ld	a,-6 (ix)
	adc	a, l
	ld	l,a
	ld	a,-5 (ix)
	adc	a, h
	ld	h,a
	push	de
	push	hl
	push	bc
	push	de
	call	_move_window
	pop	af
	pop	af
	pop	af
	ld	a,l
	pop	de
	or	a, a
	jr	NZ,00111$
;fatFs\ff_getfat.c:82: val = ld_dword(fs->win + clst * 4 % SS(fs)) & 0x0FFFFFFF;	/* Simple DWORD array but mask out upper 4 bits */
	ld	hl,#0x002E
	add	hl,de
	ex	de,hl
	push	af
	ld	l,6 (ix)
	ld	h,7 (ix)
	ld	c,8 (ix)
	ld	b,9 (ix)
	pop	af
	ld	a,#0x02
00143$:
	add	hl, hl
	rl	c
	rl	b
	dec	a
	jr	NZ,00143$
	ld	a,h
	and	a, #0x01
	ld	h,a
	add	hl,de
	push	hl
	call	_ld_dword
	pop	af
	ld	-4 (ix),l
	ld	-3 (ix),h
	ld	-2 (ix),e
	ld	a,d
	and	a, #0x0F
	ld	-1 (ix),a
;fatFs\ff_getfat.c:83: break;
	jr	00111$
;fatFs\ff_getfat.c:110: default:
00107$:
;fatFs\ff_getfat.c:111: val = 1;	/* Internal error */
	ld	-4 (ix),#0x01
	xor	a, a
	ld	-3 (ix),a
	ld	-2 (ix),a
	ld	-1 (ix),a
;fatFs\ff_getfat.c:112: }
00111$:
;fatFs\ff_getfat.c:114: return val;
	ld	l,-4 (ix)
	ld	h,-3 (ix)
	ld	e,-2 (ix)
	ld	d,-1 (ix)
	ld	sp, ix
	pop	ix
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
