;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 3.5.0 #9253 (Jun 20 2015) (MINGW64)
; This file was generated Thu Sep 12 23:57:57 2019
;--------------------------------------------------------
	.module ff_removechain
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _put_fat
	.globl _get_fat
	.globl _remove_chain
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\ff_removechain.c:43: FRESULT remove_chain (	/* FR_OK(0):succeeded, !=0:error */
;	---------------------------------
; Function remove_chain
; ---------------------------------
_remove_chain::
	call	___sdcc_enter_ix
	ld	hl,#-12
	add	hl,sp
	ld	sp,hl
;fatFs\ff_removechain.c:51: FATFS *fs = obj->fs;
	ld	a,4 (ix)
	ld	-4 (ix),a
	ld	a,5 (ix)
	ld	-3 (ix),a
	ld	l,-4 (ix)
	ld	h,-3 (ix)
	ld	c,(hl)
	inc	hl
	ld	b,(hl)
;fatFs\ff_removechain.c:59: if (clst < 2 || clst >= fs->n_fatent) return FR_INT_ERR;	/* Check if in valid range */
	ld	a,6 (ix)
	sub	a, #0x02
	ld	a,7 (ix)
	sbc	a, #0x00
	ld	a,8 (ix)
	sbc	a, #0x00
	ld	a,9 (ix)
	sbc	a, #0x00
	jr	C,00101$
	ld	hl,#0x0012
	add	hl,bc
	ld	-2 (ix),l
	ld	-1 (ix),h
	ld	l,-2 (ix)
	ld	h,-1 (ix)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	inc	hl
	inc	hl
	ld	a,(hl)
	dec	hl
	ld	h,(hl)
	ld	l,a
	ld	a,6 (ix)
	sub	a, e
	ld	a,7 (ix)
	sbc	a, d
	ld	a,8 (ix)
	sbc	a, h
	ld	a,9 (ix)
	sbc	a, l
	jr	C,00102$
00101$:
	ld	l,#0x02
	jp	00127$
00102$:
;fatFs\ff_removechain.c:62: if (pclst != 0 && (!FF_FS_EXFAT || fs->fs_type != FS_EXFAT || obj->stat != 2)) {
	ld	a,13 (ix)
	or	a, 12 (ix)
	or	a, 11 (ix)
	or	a,10 (ix)
	jr	Z,00124$
;fatFs\ff_removechain.c:63: res = put_fat(fs, pclst, 0xFFFFFFFF);
	push	bc
	ld	hl,#0xFFFF
	push	hl
	ld	hl,#0xFFFF
	push	hl
	ld	l,12 (ix)
	ld	h,13 (ix)
	push	hl
	ld	l,10 (ix)
	ld	h,11 (ix)
	push	hl
	push	bc
	call	_put_fat
	ld	iy,#10
	add	iy,sp
	ld	sp,iy
	pop	bc
;fatFs\ff_removechain.c:64: if (res != FR_OK) return res;
	ld	a,l
	or	a, a
;fatFs\ff_removechain.c:68: do {
	jp	NZ,00127$
00124$:
;fatFs\ff_removechain.c:69: nxt = get_fat(obj, clst);			/* Get cluster status */
	push	bc
	ld	l,8 (ix)
	ld	h,9 (ix)
	push	hl
	ld	l,6 (ix)
	ld	h,7 (ix)
	push	hl
	ld	l,-4 (ix)
	ld	h,-3 (ix)
	push	hl
	call	_get_fat
	pop	af
	pop	af
	pop	af
	pop	bc
	ld	-12 (ix),l
	ld	-11 (ix),h
	ld	-10 (ix),e
;fatFs\ff_removechain.c:70: if (nxt == 0) break;				/* Empty cluster? */
	ld	-9 (ix), d
	ld	a, d
	or	a, -10 (ix)
	or	a, -11 (ix)
	or	a,-12 (ix)
	jp	Z,00126$
;fatFs\ff_removechain.c:71: if (nxt == 1) return FR_INT_ERR;	/* Internal error? */
	ld	a,-12 (ix)
	dec	a
	jr	NZ,00114$
	ld	a,-11 (ix)
	or	a, a
	jr	NZ,00114$
	ld	a,-10 (ix)
	or	a, a
	jr	NZ,00114$
	ld	a,-9 (ix)
	or	a, a
	jr	NZ,00114$
	ld	l,#0x02
	jp	00127$
00114$:
;fatFs\ff_removechain.c:72: if (nxt == 0xFFFFFFFF) return FR_DISK_ERR;	/* Disk error? */
	ld	a,-12 (ix)
	inc	a
	jr	NZ,00119$
	ld	a,-11 (ix)
	inc	a
	jr	NZ,00119$
	ld	a,-10 (ix)
	inc	a
	jr	NZ,00119$
	ld	a,-9 (ix)
	inc	a
	jr	NZ,00119$
	ld	l,#0x01
	jp	00127$
;fatFs\ff_removechain.c:73: if (!FF_FS_EXFAT || fs->fs_type != FS_EXFAT) {
00119$:
;fatFs\ff_removechain.c:74: res = put_fat(fs, clst, 0);		/* Mark the cluster 'free' on the FAT */
	push	bc
	ld	hl,#0x0000
	push	hl
	ld	hl,#0x0000
	push	hl
	ld	l,8 (ix)
	ld	h,9 (ix)
	push	hl
	ld	l,6 (ix)
	ld	h,7 (ix)
	push	hl
	push	bc
	call	_put_fat
	ld	iy,#10
	add	iy,sp
	ld	sp,iy
	pop	bc
;fatFs\ff_removechain.c:75: if (res != FR_OK) return res;
	ld	a,l
	or	a, a
	jp	NZ,00127$
;fatFs\ff_removechain.c:77: if (fs->free_clst < fs->n_fatent - 2) {	/* Update FSINFO */
	ld	iy,#0x000E
	add	iy, bc
	ld	a,0 (iy)
	ld	-8 (ix),a
	ld	a,1 (iy)
	ld	-7 (ix),a
	ld	a,2 (iy)
	ld	-6 (ix),a
	ld	a,3 (iy)
	ld	-5 (ix),a
	ld	l,-2 (ix)
	ld	h,-1 (ix)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	inc	hl
	inc	hl
	ld	a,(hl)
	dec	hl
	ld	l,(hl)
	ld	h,a
	ld	a,e
	add	a,#0xFE
	ld	e,a
	ld	a,d
	adc	a,#0xFF
	ld	d,a
	ld	a,l
	adc	a,#0xFF
	ld	l,a
	ld	a,h
	adc	a,#0xFF
	ld	h,a
	ld	a,-8 (ix)
	sub	a, e
	ld	a,-7 (ix)
	sbc	a, d
	ld	a,-6 (ix)
	sbc	a, l
	ld	a,-5 (ix)
	sbc	a, h
	jr	NC,00123$
;fatFs\ff_removechain.c:78: fs->free_clst++;
	ld	a,-8 (ix)
	add	a, #0x01
	ld	h,a
	ld	a,-7 (ix)
	adc	a, #0x00
	ld	l,a
	ld	a,-6 (ix)
	adc	a, #0x00
	ld	e,a
	ld	a,-5 (ix)
	adc	a, #0x00
	ld	d,a
	ld	0 (iy),h
	ld	1 (iy),l
	ld	2 (iy),e
	ld	3 (iy),d
;fatFs\ff_removechain.c:79: fs->fsi_flag |= 1;
	ld	l, c
	ld	h, b
	inc	hl
	inc	hl
	inc	hl
	set	0, (hl)
	ld	a, (hl)
00123$:
;fatFs\ff_removechain.c:99: clst = nxt;					/* Next cluster */
	push	bc
	ld	hl, #20
	add	hl, sp
	ex	de, hl
	ld	hl, #2
	add	hl, sp
	ld	bc, #4
	ldir
	pop	bc
;fatFs\ff_removechain.c:100: } while (clst < fs->n_fatent);	/* Repeat while not the last link */
	ld	l,-2 (ix)
	ld	h,-1 (ix)
	ld	d,(hl)
	inc	hl
	ld	e,(hl)
	inc	hl
	inc	hl
	ld	a,(hl)
	dec	hl
	ld	h,(hl)
	ld	l,a
	ld	a,-12 (ix)
	sub	a, d
	ld	a,-11 (ix)
	sbc	a, e
	ld	a,-10 (ix)
	sbc	a, h
	ld	a,-9 (ix)
	sbc	a, l
	jp	C,00124$
00126$:
;fatFs\ff_removechain.c:128: return FR_OK;
	ld	l,#0x00
00127$:
	ld	sp, ix
	pop	ix
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
