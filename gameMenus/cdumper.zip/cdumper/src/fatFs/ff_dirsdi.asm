;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 3.5.0 #9253 (Jun 20 2015) (MINGW64)
; This file was generated Thu Sep 12 23:57:30 2019
;--------------------------------------------------------
	.module ff_dirsdi
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _get_fat
	.globl _clst2sect
	.globl _dir_sdi
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\ff_dirsdi.c:42: FRESULT dir_sdi (	/* FR_OK(0):succeeded, !=0:error */
;	---------------------------------
; Function dir_sdi
; ---------------------------------
_dir_sdi::
	call	___sdcc_enter_ix
	ld	hl,#-22
	add	hl,sp
	ld	sp,hl
;fatFs\ff_dirsdi.c:48: FATFS *fs = dp->obj.fs;
	ld	a,4 (ix)
	ld	-8 (ix),a
	ld	a,5 (ix)
	ld	-7 (ix),a
	ld	l,-8 (ix)
	ld	h,-7 (ix)
	ld	a,(hl)
	ld	-14 (ix),a
	inc	hl
	ld	a,(hl)
	ld	-13 (ix),a
;fatFs\ff_dirsdi.c:51: if (ofs >= (DWORD)((FF_FS_EXFAT && fs->fs_type == FS_EXFAT) ? MAX_DIR_EX : MAX_DIR) || ofs % SZDIRE) {	/* Check range of offset and alignment */
	ld	a,8 (ix)
	sub	a, #0x20
	ld	a,9 (ix)
	sbc	a, #0x00
	jr	NC,00101$
	ld	a,6 (ix)
	and	a, #0x1F
	jr	Z,00102$
00101$:
;fatFs\ff_dirsdi.c:52: return FR_INT_ERR;
	ld	l,#0x02
	jp	00124$
00102$:
;fatFs\ff_dirsdi.c:54: dp->dptr = ofs;				/* Set current offset */
	ld	a,-8 (ix)
	add	a, #0x0E
	ld	e,a
	ld	a,-7 (ix)
	adc	a, #0x00
	ld	d,a
	ld	hl, #0x001C
	add	hl, sp
	ld	bc, #0x0004
	ldir
;fatFs\ff_dirsdi.c:55: clst = dp->obj.sclust;		/* Table start cluster (0:root) */
	ld	l,-8 (ix)
	ld	h,-7 (ix)
	ld	de, #0x0006
	add	hl, de
	ld	a,(hl)
	ld	-18 (ix),a
	inc	hl
	ld	a,(hl)
	ld	-17 (ix),a
	inc	hl
	ld	a,(hl)
	ld	-16 (ix),a
	inc	hl
	ld	a,(hl)
	ld	-15 (ix),a
;fatFs\ff_dirsdi.c:57: clst = fs->dirbase;
	ld	l,-14 (ix)
	ld	h,-13 (ix)
	ld	de, #0x0022
	add	hl, de
	ld	a,(hl)
	ld	-6 (ix),a
	inc	hl
	ld	a,(hl)
	ld	-5 (ix),a
	inc	hl
	ld	a,(hl)
	ld	-4 (ix),a
	inc	hl
	ld	a,(hl)
	ld	-3 (ix),a
;fatFs\ff_dirsdi.c:56: if (clst == 0 && fs->fs_type >= FS_FAT32) {	/* Replace cluster# 0 with root cluster# */
	ld	a,-15 (ix)
	or	a, -16 (ix)
	or	a, -17 (ix)
	or	a,-18 (ix)
	jr	NZ,00107$
	ld	l,-14 (ix)
	ld	h,-13 (ix)
	ld	a, (hl)
	sub	a, #0x03
	jr	C,00107$
;fatFs\ff_dirsdi.c:57: clst = fs->dirbase;
	ld	hl, #4
	add	hl, sp
	ex	de, hl
	ld	hl, #16
	add	hl, sp
	ld	bc, #4
	ldir
;fatFs\ff_dirsdi.c:58: if (FF_FS_EXFAT) dp->obj.stat = 0;	/* exFAT: Root dir has an FAT chain */
00107$:
;fatFs\ff_dirsdi.c:63: dp->sect = fs->dirbase;
	ld	a,-8 (ix)
	add	a, #0x16
	ld	-2 (ix),a
	ld	a,-7 (ix)
	adc	a, #0x00
	ld	-1 (ix),a
;fatFs\ff_dirsdi.c:61: if (clst == 0) {	/* table (root-directory on the FAT volume) */
	ld	a,-15 (ix)
	or	a, -16 (ix)
	or	a, -17 (ix)
	or	a,-18 (ix)
	jr	NZ,00120$
;fatFs\ff_dirsdi.c:62: if (ofs / SZDIRE >= fs->n_rootdir) return FR_INT_ERR;	/* Is index out of range? */
	push	af
	ld	e,6 (ix)
	ld	d,7 (ix)
	ld	c,8 (ix)
	ld	b,9 (ix)
	pop	af
	ld	a,#0x05
00173$:
	srl	b
	rr	c
	rr	d
	rr	e
	dec	a
	jr	NZ,00173$
	ld	l,-14 (ix)
	ld	h,-13 (ix)
	push	bc
	ld	bc, #0x0006
	add	hl, bc
	pop	bc
	ld	a, (hl)
	inc	hl
	ld	h,(hl)
	ld	-12 (ix), a
	ld	-11 (ix),h
	ld	-10 (ix),#0x00
	ld	-9 (ix),#0x00
	ld	a,e
	sub	a, -12 (ix)
	ld	a,d
	sbc	a, -11 (ix)
	ld	a,c
	sbc	a, -10 (ix)
	ld	a,b
	sbc	a, -9 (ix)
	jr	C,00110$
	ld	l,#0x02
	jp	00124$
00110$:
;fatFs\ff_dirsdi.c:63: dp->sect = fs->dirbase;
	ld	e,-2 (ix)
	ld	d,-1 (ix)
	ld	hl, #0x0010
	add	hl, sp
	ld	bc, #0x0004
	ldir
	jp	00121$
00120$:
;fatFs\ff_dirsdi.c:65: csz = (DWORD)fs->csize * SS(fs);	/* Bytes per cluster */
	ld	l,-14 (ix)
	ld	h,-13 (ix)
	ld	de, #0x0008
	add	hl, de
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	hl,#0x0000
	push	af
	ld	-22 (ix),e
	ld	-21 (ix),d
	ld	-20 (ix),l
	ld	-19 (ix),h
	pop	af
	ld	a,#0x09
00175$:
	sla	-22 (ix)
	rl	-21 (ix)
	rl	-20 (ix)
	rl	-19 (ix)
	dec	a
	jr	NZ,00175$
;fatFs\ff_dirsdi.c:66: while (ofs >= csz) {				/* Follow cluster chain */
	ld	c,-14 (ix)
	ld	b,-13 (ix)
00116$:
	ld	a,6 (ix)
	sub	a, -22 (ix)
	ld	a,7 (ix)
	sbc	a, -21 (ix)
	ld	a,8 (ix)
	sbc	a, -20 (ix)
	ld	a,9 (ix)
	sbc	a, -19 (ix)
	jp	C,00118$
;fatFs\ff_dirsdi.c:67: clst = get_fat(&dp->obj, clst);				/* Get next cluster */
	push	bc
	ld	l,-16 (ix)
	ld	h,-15 (ix)
	push	hl
	ld	l,-18 (ix)
	ld	h,-17 (ix)
	push	hl
	ld	l,-8 (ix)
	ld	h,-7 (ix)
	push	hl
	call	_get_fat
	pop	af
	pop	af
	pop	af
	pop	bc
	ld	-18 (ix),l
	ld	-17 (ix),h
	ld	-16 (ix),e
	ld	-15 (ix),d
;fatFs\ff_dirsdi.c:68: if (clst == 0xFFFFFFFF) return FR_DISK_ERR;	/* Disk error */
	ld	a,-18 (ix)
	inc	a
	jr	NZ,00112$
	ld	a,-17 (ix)
	inc	a
	jr	NZ,00112$
	ld	a,-16 (ix)
	inc	a
	jr	NZ,00112$
	ld	a,-15 (ix)
	inc	a
	jr	NZ,00112$
	ld	l,#0x01
	jp	00124$
00112$:
;fatFs\ff_dirsdi.c:69: if (clst < 2 || clst >= fs->n_fatent) return FR_INT_ERR;	/* Reached to end of table or internal error */
	ld	a,-18 (ix)
	sub	a, #0x02
	ld	a,-17 (ix)
	sbc	a, #0x00
	ld	a,-16 (ix)
	sbc	a, #0x00
	ld	a,-15 (ix)
	sbc	a, #0x00
	jr	C,00113$
	ld	l, c
	ld	h, b
	ld	de, #0x0012
	add	hl, de
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	inc	hl
	inc	hl
	ld	a,(hl)
	dec	hl
	ld	h,(hl)
	ld	l,a
	ld	a,-18 (ix)
	sub	a, e
	ld	a,-17 (ix)
	sbc	a, d
	ld	a,-16 (ix)
	sbc	a, h
	ld	a,-15 (ix)
	sbc	a, l
	jr	C,00114$
00113$:
	ld	l,#0x02
	jp	00124$
00114$:
;fatFs\ff_dirsdi.c:70: ofs -= csz;
	ld	a,6 (ix)
	sub	a, -22 (ix)
	ld	6 (ix),a
	ld	a,7 (ix)
	sbc	a, -21 (ix)
	ld	7 (ix),a
	ld	a,8 (ix)
	sbc	a, -20 (ix)
	ld	8 (ix),a
	ld	a,9 (ix)
	sbc	a, -19 (ix)
	ld	9 (ix),a
	jp	00116$
00118$:
;fatFs\ff_dirsdi.c:72: dp->sect = clst2sect(fs, clst);
	ld	l,-16 (ix)
	ld	h,-15 (ix)
	push	hl
	ld	l,-18 (ix)
	ld	h,-17 (ix)
	push	hl
	ld	l,-14 (ix)
	ld	h,-13 (ix)
	push	hl
	call	_clst2sect
	pop	af
	pop	af
	pop	af
	ld	b,l
	ld	c,h
	ld	l,-2 (ix)
	ld	h,-1 (ix)
	ld	(hl),b
	inc	hl
	ld	(hl),c
	inc	hl
	ld	(hl),e
	inc	hl
	ld	(hl),d
00121$:
;fatFs\ff_dirsdi.c:74: dp->clust = clst;					/* Current cluster# */
	ld	a,-8 (ix)
	add	a, #0x12
	ld	e,a
	ld	a,-7 (ix)
	adc	a, #0x00
	ld	d,a
	ld	hl, #0x0004
	add	hl, sp
	ld	bc, #0x0004
	ldir
;fatFs\ff_dirsdi.c:75: if (dp->sect == 0) return FR_INT_ERR;
	ld	e,-2 (ix)
	ld	d,-1 (ix)
	ld	hl, #0x000A
	add	hl, sp
	ex	de, hl
	ld	bc, #0x0004
	ldir
	ld	a,-9 (ix)
	or	a, -10 (ix)
	or	a, -11 (ix)
	or	a,-12 (ix)
	jr	NZ,00123$
	ld	l,#0x02
	jp	00124$
00123$:
;fatFs\ff_dirsdi.c:76: dp->sect += ofs / SS(fs);			/* Sector# of the directory entry */
	push	af
	ld	l,6 (ix)
	ld	h,7 (ix)
	ld	e,8 (ix)
	ld	d,9 (ix)
	pop	af
	ld	b,#0x09
00179$:
	srl	d
	rr	e
	rr	h
	rr	l
	djnz	00179$
	ld	a,-12 (ix)
	add	a, l
	ld	c,a
	ld	a,-11 (ix)
	adc	a, h
	ld	b,a
	ld	a,-10 (ix)
	adc	a, e
	ld	e,a
	ld	a,-9 (ix)
	adc	a, d
	ld	d,a
	ld	l,-2 (ix)
	ld	h,-1 (ix)
	ld	(hl),c
	inc	hl
	ld	(hl),b
	inc	hl
	ld	(hl),e
	inc	hl
	ld	(hl),d
;fatFs\ff_dirsdi.c:77: dp->dir = fs->win + (ofs % SS(fs));	/* Pointer to the entry in the win[] */
	ld	a,-8 (ix)
	add	a, #0x1A
	ld	-12 (ix),a
	ld	a,-7 (ix)
	adc	a, #0x00
	ld	-11 (ix),a
	ld	a,-14 (ix)
	add	a, #0x2E
	ld	-2 (ix),a
	ld	a,-13 (ix)
	adc	a, #0x00
	ld	-1 (ix),a
	ld	a,6 (ix)
	ld	-6 (ix),a
	ld	a,7 (ix)
	and	a, #0x01
	ld	-5 (ix),a
	ld	-4 (ix),#0x00
	ld	-3 (ix),#0x00
	ld	a,-2 (ix)
	add	a, -6 (ix)
	ld	-2 (ix),a
	ld	a,-1 (ix)
	adc	a, -5 (ix)
	ld	-1 (ix),a
	ld	l,-12 (ix)
	ld	h,-11 (ix)
	ld	a,-2 (ix)
	ld	(hl),a
	inc	hl
	ld	a,-1 (ix)
	ld	(hl),a
;fatFs\ff_dirsdi.c:79: return FR_OK;
	ld	l,#0x00
00124$:
	ld	sp, ix
	pop	ix
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
