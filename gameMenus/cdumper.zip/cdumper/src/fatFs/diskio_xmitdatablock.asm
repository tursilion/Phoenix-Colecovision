;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 3.5.0 #9253 (Jun 20 2015) (MINGW64)
; This file was generated Thu Sep 12 23:57:21 2019
;--------------------------------------------------------
	.module diskio_xmitdatablock
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _wait_ready
	.globl _rcvr_mmc
	.globl _xmit_mmc
	.globl _xmit_datablock
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
_sgmPSGAddressWrite	=	0x0050
_sgmPSGDataWrite	=	0x0051
_sgmPSGDataRead	=	0x0052
_sgmConfig	=	0x0053
_phRAMBankSelect	=	0x0054
_phBankingScheme	=	0x0055
_phSDControl	=	0x0056
_phSDData	=	0x0057
_phMachineID	=	0x0058
_phCartMask	=	0x0059
_sgmBIOSMap	=	0x007f
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\diskio_xmitdatablock.c:27: int xmit_datablock (	/* 1:OK, 0:Failed */
;	---------------------------------
; Function xmit_datablock
; ---------------------------------
_xmit_datablock::
	call	___sdcc_enter_ix
	push	af
;fatFs\diskio_xmitdatablock.c:34: if (!wait_ready()) return 0;
	call	_wait_ready
	ld	a,h
	or	a,l
	jr	NZ,00102$
	ld	hl,#0x0000
	jr	00107$
00102$:
;fatFs\diskio_xmitdatablock.c:36: d[0] = token;
	ld	hl,#0x0000
	add	hl,sp
	ld	a,6 (ix)
	ld	(hl),a
;fatFs\diskio_xmitdatablock.c:37: xmit_mmc(d, 1);				    /* Xmit a token */
	ld	e, l
	ld	d, h
	push	hl
	ld	bc,#0x0001
	push	bc
	push	de
	call	_xmit_mmc
	pop	af
	pop	af
	pop	hl
;fatFs\diskio_xmitdatablock.c:38: if (token != 0xFD) {		    /* Is it data token? */
	ld	a,6 (ix)
	sub	a, #0xFD
	jr	Z,00106$
;fatFs\diskio_xmitdatablock.c:39: xmit_mmc(buff, 512);	    /* Xmit the 512 byte data block to MMC */
	push	hl
	ld	bc,#0x0200
	push	bc
	ld	c,4 (ix)
	ld	b,5 (ix)
	push	bc
	call	_xmit_mmc
	pop	af
	pop	af
	pop	hl
;fatFs\diskio_xmitdatablock.c:40: rcvr_mmc(d, 2);			    /* Xmit dummy CRC (0xFF,0xFF) */
	ld	e, l
	ld	d, h
	push	hl
	ld	bc,#0x0002
	push	bc
	push	de
	call	_rcvr_mmc
	pop	af
	pop	af
	pop	hl
;fatFs\diskio_xmitdatablock.c:41: rcvr_mmc(d, 1);			    /* Receive data response */
	ld	e, l
	ld	d, h
	push	hl
	ld	bc,#0x0001
	push	bc
	push	de
	call	_rcvr_mmc
	pop	af
	pop	af
	pop	hl
;fatFs\diskio_xmitdatablock.c:42: if ((d[0] & 0x1F) != 0x05)	/* If not accepted, return with error */
	ld	a,(hl)
	and	a, #0x1F
	sub	a, #0x05
	jr	Z,00106$
;fatFs\diskio_xmitdatablock.c:43: return 0;
	ld	hl,#0x0000
	jr	00107$
00106$:
;fatFs\diskio_xmitdatablock.c:46: return 1;
	ld	hl,#0x0001
00107$:
	pop	af
	pop	ix
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
