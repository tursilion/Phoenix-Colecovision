;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 3.5.0 #9253 (Jun 20 2015) (MINGW64)
; This file was generated Thu Sep 12 23:57:37 2019
;--------------------------------------------------------
	.module ff_followpath
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _create_name
	.globl _dir_find
	.globl _ld_clust
	.globl _dir_sdi
	.globl _follow_path
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\ff_followpath.c:42: FRESULT follow_path (	/* FR_OK(0): successful, !=0: error code */
;	---------------------------------
; Function follow_path
; ---------------------------------
_follow_path::
	call	___sdcc_enter_ix
	ld	hl,#-10
	add	hl,sp
	ld	sp,hl
;fatFs\ff_followpath.c:49: FATFS *fs = dp->obj.fs;
	ld	a,4 (ix)
	ld	-8 (ix),a
	ld	a,5 (ix)
	ld	-7 (ix),a
	pop	de
	pop	bc
	push	bc
	push	de
	ld	l,-8 (ix)
	ld	h,-7 (ix)
	ld	a,(hl)
	ld	-10 (ix),a
	inc	hl
	ld	a,(hl)
	ld	-9 (ix),a
;fatFs\ff_followpath.c:61: while (*path == '/' || *path == '\\') path++;	/* Strip heading separator */
	ld	e,6 (ix)
	ld	d,7 (ix)
00102$:
	ld	a,(de)
	ld	h,a
	sub	a, #0x2F
	jr	Z,00103$
	ld	a,h
	sub	a, #0x5C
	jr	NZ,00141$
00103$:
	inc	de
	ld	6 (ix),e
	ld	7 (ix),d
	jr	00102$
00141$:
	ld	6 (ix),e
	ld	7 (ix),d
;fatFs\ff_followpath.c:63: dp->obj.sclust = 0;					/* Start from root directory */
	ld	hl,#0x0006
	add	hl,bc
	xor	a, a
	ld	(hl), a
	inc	hl
	ld	(hl), a
	inc	hl
	xor	a, a
	ld	(hl), a
	inc	hl
	ld	(hl), a
;fatFs\ff_followpath.c:82: if ((UINT)*path < ' ') {				/* Null path name is the origin directory itself */
	ld	a,(de)
	ld	h,a
	rla
	sbc	a, a
	ld	l,a
	ld	a,h
	sub	a, #0x20
	ld	a,l
	sbc	a, #0x00
	jr	NC,00128$
;fatFs\ff_followpath.c:83: dp->fn[NSFLAG] = NS_NONAME;
	ld	hl,#0x0027
	add	hl,bc
	ld	(hl),#0x80
;fatFs\ff_followpath.c:84: res = dir_sdi(dp, 0);
	ld	hl,#0x0000
	push	hl
	ld	hl,#0x0000
	push	hl
	push	bc
	call	_dir_sdi
	pop	af
	pop	af
	pop	af
	ld	e,l
	jp	00127$
00128$:
;fatFs\ff_followpath.c:88: res = create_name(dp, &path);	/* Get a segment name of the path */
	ld	hl,#0x0010
	add	hl,sp
	push	bc
	push	hl
	push	bc
	call	_create_name
	pop	af
	pop	af
	pop	bc
	ld	e,l
;fatFs\ff_followpath.c:89: if (res != FR_OK) break;
	ld	a,e
	or	a, a
	jp	NZ,00127$
;fatFs\ff_followpath.c:90: res = dir_find(dp);				/* Find an object with the segment name */
	push	bc
	push	bc
	call	_dir_find
	pop	af
	pop	bc
	ld	e,l
;fatFs\ff_followpath.c:91: ns = dp->fn[NSFLAG];
	ld	l,-8 (ix)
	ld	h,-7 (ix)
	push	bc
	ld	bc, #0x0027
	add	hl, bc
	pop	bc
	ld	a,(hl)
;fatFs\ff_followpath.c:99: if (!(ns & NS_LAST)) res = FR_NO_PATH;	/* Adjust error code if not last segment */
	and	a, #0x04
	ld	h,a
;fatFs\ff_followpath.c:92: if (res != FR_OK) {				/* Failed to find the object */
	ld	a,e
	or	a, a
	jr	Z,00118$
;fatFs\ff_followpath.c:93: if (res == FR_NO_FILE) {	/* Object is not found */
	ld	a,e
;fatFs\ff_followpath.c:99: if (!(ns & NS_LAST)) res = FR_NO_PATH;	/* Adjust error code if not last segment */
	sub	a,#0x04
	jr	NZ,00127$
	or	a,h
	jr	NZ,00127$
	ld	e,#0x05
;fatFs\ff_followpath.c:102: break;
	jr	00127$
00118$:
;fatFs\ff_followpath.c:104: if (ns & NS_LAST) break;			/* Last segment matched. Function completed. */
	ld	a,h
	or	a, a
	jr	NZ,00127$
;fatFs\ff_followpath.c:106: if (!(dp->obj.attr & AM_DIR)) {		/* It is not a sub-directory and cannot follow */
	pop	de
	pop	hl
	push	hl
	push	de
	ld	de, #0x0004
	add	hl, de
	bit	4,(hl)
	jr	NZ,00122$
;fatFs\ff_followpath.c:107: res = FR_NO_PATH; break;
	ld	e,#0x05
	jr	00127$
00122$:
;fatFs\ff_followpath.c:118: dp->obj.sclust = ld_clust(fs, fs->win + dp->dptr % SS(fs));	/* Open next directory */
	ld	a,-8 (ix)
	add	a, #0x06
	ld	-2 (ix),a
	ld	a,-7 (ix)
	adc	a, #0x00
	ld	-1 (ix),a
	ld	iy,#0x002E
	pop	de
	push	de
	add	iy, de
	pop	de
	pop	hl
	push	hl
	push	de
	ld	de, #0x000E
	add	hl, de
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	inc	hl
	inc	hl
	ld	a,(hl)
	dec	hl
	ld	l,(hl)
	ld	a,d
	and	a, #0x01
	ld	d,a
	add	iy, de
	push	bc
	push	iy
	ld	l,-10 (ix)
	ld	h,-9 (ix)
	push	hl
	call	_ld_clust
	pop	af
	pop	af
	ld	-3 (ix),d
	ld	-4 (ix),e
	ld	-5 (ix),h
	ld	-6 (ix),l
	ld	e,-2 (ix)
	ld	d,-1 (ix)
	ld	hl, #0x0006
	add	hl, sp
	ld	bc, #0x0004
	ldir
	pop	bc
	jp	00128$
00127$:
;fatFs\ff_followpath.c:123: return res;
	ld	l,e
	ld	sp, ix
	pop	ix
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
