;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 3.5.0 #9253 (Jun 20 2015) (MINGW64)
; This file was generated Thu Sep 12 23:57:41 2019
;--------------------------------------------------------
	.module ff_fread
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _memcpy
	.globl _disk_write
	.globl _disk_read
	.globl _validate
	.globl _get_fat
	.globl _clst2sect
	.globl _f_read
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\ff_fread.c:43: FRESULT f_read (
;	---------------------------------
; Function f_read
; ---------------------------------
_f_read::
	call	___sdcc_enter_ix
	ld	hl,#-47
	add	hl,sp
	ld	sp,hl
;fatFs\ff_fread.c:55: BYTE *rbuff = (BYTE*)buff;
	ld	a,6 (ix)
	ld	-47 (ix),a
	ld	a,7 (ix)
	ld	-46 (ix),a
;fatFs\ff_fread.c:58: *br = 0;	/* Clear read byte counter */
	ld	a,10 (ix)
	ld	-19 (ix),a
	ld	a,11 (ix)
	ld	-18 (ix),a
	ld	l,-19 (ix)
	ld	h,-18 (ix)
	xor	a, a
	ld	(hl), a
	inc	hl
	ld	(hl), a
;fatFs\ff_fread.c:59: res = validate(&fp->obj, &fs);				/* Check validity of the file object */
	ld	hl,#0x0008
	add	hl,sp
	ld	a,4 (ix)
	ld	-35 (ix),a
	ld	a,5 (ix)
	ld	-34 (ix),a
	push	hl
	ld	l,-35 (ix)
	ld	h,-34 (ix)
	push	hl
	call	_validate
	pop	af
	pop	af
	ld	c,l
	ld	-15 (ix),c
;fatFs\ff_fread.c:60: if (res != FR_OK || (res = (FRESULT)fp->err) != FR_OK) LEAVE_FF(fs, res);	/* Check validity */
	ld	a,c
	or	a, a
	jr	NZ,00101$
	ld	a,-35 (ix)
	add	a, #0x0F
	ld	-21 (ix),a
	ld	a,-34 (ix)
	adc	a, #0x00
	ld	-20 (ix),a
	ld	l,-21 (ix)
	ld	h,-20 (ix)
	ld	a,(hl)
	ld	-15 (ix),a
	or	a, a
	jr	Z,00102$
00101$:
	ld	l,-15 (ix)
	jp	00144$
00102$:
;fatFs\ff_fread.c:61: if (!(fp->flag & FA_READ)) LEAVE_FF(fs, FR_DENIED); /* Check access mode */
	ld	a,-35 (ix)
	add	a, #0x0E
	ld	-17 (ix),a
	ld	a,-34 (ix)
	adc	a, #0x00
	ld	-16 (ix),a
	ld	l,-17 (ix)
	ld	h,-16 (ix)
	ld	a,(hl)
	rrca
	jr	C,00105$
	ld	l,#0x07
	jp	00144$
00105$:
;fatFs\ff_fread.c:62: remain = fp->obj.objsize - fp->fptr;
	ld	l,-35 (ix)
	ld	h,-34 (ix)
	ld	de, #0x000A
	add	hl, de
	ld	c,(hl)
	inc	hl
	ld	b,(hl)
	inc	hl
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,-35 (ix)
	add	a, #0x10
	ld	-14 (ix),a
	ld	a,-34 (ix)
	adc	a, #0x00
	ld	-13 (ix),a
	push	de
	push	bc
	ld	e,-14 (ix)
	ld	d,-13 (ix)
	ld	hl, #0x001A
	add	hl, sp
	ex	de, hl
	ld	bc, #0x0004
	ldir
	pop	bc
	pop	de
	ld	a,c
	sub	a, -25 (ix)
	ld	c,a
	ld	a,b
	sbc	a, -24 (ix)
	ld	b,a
	ld	a,e
	sbc	a, -23 (ix)
	ld	e,a
	ld	a,d
	sbc	a, -22 (ix)
	ld	d,a
;fatFs\ff_fread.c:63: if (btr > remain) btr = (UINT)remain;		/* Truncate btr by remaining bytes */
	ld	a,8 (ix)
	ld	-25 (ix),a
	ld	a,9 (ix)
	ld	-24 (ix),a
	ld	-23 (ix),#0x00
	ld	-22 (ix),#0x00
	ld	a,c
	sub	a, -25 (ix)
	ld	a,b
	sbc	a, -24 (ix)
	ld	a,e
	sbc	a, -23 (ix)
	ld	a,d
	sbc	a, -22 (ix)
	jr	NC,00166$
	ld	8 (ix),c
	ld	9 (ix),b
00166$:
	ld	a,-35 (ix)
	add	a, #0x22
	ld	-25 (ix),a
	ld	a,-34 (ix)
	adc	a, #0x00
	ld	-24 (ix),a
	ld	a,-25 (ix)
	ld	-27 (ix),a
	ld	a,-24 (ix)
	ld	-26 (ix),a
	ld	a,-35 (ix)
	add	a, #0x18
	ld	-29 (ix),a
	ld	a,-34 (ix)
	adc	a, #0x00
	ld	-28 (ix),a
	ld	a,-29 (ix)
	ld	-31 (ix),a
	ld	a,-28 (ix)
	ld	-30 (ix),a
	ld	a,-35 (ix)
	ld	-33 (ix),a
	ld	a,-34 (ix)
	ld	-32 (ix),a
;fatFs\ff_fread.c:79: clst = get_fat(&fp->obj, fp->clust);	/* Follow cluster chain on the FAT */
	ld	a,-35 (ix)
	add	a, #0x14
	ld	-37 (ix),a
	ld	a,-34 (ix)
	adc	a, #0x00
	ld	-36 (ix),a
;fatFs\ff_fread.c:63: if (btr > remain) btr = (UINT)remain;		/* Truncate btr by remaining bytes */
	ld	a,-37 (ix)
	ld	-8 (ix),a
	ld	a,-36 (ix)
	ld	-7 (ix),a
	ld	a,-25 (ix)
	ld	-2 (ix),a
	ld	a,-24 (ix)
	ld	-1 (ix),a
00143$:
;fatFs\ff_fread.c:65: for ( ;  btr;								/* Repeat until btr bytes read */
	ld	a,9 (ix)
	or	a,8 (ix)
	jp	Z,00141$
;fatFs\ff_fread.c:67: if (fp->fptr % SS(fs) == 0) {			/* On the sector boundary? */
	ld	l,-14 (ix)
	ld	h,-13 (ix)
	ld	c,(hl)
	inc	hl
	ld	b,(hl)
	inc	hl
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,c
	or	a, a
	jp	NZ,00137$
	bit	0, b
	jp	NZ,00137$
;fatFs\ff_fread.c:68: csect = (UINT)(fp->fptr / SS(fs) & (fs->csize - 1));	/* Sector offset in the cluster */
	push	af
	ld	-12 (ix),c
	ld	-11 (ix),b
	ld	-10 (ix),e
	ld	-9 (ix),d
	pop	af
	ld	a,#0x09
00234$:
	srl	-9 (ix)
	rr	-10 (ix)
	rr	-11 (ix)
	rr	-12 (ix)
	dec	a
	jr	NZ,00234$
	ld	l,-39 (ix)
	ld	h,-38 (ix)
	push	bc
	ld	bc, #0x0008
	add	hl, bc
	pop	bc
	ld	a, (hl)
	inc	hl
	ld	h,(hl)
	ld	l,a
	dec	hl
	ld	-6 (ix),l
	ld	-5 (ix),h
	ld	-4 (ix),#0x00
	ld	-3 (ix),#0x00
	ld	a,-6 (ix)
	and	a, -12 (ix)
	ld	-6 (ix),a
	ld	a,-5 (ix)
	and	a, -11 (ix)
	ld	-5 (ix),a
	ld	a,-4 (ix)
	and	a, -10 (ix)
	ld	-4 (ix),a
	ld	a,-3 (ix)
	and	a, -9 (ix)
	ld	-3 (ix),a
	ld	a,-6 (ix)
	ld	-45 (ix),a
	ld	a,-5 (ix)
;fatFs\ff_fread.c:69: if (csect == 0) {					/* On the cluster boundary? */
	ld	-44 (ix), a
	or	a,-45 (ix)
	jp	NZ,00116$
;fatFs\ff_fread.c:70: if (fp->fptr == 0) {			/* On the top of the file? */
	ld	a,d
	or	a, e
	or	a, b
	or	a,c
	jr	NZ,00109$
;fatFs\ff_fread.c:71: clst = fp->obj.sclust;		/* Follow cluster chain from the origin */
	ld	l,-33 (ix)
	ld	h,-32 (ix)
	ld	de, #0x0006
	add	hl, de
	ld	c,(hl)
	inc	hl
	ld	b,(hl)
	inc	hl
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	jr	00110$
00109$:
;fatFs\ff_fread.c:79: clst = get_fat(&fp->obj, fp->clust);	/* Follow cluster chain on the FAT */
	ld	e,-37 (ix)
	ld	d,-36 (ix)
	ld	hl, #0x0029
	add	hl, sp
	ex	de, hl
	ld	bc, #0x0004
	ldir
	ld	l,-4 (ix)
	ld	h,-3 (ix)
	push	hl
	ld	l,-6 (ix)
	ld	h,-5 (ix)
	push	hl
	ld	l,-35 (ix)
	ld	h,-34 (ix)
	push	hl
	call	_get_fat
	pop	af
	pop	af
	pop	af
	ld	c,l
	ld	b,h
00110$:
;fatFs\ff_fread.c:82: if (clst < 2) ABORT(fs, FR_INT_ERR);
	ld	a,c
	sub	a, #0x02
	ld	a,b
	sbc	a, #0x00
	ld	a,e
	sbc	a, #0x00
	ld	a,d
	sbc	a, #0x00
	jr	NC,00112$
	ld	l,-21 (ix)
	ld	h,-20 (ix)
	ld	(hl),#0x02
	ld	l,#0x02
	jp	00144$
00112$:
;fatFs\ff_fread.c:83: if (clst == 0xFFFFFFFF) ABORT(fs, FR_DISK_ERR);
	ld	a,c
	inc	a
	jr	NZ,00114$
	ld	a,b
	inc	a
	jr	NZ,00114$
	ld	a,e
	inc	a
	jr	NZ,00114$
	ld	a,d
	inc	a
	jr	NZ,00114$
	ld	l,-21 (ix)
	ld	h,-20 (ix)
	ld	(hl),#0x01
	ld	l,#0x01
	jp	00144$
00114$:
;fatFs\ff_fread.c:84: fp->clust = clst;				/* Update current cluster */
	ld	l,-37 (ix)
	ld	h,-36 (ix)
	ld	(hl),c
	inc	hl
	ld	(hl),b
	inc	hl
	ld	(hl),e
	inc	hl
	ld	(hl),d
00116$:
;fatFs\ff_fread.c:86: sect = clst2sect(fs, fp->clust);	/* Get current sector */
	ld	l,-8 (ix)
	ld	h,-7 (ix)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	inc	hl
	ld	c,(hl)
	inc	hl
	ld	b,(hl)
	push	bc
	push	de
	ld	l,-39 (ix)
	ld	h,-38 (ix)
	push	hl
	call	_clst2sect
	pop	af
	pop	af
	pop	af
;fatFs\ff_fread.c:87: if (sect == 0) ABORT(fs, FR_INT_ERR);
	ld	a,d
	or	a, e
	or	a, h
	or	a,l
	jr	NZ,00118$
	ld	l,-21 (ix)
	ld	h,-20 (ix)
	ld	(hl),#0x02
	ld	l,#0x02
	jp	00144$
00118$:
;fatFs\ff_fread.c:88: sect += csect;
	ld	a,-45 (ix)
	ld	-6 (ix),a
	ld	a,-44 (ix)
	ld	-5 (ix),a
	ld	-4 (ix),#0x00
	ld	-3 (ix),#0x00
	ld	a,l
	add	a, -6 (ix)
	ld	l,a
	ld	a,h
	adc	a, -5 (ix)
	ld	h,a
	ld	a,e
	adc	a, -4 (ix)
	ld	e,a
	ld	a,d
	adc	a, -3 (ix)
	ld	d,a
	ld	-43 (ix),l
	ld	-42 (ix),h
	ld	-41 (ix),e
	ld	-40 (ix),d
;fatFs\ff_fread.c:89: cc = btr / SS(fs);					/* When remaining bytes >= sector size, */
	ld	a,9 (ix)
	srl	a
	ld	c,a
	ld	b,#0x00
;fatFs\ff_fread.c:90: if (cc > 0) {						/* Read maximum contiguous sectors directly */
	ld	a,b
	or	a,c
	jp	Z,00127$
;fatFs\ff_fread.c:91: if (csect + cc > fs->csize) {	/* Clip at cluster boundary */
	ld	a,-45 (ix)
	add	a, c
	ld	e,a
	ld	a,-44 (ix)
	adc	a, b
	ld	d,a
	ld	l,-39 (ix)
	ld	h,-38 (ix)
	push	bc
	ld	bc, #0x0008
	add	hl, bc
	pop	bc
	ld	a, (hl)
	inc	hl
	ld	l,(hl)
	ld	h,a
	sub	a, e
	ld	a,l
	sbc	a, d
	jr	NC,00120$
;fatFs\ff_fread.c:92: cc = fs->csize - csect;
	ld	a,h
	sub	a, -45 (ix)
	ld	c,a
	ld	a,l
	sbc	a, -44 (ix)
	ld	b,a
00120$:
;fatFs\ff_fread.c:97: if (disk_read(rbuff, sect, cc) != RES_OK) ABORT(fs, FR_DISK_ERR);
	push	bc
	push	bc
	ld	l,-41 (ix)
	ld	h,-40 (ix)
	push	hl
	ld	l,-43 (ix)
	ld	h,-42 (ix)
	push	hl
	ld	l,-47 (ix)
	ld	h,-46 (ix)
	push	hl
	call	_disk_read
	pop	af
	pop	af
	pop	af
	pop	af
	ld	a,l
	pop	bc
	or	a, a
	jr	Z,00122$
	ld	l,-21 (ix)
	ld	h,-20 (ix)
	ld	(hl),#0x01
	ld	l,#0x01
	jp	00144$
00122$:
;fatFs\ff_fread.c:105: if ((fp->flag & FA_DIRTY) && fp->sect - sect < cc) {
	ld	l,-17 (ix)
	ld	h,-16 (ix)
	ld	a,(hl)
	rlca
	jr	NC,00124$
	ld	l,-31 (ix)
	ld	h,-30 (ix)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	inc	hl
	inc	hl
	ld	a,(hl)
	dec	hl
	ld	l,(hl)
	ld	h,a
	ld	a,e
	sub	a, -43 (ix)
	ld	e,a
	ld	a,d
	sbc	a, -42 (ix)
	ld	d,a
	ld	a,l
	sbc	a, -41 (ix)
	ld	l,a
	ld	a,h
	sbc	a, -40 (ix)
	ld	h,a
	ld	-6 (ix),c
	ld	-5 (ix),b
	ld	-4 (ix),#0x00
	ld	-3 (ix),#0x00
	ld	a,e
	sub	a, -6 (ix)
	ld	a,d
	sbc	a, -5 (ix)
	ld	a,l
	sbc	a, -4 (ix)
	ld	a,h
	sbc	a, -3 (ix)
	jr	NC,00124$
;fatFs\ff_fread.c:106: memcpy(rbuff + ((fp->sect - sect) * SS(fs)), fp->buf, SS(fs));
	push	hl
	ld	l,-27 (ix)
	ld	h,-26 (ix)
	push	hl
	pop	iy
	pop	hl
	ld	a,#0x09
00239$:
	sla	e
	rl	d
	adc	hl, hl
	dec	a
	jr	NZ,00239$
	ld	a,-47 (ix)
	add	a, e
	ld	e,a
	ld	a,-46 (ix)
	adc	a, d
	ld	d,a
	push	bc
	ld	hl,#0x0200
	push	hl
	push	iy
	push	de
	call	_memcpy
	pop	af
	pop	af
	pop	af
	pop	bc
00124$:
;fatFs\ff_fread.c:110: rcnt = SS(fs) * cc;				/* Number of bytes transferred */
	ld	a,c
	add	a, a
	ld	b,a
	ld	c,#0x00
;fatFs\ff_fread.c:111: continue;
	jp	00140$
00127$:
;fatFs\ff_fread.c:114: if (fp->sect != sect) {			/* Load data sector if not in cache */
	ld	l,-29 (ix)
	ld	h,-28 (ix)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	inc	hl
	ld	c,(hl)
	inc	hl
	ld	b,(hl)
	ld	a,-43 (ix)
	sub	a, e
	jr	NZ,00241$
	ld	a,-42 (ix)
	sub	a, d
	jr	NZ,00241$
	ld	a,-41 (ix)
	sub	a, c
	jr	NZ,00241$
	ld	a,-40 (ix)
	sub	a, b
	jr	Z,00135$
00241$:
;fatFs\ff_fread.c:116: if (fp->flag & FA_DIRTY) {		/* Write-back dirty sector cache */
	ld	l,-17 (ix)
	ld	h,-16 (ix)
	ld	a,(hl)
	rlca
	jr	NC,00131$
;fatFs\ff_fread.c:120: if (disk_write(fp->buf, fp->sect, 1) != RES_OK) ABORT(fs, FR_DISK_ERR);
	ld	hl,#0x0001
	push	hl
	push	bc
	push	de
	ld	l,-25 (ix)
	ld	h,-24 (ix)
	push	hl
	call	_disk_write
	pop	af
	pop	af
	pop	af
	pop	af
	ld	a,l
	or	a, a
	jr	Z,00129$
	ld	l,-21 (ix)
	ld	h,-20 (ix)
	ld	(hl),#0x01
	ld	l,#0x01
	jp	00144$
00129$:
;fatFs\ff_fread.c:122: fp->flag &= (BYTE)~FA_DIRTY;
	ld	l,-17 (ix)
	ld	h,-16 (ix)
	ld	a,(hl)
	and	a, #0x7F
	ld	l,-17 (ix)
	ld	h,-16 (ix)
	ld	(hl),a
00131$:
;fatFs\ff_fread.c:128: if (disk_read(fp->buf, sect, 1) != RES_OK)	ABORT(fs, FR_DISK_ERR);	/* Fill sector cache */
	ld	hl,#0x0001
	push	hl
	ld	l,-41 (ix)
	ld	h,-40 (ix)
	push	hl
	ld	l,-43 (ix)
	ld	h,-42 (ix)
	push	hl
	ld	l,-25 (ix)
	ld	h,-24 (ix)
	push	hl
	call	_disk_read
	pop	af
	pop	af
	pop	af
	pop	af
	ld	a,l
	or	a, a
	jr	Z,00135$
	ld	l,-21 (ix)
	ld	h,-20 (ix)
	ld	(hl),#0x01
	ld	l,#0x01
	jp	00144$
00135$:
;fatFs\ff_fread.c:132: fp->sect = sect;
	ld	e,-29 (ix)
	ld	d,-28 (ix)
	ld	hl, #0x0004
	add	hl, sp
	ld	bc, #0x0004
	ldir
00137$:
;fatFs\ff_fread.c:62: remain = fp->obj.objsize - fp->fptr;
	ld	e,-14 (ix)
	ld	d,-13 (ix)
	ld	hl, #0x0029
	add	hl, sp
	ex	de, hl
	ld	bc, #0x0004
	ldir
;fatFs\ff_fread.c:134: rcnt = SS(fs) - (UINT)fp->fptr % SS(fs);	/* Number of bytes left in the sector */
	ld	h,-6 (ix)
	ld	a, -5 (ix)
	and	a, #0x01
	ld	l,a
	xor	a, a
	sub	a, h
	ld	c,a
	ld	a,#0x02
	sbc	a, l
	ld	b,a
;fatFs\ff_fread.c:135: if (rcnt > btr) rcnt = btr;					/* Clip it by btr if needed */
	ld	a,8 (ix)
	sub	a, c
	ld	a,9 (ix)
	sbc	a, b
	jr	NC,00139$
	ld	c,8 (ix)
	ld	b,9 (ix)
00139$:
;fatFs\ff_fread.c:140: memcpy(rbuff, fp->buf + fp->fptr % SS(fs), rcnt);	/* Extract partial sector */
	ld	l,-6 (ix)
	ld	a,-5 (ix)
	and	a, #0x01
	ld	h,a
	ld	a,-2 (ix)
	add	a, l
	ld	l,a
	ld	a,-1 (ix)
	adc	a, h
	ld	h,a
	pop	de
	push	de
	push	bc
	push	bc
	push	hl
	push	de
	call	_memcpy
	pop	af
	pop	af
	pop	af
	pop	bc
00140$:
;fatFs\ff_fread.c:66: btr -= rcnt, *br += rcnt, rbuff += rcnt, fp->fptr += rcnt) {
	ld	a,8 (ix)
	sub	a, c
	ld	8 (ix),a
	ld	a,9 (ix)
	sbc	a, b
	ld	9 (ix),a
	ld	l,-19 (ix)
	ld	h,-18 (ix)
	ld	a, (hl)
	inc	hl
	ld	h,(hl)
	ld	l,a
	add	hl,bc
	ld	d,l
	ld	e,h
	ld	l,-19 (ix)
	ld	h,-18 (ix)
	ld	(hl),d
	inc	hl
	ld	(hl),e
	ld	a,-47 (ix)
	add	a, c
	ld	-47 (ix),a
	ld	a,-46 (ix)
	adc	a, b
	ld	-46 (ix),a
	push	bc
	ld	e,-14 (ix)
	ld	d,-13 (ix)
	ld	hl, #0x002B
	add	hl, sp
	ex	de, hl
	ld	bc, #0x0004
	ldir
	pop	bc
	ld	hl,#0x0000
	ld	a,-6 (ix)
	add	a, c
	ld	e,a
	ld	a,-5 (ix)
	adc	a, b
	ld	d,a
	ld	a,-4 (ix)
	adc	a, h
	ld	c,a
	ld	a,-3 (ix)
	adc	a, l
	ld	b,a
	ld	l,-14 (ix)
	ld	h,-13 (ix)
	ld	(hl),e
	inc	hl
	ld	(hl),d
	inc	hl
	ld	(hl),c
	inc	hl
	ld	(hl),b
	jp	00143$
00141$:
;fatFs\ff_fread.c:144: LEAVE_FF(fs, FR_OK);
	ld	l,#0x00
00144$:
	ld	sp, ix
	pop	ix
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
