;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 3.5.0 #9253 (Jun 20 2015) (MINGW64)
; This file was generated Thu Sep 12 23:57:51 2019
;--------------------------------------------------------
	.module ff_lddword
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _ld_dword
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\ff_lddword.c:42: DWORD ld_dword (const BYTE* ptr)	/* Load a 4-byte little-endian word */
;	---------------------------------
; Function ld_dword
; ---------------------------------
_ld_dword::
	call	___sdcc_enter_ix
	push	af
	push	af
;fatFs\ff_lddword.c:46: rv = ptr[3];
	ld	l,4 (ix)
	ld	h,5 (ix)
	inc	hl
	inc	hl
	inc	hl
	ld	e,(hl)
	ld	d,#0x00
	ld	bc,#0x0000
;fatFs\ff_lddword.c:47: rv = rv << 8 | ptr[2];
	ld	a,#0x08
00103$:
	sla	e
	rl	d
	rl	c
	rl	b
	dec	a
	jr	NZ,00103$
	ld	l,4 (ix)
	ld	h,5 (ix)
	inc	hl
	inc	hl
	ld	a,(hl)
	ld	-4 (ix),a
	ld	-3 (ix),#0x00
	ld	-2 (ix),#0x00
	ld	-1 (ix),#0x00
	ld	a,e
	or	a, -4 (ix)
	ld	e,a
	ld	a,d
	or	a, -3 (ix)
	ld	d,a
	ld	a,c
	or	a, -2 (ix)
	ld	c,a
	ld	a,b
	or	a, -1 (ix)
	ld	b,a
;fatFs\ff_lddword.c:48: rv = rv << 8 | ptr[1];
	ld	a,#0x08
00105$:
	sla	e
	rl	d
	rl	c
	rl	b
	dec	a
	jr	NZ,00105$
	ld	l,4 (ix)
	ld	h,5 (ix)
	inc	hl
	ld	a,(hl)
	ld	-4 (ix),a
	ld	-3 (ix),#0x00
	ld	-2 (ix),#0x00
	ld	-1 (ix),#0x00
	ld	a,e
	or	a, -4 (ix)
	ld	e,a
	ld	a,d
	or	a, -3 (ix)
	ld	d,a
	ld	a,c
	or	a, -2 (ix)
	ld	c,a
	ld	a,b
	or	a, -1 (ix)
	ld	b,a
;fatFs\ff_lddword.c:49: rv = rv << 8 | ptr[0];
	ld	a,#0x08
00107$:
	sla	e
	rl	d
	rl	c
	rl	b
	dec	a
	jr	NZ,00107$
	ld	l,4 (ix)
	ld	h,5 (ix)
	ld	a,(hl)
	ld	-4 (ix),a
	ld	-3 (ix),#0x00
	ld	-2 (ix),#0x00
	ld	-1 (ix),#0x00
	ld	a,e
	or	a, -4 (ix)
	ld	l,a
	ld	a,d
	or	a, -3 (ix)
	ld	h,a
	ld	a,c
	or	a, -2 (ix)
	ld	e,a
	ld	a,b
	or	a, -1 (ix)
	ld	d,a
;fatFs\ff_lddword.c:50: return rv;
	ld	sp, ix
	pop	ix
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
