;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 3.5.0 #9253 (Jun 20 2015) (MINGW64)
; This file was generated Thu Sep 12 23:57:48 2019
;--------------------------------------------------------
	.module ff_fwrite
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _memcpy
	.globl _disk_write
	.globl _disk_read
	.globl _create_chain
	.globl _validate
	.globl _clst2sect
	.globl _f_write
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\ff_fwrite.c:43: FRESULT f_write (
;	---------------------------------
; Function f_write
; ---------------------------------
_f_write::
	call	___sdcc_enter_ix
	ld	hl,#-54
	add	hl,sp
	ld	sp,hl
;fatFs\ff_fwrite.c:54: const BYTE *wbuff = (const BYTE*)buff;
	ld	a,6 (ix)
	ld	-52 (ix),a
	ld	a,7 (ix)
	ld	-51 (ix),a
;fatFs\ff_fwrite.c:57: *bw = 0;	/* Clear write byte counter */
	ld	a,10 (ix)
	ld	-8 (ix),a
	ld	a,11 (ix)
	ld	-7 (ix),a
	ld	l,-8 (ix)
	ld	h,-7 (ix)
	xor	a, a
	ld	(hl), a
	inc	hl
	ld	(hl), a
;fatFs\ff_fwrite.c:58: res = validate(&fp->obj, &fs);			/* Check validity of the file object */
	ld	hl,#0x0000
	add	hl,sp
	ld	a,4 (ix)
	ld	-4 (ix),a
	ld	a,5 (ix)
	ld	-3 (ix),a
	push	hl
	ld	l,-4 (ix)
	ld	h,-3 (ix)
	push	hl
	call	_validate
	pop	af
	pop	af
;fatFs\ff_fwrite.c:59: if (res != FR_OK || (res = (FRESULT)fp->err) != FR_OK) LEAVE_FF(fs, res);	/* Check validity */
	ld	a,l
	or	a, a
	jp	NZ,00151$
	ld	a,-4 (ix)
	add	a, #0x0F
	ld	-28 (ix),a
	ld	a,-3 (ix)
	adc	a, #0x00
	ld	-27 (ix),a
	ld	l,-28 (ix)
	ld	h,-27 (ix)
	ld	a,(hl)
	ld	l,a
	or	a, a
	jp	NZ,00151$
;fatFs\ff_fwrite.c:60: if (!(fp->flag & FA_WRITE)) LEAVE_FF(fs, FR_DENIED);	/* Check access mode */
	ld	a,-4 (ix)
	add	a, #0x0E
	ld	-34 (ix),a
	ld	a,-3 (ix)
	adc	a, #0x00
	ld	-33 (ix),a
	ld	l,-34 (ix)
	ld	h,-33 (ix)
	bit	1,(hl)
	jr	NZ,00109$
	ld	l,#0x07
	jp	00151$
;fatFs\ff_fwrite.c:63: if ((!FF_FS_EXFAT || fs->fs_type != FS_EXFAT) && (DWORD)(fp->fptr + btw) < (DWORD)fp->fptr) {
00109$:
	ld	a,-4 (ix)
	add	a, #0x10
	ld	-44 (ix),a
	ld	a,-3 (ix)
	adc	a, #0x00
	ld	-43 (ix),a
	ld	l,-44 (ix)
	ld	h,-43 (ix)
	ld	c,(hl)
	inc	hl
	ld	b,(hl)
	inc	hl
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,8 (ix)
	ld	-40 (ix),a
	ld	a,9 (ix)
	ld	-39 (ix),a
	ld	-38 (ix),#0x00
	ld	-37 (ix),#0x00
	ld	a,c
	add	a, -40 (ix)
	ld	-40 (ix),a
	ld	a,b
	adc	a, -39 (ix)
	ld	-39 (ix),a
	ld	a,e
	adc	a, -38 (ix)
	ld	-38 (ix),a
	ld	a,d
	adc	a, -37 (ix)
	ld	-37 (ix),a
	ld	a,-40 (ix)
	sub	a, c
	ld	a,-39 (ix)
	sbc	a, b
	ld	a,-38 (ix)
	sbc	a, e
	ld	a,-37 (ix)
	sbc	a, d
	jr	NC,00179$
;fatFs\ff_fwrite.c:64: btw = (UINT)(0xFFFFFFFF - (DWORD)fp->fptr);
	ld	a,#0xFF
	sub	a, c
	ld	l,a
	ld	a,#0xFF
	sbc	a, b
	ld	h,a
	ld	a,#0xFF
	sbc	a, e
	ld	a,#0xFF
	sbc	a, d
	ld	8 (ix),l
	ld	9 (ix),h
00179$:
;fatFs\ff_fwrite.c:100: if (disk_write(fp->buf, fp->sect, 1) != RES_OK) ABORT(fs, FR_DISK_ERR);
	ld	a,-4 (ix)
	add	a, #0x22
	ld	-40 (ix),a
	ld	a,-3 (ix)
	adc	a, #0x00
	ld	-39 (ix),a
;fatFs\ff_fwrite.c:64: btw = (UINT)(0xFFFFFFFF - (DWORD)fp->fptr);
	ld	a,-40 (ix)
	ld	-18 (ix),a
	ld	a,-39 (ix)
	ld	-17 (ix),a
	ld	a,-4 (ix)
	add	a, #0x18
	ld	-42 (ix),a
	ld	a,-3 (ix)
	adc	a, #0x00
	ld	-41 (ix),a
	ld	a,-42 (ix)
	ld	-36 (ix),a
	ld	a,-41 (ix)
	ld	-35 (ix),a
	ld	a,-4 (ix)
	add	a, #0x06
	ld	-2 (ix),a
	ld	a,-3 (ix)
	adc	a, #0x00
	ld	-1 (ix),a
	ld	a,-2 (ix)
	ld	-20 (ix),a
	ld	a,-1 (ix)
	ld	-19 (ix),a
	ld	a,-42 (ix)
	ld	-30 (ix),a
	ld	a,-41 (ix)
	ld	-29 (ix),a
;fatFs\ff_fwrite.c:84: clst = create_chain(&fp->obj, fp->clust);	/* Follow or stretch cluster chain on the FAT */
	ld	a,-4 (ix)
	add	a, #0x14
	ld	-32 (ix),a
	ld	a,-3 (ix)
	adc	a, #0x00
	ld	-31 (ix),a
;fatFs\ff_fwrite.c:64: btw = (UINT)(0xFFFFFFFF - (DWORD)fp->fptr);
	ld	a,-32 (ix)
	ld	-26 (ix),a
	ld	a,-31 (ix)
	ld	-25 (ix),a
	ld	a,-4 (ix)
	add	a, #0x0A
	ld	-24 (ix),a
	ld	a,-3 (ix)
	adc	a, #0x00
	ld	-23 (ix),a
	ld	a,-24 (ix)
	ld	-22 (ix),a
	ld	a,-23 (ix)
	ld	-21 (ix),a
	ld	a,-40 (ix)
	ld	-6 (ix),a
	ld	a,-39 (ix)
	ld	-5 (ix),a
00150$:
;fatFs\ff_fwrite.c:67: for ( ;  btw;							/* Repeat until all data written */
	ld	a,9 (ix)
	or	a,8 (ix)
	jp	Z,00148$
;fatFs\ff_fwrite.c:69: if (fp->fptr % SS(fs) == 0) {		/* On the sector boundary? */
	ld	l,-44 (ix)
	ld	h,-43 (ix)
	ld	c,(hl)
	inc	hl
	ld	b,(hl)
	inc	hl
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,c
	or	a, a
	jp	NZ,00144$
	bit	0, b
	jp	NZ,00144$
;fatFs\ff_fwrite.c:70: csect = (UINT)(fp->fptr / SS(fs)) & (fs->csize - 1);	/* Sector offset in the cluster */
	push	af
	ld	-16 (ix),c
	ld	-15 (ix),b
	ld	-14 (ix),e
	ld	-13 (ix),d
	pop	af
	ld	a,#0x09
00259$:
	srl	-13 (ix)
	rr	-14 (ix)
	rr	-15 (ix)
	rr	-16 (ix)
	dec	a
	jr	NZ,00259$
	ld	a,-16 (ix)
	ld	-16 (ix),a
	ld	a,-15 (ix)
	ld	-15 (ix),a
	pop	hl
	push	hl
	push	bc
	ld	bc, #0x0008
	add	hl, bc
	pop	bc
	ld	a, (hl)
	inc	hl
	ld	h,(hl)
	ld	l,a
	dec	hl
	ld	a,l
	and	a, -16 (ix)
	ld	l,a
	ld	a,h
	and	a, -15 (ix)
	ld	-46 (ix), l
;fatFs\ff_fwrite.c:71: if (csect == 0) {				/* On the cluster boundary? */
	ld	-45 (ix), a
	or	a,-46 (ix)
	jp	NZ,00124$
;fatFs\ff_fwrite.c:72: if (fp->fptr == 0) {		/* On the top of the file? */
	ld	a,d
	or	a, e
	or	a, b
	or	a,c
	jr	NZ,00113$
;fatFs\ff_fwrite.c:73: clst = fp->obj.sclust;	/* Follow from the origin */
	ld	l,-20 (ix)
	ld	h,-19 (ix)
	ld	c,(hl)
	inc	hl
	ld	b,(hl)
	inc	hl
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
;fatFs\ff_fwrite.c:74: if (clst == 0) {		/* If no cluster is allocated, */
	ld	a,d
	or	a, e
	or	a, b
	or	a,c
	jr	NZ,00114$
;fatFs\ff_fwrite.c:75: clst = create_chain(&fp->obj, 0);	/* create a new cluster chain */
	ld	hl,#0x0000
	push	hl
	ld	hl,#0x0000
	push	hl
	ld	l,-4 (ix)
	ld	h,-3 (ix)
	push	hl
	call	_create_chain
	pop	af
	pop	af
	pop	af
	ld	c,l
	ld	b,h
	jr	00114$
00113$:
;fatFs\ff_fwrite.c:84: clst = create_chain(&fp->obj, fp->clust);	/* Follow or stretch cluster chain on the FAT */
	ld	e,-32 (ix)
	ld	d,-31 (ix)
	ld	hl, #0x0026
	add	hl, sp
	ex	de, hl
	ld	bc, #0x0004
	ldir
	ld	l,-14 (ix)
	ld	h,-13 (ix)
	push	hl
	ld	l,-16 (ix)
	ld	h,-15 (ix)
	push	hl
	ld	l,-4 (ix)
	ld	h,-3 (ix)
	push	hl
	call	_create_chain
	pop	af
	pop	af
	pop	af
	ld	c,l
	ld	b,h
00114$:
;fatFs\ff_fwrite.c:87: if (clst == 0) break;		/* Could not allocate a new cluster (disk full) */
	ld	a,d
	or	a, e
	or	a, b
	or	a,c
	jp	Z,00148$
;fatFs\ff_fwrite.c:88: if (clst == 1) ABORT(fs, FR_INT_ERR);
	ld	a,c
	dec	a
	jr	NZ,00118$
	ld	a,b
	or	a,a
	jr	NZ,00118$
	or	a,e
	jr	NZ,00118$
	or	a,d
	jr	NZ,00118$
	ld	l,-28 (ix)
	ld	h,-27 (ix)
	ld	(hl),#0x02
	ld	l,#0x02
	jp	00151$
00118$:
;fatFs\ff_fwrite.c:89: if (clst == 0xFFFFFFFF) ABORT(fs, FR_DISK_ERR);
	ld	a,c
	inc	a
	jr	NZ,00120$
	ld	a,b
	inc	a
	jr	NZ,00120$
	ld	a,e
	inc	a
	jr	NZ,00120$
	ld	a,d
	inc	a
	jr	NZ,00120$
	ld	l,-28 (ix)
	ld	h,-27 (ix)
	ld	(hl),#0x01
	ld	l,#0x01
	jp	00151$
00120$:
;fatFs\ff_fwrite.c:90: fp->clust = clst;			/* Update current cluster */
	ld	l,-32 (ix)
	ld	h,-31 (ix)
	ld	(hl),c
	inc	hl
	ld	(hl),b
	inc	hl
	ld	(hl),e
	inc	hl
	ld	(hl),d
;fatFs\ff_fwrite.c:91: if (fp->obj.sclust == 0) fp->obj.sclust = clst;	/* Set start cluster if the first write */
	push	de
	push	bc
	ld	e,-2 (ix)
	ld	d,-1 (ix)
	ld	hl, #0x002A
	add	hl, sp
	ex	de, hl
	ld	bc, #0x0004
	ldir
	pop	bc
	pop	de
	ld	a,-13 (ix)
	or	a, -14 (ix)
	or	a, -15 (ix)
	or	a,-16 (ix)
	jr	NZ,00124$
	ld	l,-2 (ix)
	ld	h,-1 (ix)
	ld	(hl),c
	inc	hl
	ld	(hl),b
	inc	hl
	ld	(hl),e
	inc	hl
	ld	(hl),d
00124$:
;fatFs\ff_fwrite.c:96: if (fp->flag & FA_DIRTY) {		/* Write-back sector cache */
	ld	l,-34 (ix)
	ld	h,-33 (ix)
	ld	a,(hl)
	rlca
	jr	NC,00128$
;fatFs\ff_fwrite.c:100: if (disk_write(fp->buf, fp->sect, 1) != RES_OK) ABORT(fs, FR_DISK_ERR);
	ld	l,-30 (ix)
	ld	h,-29 (ix)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	inc	hl
	ld	c,(hl)
	inc	hl
	ld	b,(hl)
	ld	hl,#0x0001
	push	hl
	push	bc
	push	de
	ld	l,-40 (ix)
	ld	h,-39 (ix)
	push	hl
	call	_disk_write
	pop	af
	pop	af
	pop	af
	pop	af
	ld	a,l
	or	a, a
	jr	Z,00126$
	ld	l,-28 (ix)
	ld	h,-27 (ix)
	ld	(hl),#0x01
	ld	l,#0x01
	jp	00151$
00126$:
;fatFs\ff_fwrite.c:102: fp->flag &= (BYTE)~FA_DIRTY;
	ld	l,-34 (ix)
	ld	h,-33 (ix)
	ld	a,(hl)
	and	a, #0x7F
	ld	l,-34 (ix)
	ld	h,-33 (ix)
	ld	(hl),a
00128$:
;fatFs\ff_fwrite.c:105: sect = clst2sect(fs, fp->clust);	/* Get current sector */
	ld	l,-26 (ix)
	ld	h,-25 (ix)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	inc	hl
	ld	c,(hl)
	inc	hl
	ld	b,(hl)
	push	bc
	push	de
	ld	l,-54 (ix)
	ld	h,-53 (ix)
	push	hl
	call	_clst2sect
	pop	af
	pop	af
	pop	af
;fatFs\ff_fwrite.c:106: if (sect == 0) ABORT(fs, FR_INT_ERR);
	ld	a,d
	or	a, e
	or	a, h
	or	a,l
	jr	NZ,00130$
	ld	l,-28 (ix)
	ld	h,-27 (ix)
	ld	(hl),#0x02
	ld	l,#0x02
	jp	00151$
00130$:
;fatFs\ff_fwrite.c:107: sect += csect;
	ld	a,-46 (ix)
	ld	-16 (ix),a
	ld	a,-45 (ix)
	ld	-15 (ix),a
	ld	-14 (ix),#0x00
	ld	-13 (ix),#0x00
	ld	a,l
	add	a, -16 (ix)
	ld	l,a
	ld	a,h
	adc	a, -15 (ix)
	ld	h,a
	ld	a,e
	adc	a, -14 (ix)
	ld	e,a
	ld	a,d
	adc	a, -13 (ix)
	ld	d,a
	ld	-50 (ix),l
	ld	-49 (ix),h
	ld	-48 (ix),e
	ld	-47 (ix),d
;fatFs\ff_fwrite.c:108: cc = btw / SS(fs);				/* When remaining bytes >= sector size, */
	ld	a,9 (ix)
	srl	a
	ld	c,a
	ld	b,#0x00
;fatFs\ff_fwrite.c:109: if (cc > 0) {					/* Write maximum contiguous sectors directly */
	ld	a,b
	or	a,c
	jp	Z,00138$
;fatFs\ff_fwrite.c:110: if (csect + cc > fs->csize) {	/* Clip at cluster boundary */
	ld	a,-46 (ix)
	add	a, c
	ld	e,a
	ld	a,-45 (ix)
	adc	a, b
	ld	d,a
	pop	hl
	push	hl
	push	bc
	ld	bc, #0x0008
	add	hl, bc
	pop	bc
	ld	a, (hl)
	inc	hl
	ld	l,(hl)
	ld	h,a
	sub	a, e
	ld	a,l
	sbc	a, d
	jr	NC,00132$
;fatFs\ff_fwrite.c:111: cc = fs->csize - csect;
	ld	a,h
	sub	a, -46 (ix)
	ld	c,a
	ld	a,l
	sbc	a, -45 (ix)
	ld	b,a
00132$:
;fatFs\ff_fwrite.c:116: if (disk_write(wbuff, sect, cc) != RES_OK) ABORT(fs, FR_DISK_ERR);
	push	bc
	push	bc
	ld	l,-48 (ix)
	ld	h,-47 (ix)
	push	hl
	ld	l,-50 (ix)
	ld	h,-49 (ix)
	push	hl
	ld	l,-52 (ix)
	ld	h,-51 (ix)
	push	hl
	call	_disk_write
	pop	af
	pop	af
	pop	af
	pop	af
	ld	a,l
	pop	bc
	or	a, a
	jr	Z,00134$
	ld	l,-28 (ix)
	ld	h,-27 (ix)
	ld	(hl),#0x01
	ld	l,#0x01
	jp	00151$
00134$:
;fatFs\ff_fwrite.c:125: if (fp->sect - sect < cc) { /* Refill sector cache if it gets invalidated by the direct write */
	ld	l,-36 (ix)
	ld	h,-35 (ix)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	inc	hl
	inc	hl
	ld	a,(hl)
	dec	hl
	ld	l,(hl)
	ld	h,a
	ld	a,e
	sub	a, -50 (ix)
	ld	-16 (ix),a
	ld	a,d
	sbc	a, -49 (ix)
	ld	-15 (ix),a
	ld	a,l
	sbc	a, -48 (ix)
	ld	-14 (ix),a
	ld	a,h
	sbc	a, -47 (ix)
	ld	-13 (ix),a
	ld	h,c
	ld	l,b
	ld	de,#0x0000
	ld	a,-16 (ix)
	sub	a, h
	ld	a,-15 (ix)
	sbc	a, l
	ld	a,-14 (ix)
	sbc	a, e
	ld	a,-13 (ix)
	sbc	a, d
	jr	NC,00136$
;fatFs\ff_fwrite.c:126: memcpy(fp->buf, wbuff + ((fp->sect - sect) * SS(fs)), SS(fs));
	push	af
	ld	l,-16 (ix)
	ld	h,-15 (ix)
	ld	d,-14 (ix)
	ld	e,-13 (ix)
	pop	af
	ld	a,#0x09
00266$:
	add	hl, hl
	rl	d
	rl	e
	dec	a
	jr	NZ,00266$
	ld	a,-52 (ix)
	add	a, l
	ld	l,a
	ld	a,-51 (ix)
	adc	a, h
	ld	h,a
	ld	e,-18 (ix)
	ld	d,-17 (ix)
	push	de
	pop	iy
	push	bc
	ld	de,#0x0200
	push	de
	push	hl
	push	iy
	call	_memcpy
	pop	af
	pop	af
	pop	af
	pop	bc
;fatFs\ff_fwrite.c:127: fp->flag &= (BYTE)~FA_DIRTY;
	ld	l,-34 (ix)
	ld	h,-33 (ix)
	ld	a,(hl)
	and	a, #0x7F
	ld	l,-34 (ix)
	ld	h,-33 (ix)
	ld	(hl),a
00136$:
;fatFs\ff_fwrite.c:131: wcnt = SS(fs) * cc;		/* Number of bytes transferred */
	ld	a,c
	add	a, a
	ld	d,a
	ld	e,#0x00
;fatFs\ff_fwrite.c:132: continue;
	jp	00147$
00138$:
;fatFs\ff_fwrite.c:140: if (fp->sect != sect && 		/* Fill sector cache with file data */
	ld	l,-42 (ix)
	ld	h,-41 (ix)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	inc	hl
	ld	b,(hl)
	inc	hl
	ld	c,(hl)
	ld	a,-50 (ix)
	sub	a, e
	jr	NZ,00268$
	ld	a,-49 (ix)
	sub	a, d
	jr	NZ,00268$
	ld	a,-48 (ix)
	sub	a, b
	jr	NZ,00268$
	ld	a,-47 (ix)
	sub	a, c
	jr	Z,00140$
00268$:
;fatFs\ff_fwrite.c:141: fp->fptr < fp->obj.objsize &&
	ld	e,-44 (ix)
	ld	d,-43 (ix)
	ld	hl, #0x0026
	add	hl, sp
	ex	de, hl
	ld	bc, #0x0004
	ldir
	ld	l,-22 (ix)
	ld	h,-21 (ix)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	inc	hl
	ld	b,(hl)
	inc	hl
	ld	h,(hl)
	ld	a,-16 (ix)
	sub	a, e
	ld	a,-15 (ix)
	sbc	a, d
	ld	a,-14 (ix)
	sbc	a, b
	ld	a,-13 (ix)
	sbc	a, h
	jr	NC,00140$
;fatFs\ff_fwrite.c:145: disk_read(fp->buf, sect, 1) != RES_OK) {
	ld	hl,#0x0001
	push	hl
	ld	l,-48 (ix)
	ld	h,-47 (ix)
	push	hl
	ld	l,-50 (ix)
	ld	h,-49 (ix)
	push	hl
	ld	l,-40 (ix)
	ld	h,-39 (ix)
	push	hl
	call	_disk_read
	pop	af
	pop	af
	pop	af
	pop	af
	ld	a,l
	or	a, a
	jr	Z,00140$
;fatFs\ff_fwrite.c:147: ABORT(fs, FR_DISK_ERR);
	ld	l,-28 (ix)
	ld	h,-27 (ix)
	ld	(hl),#0x01
	ld	l,#0x01
	jp	00151$
00140$:
;fatFs\ff_fwrite.c:150: fp->sect = sect;
	ld	e,-42 (ix)
	ld	d,-41 (ix)
	ld	hl, #0x0004
	add	hl, sp
	ld	bc, #0x0004
	ldir
00144$:
;fatFs\ff_fwrite.c:63: if ((!FF_FS_EXFAT || fs->fs_type != FS_EXFAT) && (DWORD)(fp->fptr + btw) < (DWORD)fp->fptr) {
	ld	e,-44 (ix)
	ld	d,-43 (ix)
	ld	hl, #0x0026
	add	hl, sp
	ex	de, hl
	ld	bc, #0x0004
	ldir
;fatFs\ff_fwrite.c:152: wcnt = SS(fs) - (UINT)fp->fptr % SS(fs);	/* Number of bytes left in the sector */
	ld	l,-16 (ix)
	ld	a, -15 (ix)
	and	a, #0x01
	ld	h,a
	xor	a, a
	sub	a, l
	ld	e,a
	ld	a,#0x02
	sbc	a, h
	ld	d,a
;fatFs\ff_fwrite.c:153: if (wcnt > btw) wcnt = btw;					/* Clip it by btw if needed */
	ld	a,8 (ix)
	sub	a, e
	ld	a,9 (ix)
	sbc	a, d
	jr	NC,00146$
	ld	e,8 (ix)
	ld	d,9 (ix)
00146$:
;fatFs\ff_fwrite.c:159: memcpy(fp->buf + fp->fptr % SS(fs), wbuff, wcnt);	/* Fit data to the sector */
	pop	bc
	pop	iy
	push	iy
	push	bc
	ld	l,-16 (ix)
	ld	a,-15 (ix)
	and	a, #0x01
	ld	h,a
	ld	a,-6 (ix)
	add	a, l
	ld	l,a
	ld	a,-5 (ix)
	adc	a, h
	ld	h,a
	push	de
	push	de
	push	iy
	push	hl
	call	_memcpy
	pop	af
	pop	af
	pop	af
	pop	de
;fatFs\ff_fwrite.c:160: fp->flag |= FA_DIRTY;
	ld	l,-34 (ix)
	ld	h,-33 (ix)
	ld	a,(hl)
	set	7, a
	ld	l,-34 (ix)
	ld	h,-33 (ix)
	ld	(hl),a
00147$:
;fatFs\ff_fwrite.c:68: btw -= wcnt, *bw += wcnt, wbuff += wcnt, fp->fptr += wcnt, fp->obj.objsize = (fp->fptr > fp->obj.objsize) ? fp->fptr : fp->obj.objsize) {
	ld	a,8 (ix)
	sub	a, e
	ld	8 (ix),a
	ld	a,9 (ix)
	sbc	a, d
	ld	9 (ix),a
	ld	l,-8 (ix)
	ld	h,-7 (ix)
	ld	a, (hl)
	inc	hl
	ld	h,(hl)
	ld	l,a
	add	hl,de
	ld	b,l
	ld	c,h
	ld	l,-8 (ix)
	ld	h,-7 (ix)
	ld	(hl),b
	inc	hl
	ld	(hl),c
	ld	a,-52 (ix)
	add	a, e
	ld	-52 (ix),a
	ld	a,-51 (ix)
	adc	a, d
	ld	-51 (ix),a
	push	de
	ld	e,-44 (ix)
	ld	d,-43 (ix)
	ld	hl, #0x0028
	add	hl, sp
	ex	de, hl
	ld	bc, #0x0004
	ldir
	pop	de
	ld	hl,#0x0000
	ld	a,-16 (ix)
	add	a, e
	ld	-16 (ix),a
	ld	a,-15 (ix)
	adc	a, d
	ld	-15 (ix),a
	ld	a,-14 (ix)
	adc	a, l
	ld	-14 (ix),a
	ld	a,-13 (ix)
	adc	a, h
	ld	-13 (ix),a
	ld	e,-44 (ix)
	ld	d,-43 (ix)
	ld	hl, #0x0026
	add	hl, sp
	ld	bc, #0x0004
	ldir
	ld	e,-44 (ix)
	ld	d,-43 (ix)
	ld	hl, #0x002A
	add	hl, sp
	ex	de, hl
	ld	bc, #0x0004
	ldir
	ld	l,-24 (ix)
	ld	h,-23 (ix)
	ld	c,(hl)
	inc	hl
	ld	b,(hl)
	inc	hl
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,c
	sub	a, -16 (ix)
	ld	a,b
	sbc	a, -15 (ix)
	ld	a,e
	sbc	a, -14 (ix)
	ld	a,d
	sbc	a, -13 (ix)
	jr	C,00154$
	ld	-12 (ix),c
	ld	-11 (ix),b
	ld	-10 (ix),e
	ld	-9 (ix),d
00154$:
	ld	e,-24 (ix)
	ld	d,-23 (ix)
	ld	hl, #0x002A
	add	hl, sp
	ld	bc, #0x0004
	ldir
	jp	00150$
00148$:
;fatFs\ff_fwrite.c:164: fp->flag |= FA_MODIFIED;				/* Set file change flag */
	ld	l,-34 (ix)
	ld	h,-33 (ix)
	ld	a,(hl)
	set	6, a
	ld	l,-34 (ix)
	ld	h,-33 (ix)
	ld	(hl),a
;fatFs\ff_fwrite.c:166: LEAVE_FF(fs, FR_OK);
	ld	l,#0x00
00151$:
	ld	sp, ix
	pop	ix
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
