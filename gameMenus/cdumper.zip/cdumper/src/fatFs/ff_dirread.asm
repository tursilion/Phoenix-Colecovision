;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 3.5.0 #9253 (Jun 20 2015) (MINGW64)
; This file was generated Thu Sep 12 23:57:29 2019
;--------------------------------------------------------
	.module ff_dirread
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _dir_next
	.globl _move_window
	.globl _dir_read
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\ff_dirread.c:46: FRESULT dir_read (
;	---------------------------------
; Function dir_read
; ---------------------------------
_dir_read::
	call	___sdcc_enter_ix
	ld	hl,#-9
	add	hl,sp
	ld	sp,hl
;fatFs\ff_dirread.c:51: FRESULT res = FR_NO_FILE;
	ld	-9 (ix),#0x04
;fatFs\ff_dirread.c:52: FATFS *fs = dp->obj.fs;
	ld	c,4 (ix)
	ld	b,5 (ix)
	ld	a,(bc)
	ld	-8 (ix),a
	inc	bc
	ld	a,(bc)
	ld	-7 (ix),a
	dec	bc
;fatFs\ff_dirread.c:58: while (dp->sect) {
	ld	hl,#0x0016
	add	hl,bc
	ld	-6 (ix),l
	ld	-5 (ix),h
00112$:
	push	bc
	ld	e,-6 (ix)
	ld	d,-5 (ix)
	ld	hl, #0x0007
	add	hl, sp
	ex	de, hl
	ld	bc, #0x0004
	ldir
	pop	bc
	ld	a,-1 (ix)
	or	a, -2 (ix)
	or	a, -3 (ix)
	or	a,-4 (ix)
	jp	Z,00114$
;fatFs\ff_dirread.c:59: res = move_window(fs, dp->sect);
	push	bc
	ld	l,-2 (ix)
	ld	h,-1 (ix)
	push	hl
	ld	l,-4 (ix)
	ld	h,-3 (ix)
	push	hl
	ld	l,-8 (ix)
	ld	h,-7 (ix)
	push	hl
	call	_move_window
	pop	af
	pop	af
	pop	af
	pop	bc
;fatFs\ff_dirread.c:60: if (res != FR_OK) {
	ld	-9 (ix), l
	ld	a, l
	or	a, a
	jr	NZ,00114$
;fatFs\ff_dirread.c:63: b = dp->dir[DIR_Name];	/* Test for the entry type */
	push	bc
	pop	iy
	ld	l,26 (iy)
	ld	h,27 (iy)
	ld	e,(hl)
;fatFs\ff_dirread.c:64: if (b == 0) {
	ld	a,e
	or	a, a
	jr	NZ,00104$
;fatFs\ff_dirread.c:65: res = FR_NO_FILE; 
	ld	-9 (ix),#0x04
;fatFs\ff_dirread.c:66: break; /* Reached to end of the directory */
	jr	00114$
00104$:
;fatFs\ff_dirread.c:86: dp->obj.attr = attr = dp->dir[DIR_Attr] & AM_MASK;	/* Get attribute */
	ld	iy,#0x0004
	add	iy, bc
	push	bc
	ld	bc, #0x000B
	add	hl, bc
	pop	bc
	ld	a,(hl)
	and	a, #0x3F
	ld	l,a
	ld	0 (iy), a
;fatFs\ff_dirread.c:107: if (b != DDEM && b != '.' && attr != AM_LFN && (int)((attr & ~AM_ARC) == AM_VOL) == vol) {	/* Is it a valid entry? */
	ld	a,e
	cp	a,#0xE5
	jr	Z,00106$
	sub	a, #0x2E
	jr	Z,00106$
	ld	a,l
	sub	a, #0x0F
	jr	Z,00106$
	ld	h,#0x00
	res	5, l
	ld	a,l
	sub	a,#0x08
	jr	NZ,00154$
	or	a,h
	jr	NZ,00154$
	ld	a,#0x01
	jr	00155$
00154$:
	xor	a,a
00155$:
	ld	d,a
	rla
	sbc	a, a
	ld	e,a
	ld	a,6 (ix)
	sub	a, d
	jr	NZ,00156$
	ld	a,7 (ix)
	sub	a, e
	jr	Z,00114$
00156$:
;fatFs\ff_dirread.c:108: break;
00106$:
;fatFs\ff_dirread.c:112: res = dir_next(dp, 0);		/* Next entry */
	push	bc
	ld	hl,#0x0000
	push	hl
	push	bc
	call	_dir_next
	pop	af
	pop	af
	pop	bc
;fatFs\ff_dirread.c:113: if (res != FR_OK) {
	ld	-9 (ix), l
	ld	a, l
	or	a, a
	jp	Z,00112$
;fatFs\ff_dirread.c:114: break;
00114$:
;fatFs\ff_dirread.c:118: if (res != FR_OK) {
	ld	a,-9 (ix)
	or	a, a
	jr	Z,00116$
;fatFs\ff_dirread.c:119: dp->sect = 0;		/* Terminate the read operation on error or EOT */
	ld	l,-6 (ix)
	ld	h,-5 (ix)
	xor	a, a
	ld	(hl), a
	inc	hl
	ld	(hl), a
	inc	hl
	xor	a, a
	ld	(hl), a
	inc	hl
	ld	(hl), a
00116$:
;fatFs\ff_dirread.c:121: return res;
	ld	l,-9 (ix)
	ld	sp, ix
	pop	ix
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
