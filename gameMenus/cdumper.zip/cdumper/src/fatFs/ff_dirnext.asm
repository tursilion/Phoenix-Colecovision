;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 3.5.0 #9253 (Jun 20 2015) (MINGW64)
; This file was generated Thu Sep 12 23:57:29 2019
;--------------------------------------------------------
	.module ff_dirnext
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _dir_clear
	.globl _create_chain
	.globl _get_fat
	.globl _clst2sect
	.globl _dir_next
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\ff_dirnext.c:42: FRESULT dir_next (	/* FR_OK(0):succeeded, FR_NO_FILE:End of table, FR_DENIED:Could not stretch */
;	---------------------------------
; Function dir_next
; ---------------------------------
_dir_next::
	call	___sdcc_enter_ix
	ld	hl,#-28
	add	hl,sp
	ld	sp,hl
;fatFs\ff_dirnext.c:48: FATFS *fs = dp->obj.fs;
	ld	a,4 (ix)
	ld	-16 (ix),a
	ld	a,5 (ix)
	ld	-15 (ix),a
	ld	l,-16 (ix)
	ld	h,-15 (ix)
	ld	a,(hl)
	ld	-24 (ix),a
	inc	hl
	ld	a,(hl)
	ld	-23 (ix),a
;fatFs\ff_dirnext.c:51: ofs = dp->dptr + SZDIRE;	/* Next entry */
	ld	a,-16 (ix)
	add	a, #0x0E
	ld	-18 (ix),a
	ld	a,-15 (ix)
	adc	a, #0x00
	ld	-17 (ix),a
	ld	l,-18 (ix)
	ld	h,-17 (ix)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	inc	hl
	ld	c,(hl)
	inc	hl
	ld	b,(hl)
	ld	a,e
	add	a, #0x20
	ld	-28 (ix),a
	ld	a,d
	adc	a, #0x00
	ld	-27 (ix),a
	ld	a,c
	adc	a, #0x00
	ld	-26 (ix),a
	ld	a,b
	adc	a, #0x00
	ld	-25 (ix),a
;fatFs\ff_dirnext.c:52: if (ofs >= (DWORD)((FF_FS_EXFAT && fs->fs_type == FS_EXFAT) ? MAX_DIR_EX : MAX_DIR)) dp->sect = 0;	/* Disable it if the offset reached the max value */
	ld	a,-16 (ix)
	add	a, #0x16
	ld	-14 (ix),a
	ld	a,-15 (ix)
	adc	a, #0x00
	ld	-13 (ix),a
	ld	a,-26 (ix)
	sub	a, #0x20
	ld	a,-25 (ix)
	sbc	a, #0x00
	jr	C,00102$
	ld	l,-14 (ix)
	ld	h,-13 (ix)
	ld	(hl),#0x00
	inc	hl
	ld	(hl),#0x00
	inc	hl
	ld	(hl),#0x00
	inc	hl
	ld	(hl),#0x00
00102$:
;fatFs\ff_dirnext.c:53: if (dp->sect == 0) return FR_NO_FILE;	/* Report EOT if it has been disabled */
	ld	e,-14 (ix)
	ld	d,-13 (ix)
	ld	hl, #0x0006
	add	hl, sp
	ex	de, hl
	ld	bc, #0x0004
	ldir
	ld	a,-19 (ix)
	or	a, -20 (ix)
	or	a, -21 (ix)
	or	a,-22 (ix)
	jr	NZ,00104$
	ld	l,#0x04
	jp	00132$
00104$:
;fatFs\ff_dirnext.c:55: if (ofs % SS(fs) == 0) {	/* Sector changed? */
	ld	a,-28 (ix)
	ld	-12 (ix),a
	ld	a,-27 (ix)
	and	a, #0x01
	ld	-11 (ix),a
	ld	-10 (ix),#0x00
	ld	-9 (ix), #0x00
	ld	a, #0x00
	or	a, -10 (ix)
	or	a, -11 (ix)
	or	a,-12 (ix)
	jp	NZ,00131$
;fatFs\ff_dirnext.c:56: dp->sect++;				/* Next sector */
	ld	a,-22 (ix)
	add	a, #0x01
	ld	d,a
	ld	a,-21 (ix)
	adc	a, #0x00
	ld	e,a
	ld	a,-20 (ix)
	adc	a, #0x00
	ld	b,a
	ld	a,-19 (ix)
	adc	a, #0x00
	ld	c,a
	ld	l,-14 (ix)
	ld	h,-13 (ix)
	ld	(hl),d
	inc	hl
	ld	(hl),e
	inc	hl
	ld	(hl),b
	inc	hl
	ld	(hl),c
;fatFs\ff_dirnext.c:58: if (dp->clust == 0) {	/* table */
	ld	a,-16 (ix)
	add	a, #0x12
	ld	-22 (ix),a
	ld	a,-15 (ix)
	adc	a, #0x00
	ld	-21 (ix),a
	ld	e,-22 (ix)
	ld	d,-21 (ix)
	ld	hl, #0x0014
	add	hl, sp
	ex	de, hl
	ld	bc, #0x0004
	ldir
	ld	a,-5 (ix)
	or	a, -6 (ix)
	or	a, -7 (ix)
	or	a,-8 (ix)
	jr	NZ,00128$
;fatFs\ff_dirnext.c:59: if (ofs / SZDIRE >= fs->n_rootdir) {	/* Report EOT if it reached end of table */
	push	af
	ld	e,-28 (ix)
	ld	d,-27 (ix)
	ld	c,-26 (ix)
	ld	b,-25 (ix)
	pop	af
	ld	a,#0x05
00196$:
	srl	b
	rr	c
	rr	d
	rr	e
	dec	a
	jr	NZ,00196$
	ld	l,-24 (ix)
	ld	h,-23 (ix)
	push	bc
	ld	bc, #0x0006
	add	hl, bc
	pop	bc
	ld	a, (hl)
	inc	hl
	ld	h,(hl)
	ld	-4 (ix), a
	ld	-3 (ix),h
	ld	-2 (ix),#0x00
	ld	-1 (ix),#0x00
	ld	a,e
	sub	a, -4 (ix)
	ld	a,d
	sbc	a, -3 (ix)
	ld	a,c
	sbc	a, -2 (ix)
	ld	a,b
	sbc	a, -1 (ix)
	jp	C,00131$
;fatFs\ff_dirnext.c:60: dp->sect = 0; return FR_NO_FILE;
	ld	l,-14 (ix)
	ld	h,-13 (ix)
	xor	a, a
	ld	(hl), a
	inc	hl
	ld	(hl), a
	inc	hl
	xor	a, a
	ld	(hl), a
	inc	hl
	ld	(hl), a
	ld	l,#0x04
	jp	00132$
00128$:
;fatFs\ff_dirnext.c:64: if ((ofs / SS(fs) & (fs->csize - 1)) == 0) {	/* Cluster changed? */
	push	af
	ld	e,-28 (ix)
	ld	d,-27 (ix)
	ld	c,-26 (ix)
	ld	b,-25 (ix)
	pop	af
	ld	a,#0x09
00198$:
	srl	b
	rr	c
	rr	d
	rr	e
	dec	a
	jr	NZ,00198$
	ld	l,-24 (ix)
	ld	h,-23 (ix)
	push	bc
	ld	bc, #0x0008
	add	hl, bc
	pop	bc
	ld	a, (hl)
	inc	hl
	ld	h,(hl)
	ld	l,a
	dec	hl
	ld	-4 (ix),l
	ld	-3 (ix),h
	ld	-2 (ix),#0x00
	ld	-1 (ix),#0x00
	ld	a,e
	and	a, -4 (ix)
	ld	l,a
	ld	a,d
	and	a, -3 (ix)
	ld	h,a
	ld	a,c
	and	a, -2 (ix)
	ld	e,a
	ld	a,b
	and	a, -1 (ix)
	or	a, e
	or	a, h
	or	a,l
	jp	NZ,00131$
;fatFs\ff_dirnext.c:65: clst = get_fat(&dp->obj, dp->clust);		/* Get next cluster */
	ld	l,-6 (ix)
	ld	h,-5 (ix)
	push	hl
	ld	l,-8 (ix)
	ld	h,-7 (ix)
	push	hl
	ld	l,-16 (ix)
	ld	h,-15 (ix)
	push	hl
	call	_get_fat
	pop	af
	pop	af
	pop	af
	ld	c,l
	ld	b,h
;fatFs\ff_dirnext.c:66: if (clst <= 1) return FR_INT_ERR;			/* Internal error */
	ld	a,#0x01
	cp	a, c
	ld	a,#0x00
	sbc	a, b
	ld	a,#0x00
	sbc	a, e
	ld	a,#0x00
	sbc	a, d
	jr	C,00108$
	ld	l,#0x02
	jp	00132$
00108$:
;fatFs\ff_dirnext.c:67: if (clst == 0xFFFFFFFF) return FR_DISK_ERR;	/* Disk error */
	ld	a,c
	inc	a
	jr	NZ,00110$
	ld	a,b
	inc	a
	jr	NZ,00110$
	ld	a,e
	inc	a
	jr	NZ,00110$
	ld	a,d
	inc	a
	jr	NZ,00110$
	ld	l,#0x01
	jp	00132$
00110$:
;fatFs\ff_dirnext.c:68: if (clst >= fs->n_fatent) {					/* It reached end of dynamic table */
	push	hl
	ld	l,-24 (ix)
	ld	h,-23 (ix)
	push	hl
	pop	iy
	pop	hl
	ld	a,18 (iy)
	ld	-4 (ix),a
	ld	a,19 (iy)
	ld	-3 (ix),a
	ld	a,20 (iy)
	ld	-2 (ix),a
	ld	a,21 (iy)
	ld	-1 (ix),a
	ld	a,c
	sub	a, -4 (ix)
	ld	a,b
	sbc	a, -3 (ix)
	ld	a,e
	sbc	a, -2 (ix)
	ld	a,d
	sbc	a, -1 (ix)
	jp	C,00124$
;fatFs\ff_dirnext.c:70: if (!stretch) {								/* If no stretch, report EOT */
	ld	a,7 (ix)
	or	a,6 (ix)
	jr	NZ,00112$
;fatFs\ff_dirnext.c:71: dp->sect = 0; return FR_NO_FILE;
	ld	l,-14 (ix)
	ld	h,-13 (ix)
	xor	a, a
	ld	(hl), a
	inc	hl
	ld	(hl), a
	inc	hl
	xor	a, a
	ld	(hl), a
	inc	hl
	ld	(hl), a
	ld	l,#0x04
	jp	00132$
00112$:
;fatFs\ff_dirnext.c:73: clst = create_chain(&dp->obj, dp->clust);	/* Allocate a cluster */
	ld	l,-22 (ix)
	ld	h,-21 (ix)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	inc	hl
	ld	c,(hl)
	inc	hl
	ld	b,(hl)
	push	bc
	push	de
	ld	l,-16 (ix)
	ld	h,-15 (ix)
	push	hl
	call	_create_chain
	pop	af
	pop	af
	pop	af
	ld	c,l
	ld	b,h
;fatFs\ff_dirnext.c:74: if (clst == 0) return FR_DENIED;			/* No free cluster */
	ld	a,d
	or	a, e
	or	a, b
	or	a,c
	jr	NZ,00114$
	ld	l,#0x07
	jp	00132$
00114$:
;fatFs\ff_dirnext.c:75: if (clst == 1) return FR_INT_ERR;			/* Internal error */
	ld	a,c
	dec	a
	jr	NZ,00116$
	ld	a,b
	or	a,a
	jr	NZ,00116$
	or	a,e
	jr	NZ,00116$
	or	a,d
	jr	NZ,00116$
	ld	l,#0x02
	jp	00132$
00116$:
;fatFs\ff_dirnext.c:76: if (clst == 0xFFFFFFFF) return FR_DISK_ERR;	/* Disk error */
	ld	a,c
	inc	a
	jr	NZ,00118$
	ld	a,b
	inc	a
	jr	NZ,00118$
	ld	a,e
	inc	a
	jr	NZ,00118$
	ld	a,d
	inc	a
	jr	NZ,00118$
	ld	l,#0x01
	jp	00132$
00118$:
;fatFs\ff_dirnext.c:77: if (dir_clear(fs, clst) != FR_OK) return FR_DISK_ERR;	/* Clean up the stretched table */
	push	bc
	push	de
	push	de
	push	bc
	ld	l,-24 (ix)
	ld	h,-23 (ix)
	push	hl
	call	_dir_clear
	pop	af
	pop	af
	pop	af
	ld	a,l
	pop	de
	pop	bc
	or	a, a
	jr	Z,00124$
	ld	l,#0x01
	jp	00132$
;fatFs\ff_dirnext.c:78: if (FF_FS_EXFAT) dp->obj.stat |= 4;			/* exFAT: The directory has been stretched */
00124$:
;fatFs\ff_dirnext.c:84: dp->clust = clst;		/* Initialize data for new cluster */
	ld	l,-22 (ix)
	ld	h,-21 (ix)
	ld	(hl),c
	inc	hl
	ld	(hl),b
	inc	hl
	ld	(hl),e
	inc	hl
	ld	(hl),d
;fatFs\ff_dirnext.c:85: dp->sect = clst2sect(fs, clst);
	push	de
	push	bc
	ld	l,-24 (ix)
	ld	h,-23 (ix)
	push	hl
	call	_clst2sect
	pop	af
	pop	af
	pop	af
	ld	b,l
	ld	c,h
	ld	l,-14 (ix)
	ld	h,-13 (ix)
	ld	(hl),b
	inc	hl
	ld	(hl),c
	inc	hl
	ld	(hl),e
	inc	hl
	ld	(hl),d
00131$:
;fatFs\ff_dirnext.c:89: dp->dptr = ofs;						/* Current entry */
	ld	e,-18 (ix)
	ld	d,-17 (ix)
	ld	hl, #0x0000
	add	hl, sp
	ld	bc, #0x0004
	ldir
;fatFs\ff_dirnext.c:90: dp->dir = fs->win + ofs % SS(fs);	/* Pointer to the entry in the win[] */
	ld	a,-16 (ix)
	add	a, #0x1A
	ld	-4 (ix),a
	ld	a,-15 (ix)
	adc	a, #0x00
	ld	-3 (ix),a
	ld	a,-24 (ix)
	add	a, #0x2E
	ld	-8 (ix),a
	ld	a,-23 (ix)
	adc	a, #0x00
	ld	-7 (ix),a
	ld	a,-8 (ix)
	add	a, -12 (ix)
	ld	-8 (ix),a
	ld	a,-7 (ix)
	adc	a, -11 (ix)
	ld	-7 (ix),a
	ld	l,-4 (ix)
	ld	h,-3 (ix)
	ld	a,-8 (ix)
	ld	(hl),a
	inc	hl
	ld	a,-7 (ix)
	ld	(hl),a
;fatFs\ff_dirnext.c:92: return FR_OK;
	ld	l,#0x00
00132$:
	ld	sp, ix
	pop	ix
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
