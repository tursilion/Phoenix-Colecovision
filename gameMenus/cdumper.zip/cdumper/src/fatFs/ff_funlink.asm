;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 3.5.0 #9253 (Jun 20 2015) (MINGW64)
; This file was generated Thu Sep 12 23:57:44 2019
;--------------------------------------------------------
	.module ff_funlink
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _dir_remove
	.globl _remove_chain
	.globl _sync_fs
	.globl _find_volume
	.globl _follow_path
	.globl _dir_read
	.globl _ld_clust
	.globl _dir_sdi
	.globl _f_unlink
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\ff_funlink.c:43: FRESULT f_unlink (
;	---------------------------------
; Function f_unlink
; ---------------------------------
_f_unlink::
	call	___sdcc_enter_ix
	ld	hl,#-97
	add	hl,sp
	ld	sp,hl
;fatFs\ff_funlink.c:49: DWORD dclst = 0;
	xor	a, a
	ld	-56 (ix),a
	ld	-55 (ix),a
	ld	-54 (ix),a
	ld	-53 (ix),a
;fatFs\ff_funlink.c:61: res = find_volume(&fs, FA_WRITE);
	ld	hl,#0x002D
	add	hl,sp
	ex	de,hl
	ld	a,#0x02
	push	af
	inc	sp
	push	de
	call	_find_volume
	pop	af
	inc	sp
;fatFs\ff_funlink.c:63: if (res == FR_OK) {
	ld	-97 (ix), l
	ld	a, l
	or	a, a
	jp	NZ,00130$
;fatFs\ff_funlink.c:64: dj.obj.fs = fs;
	ld	hl,#0x002F
	add	hl,sp
	ld	a,-52 (ix)
	ld	(hl),a
	inc	hl
	ld	a,-51 (ix)
	ld	(hl),a
;fatFs\ff_funlink.c:66: res = follow_path(&dj, path);		/* Follow the file path */
	ld	hl,#0x002F
	add	hl,sp
	ld	-4 (ix),l
	ld	-3 (ix),h
	ld	l,-4 (ix)
	ld	h,-3 (ix)
	ld	c,4 (ix)
	ld	b,5 (ix)
	push	bc
	push	hl
	call	_follow_path
	pop	af
	pop	af
;fatFs\ff_funlink.c:73: if (res == FR_OK) {					/* The object is accessible */
	ld	-97 (ix), l
	ld	a, l
	or	a, a
	jp	NZ,00130$
;fatFs\ff_funlink.c:74: if (dj.fn[NSFLAG] & NS_NONAME) {
	ld	l,-4 (ix)
	ld	h,-3 (ix)
	ld	de, #0x0027
	add	hl, de
	ld	h,(hl)
;fatFs\ff_funlink.c:77: if (dj.obj.attr & AM_RDO) {
	ld	a,-4 (ix)
	add	a, #0x04
	ld	-6 (ix),a
	ld	a,-3 (ix)
	adc	a, #0x00
	ld	-5 (ix),a
;fatFs\ff_funlink.c:74: if (dj.fn[NSFLAG] & NS_NONAME) {
	add	hl, hl
	jr	NC,00108$
;fatFs\ff_funlink.c:75: res = FR_INVALID_NAME;		/* Cannot remove the origin directory */
	ld	-97 (ix),#0x06
	jr	00109$
00108$:
;fatFs\ff_funlink.c:77: if (dj.obj.attr & AM_RDO) {
	ld	l,-6 (ix)
	ld	h,-5 (ix)
	ld	a,(hl)
	rrca
	jr	NC,00109$
;fatFs\ff_funlink.c:78: res = FR_DENIED;		/* Cannot remove R/O object */
	ld	-97 (ix),#0x07
00109$:
;fatFs\ff_funlink.c:81: if (res == FR_OK) {
	ld	a,-97 (ix)
	or	a, a
	jp	NZ,00119$
;fatFs\ff_funlink.c:90: dclst = ld_clust(fs, dj.dir);
	ld	a,-4 (ix)
	ld	-2 (ix),a
	ld	a,-3 (ix)
	ld	-1 (ix),a
	ld	l,-2 (ix)
	ld	h,-1 (ix)
	ld	de, #0x001A
	add	hl, de
	ld	a,(hl)
	ld	-2 (ix),a
	inc	hl
	ld	a,(hl)
	ld	-1 (ix),a
	ld	l,-2 (ix)
	ld	h,-1 (ix)
	push	hl
	ld	l,-52 (ix)
	ld	h,-51 (ix)
	push	hl
	call	_ld_clust
	pop	af
	pop	af
	ld	-7 (ix),d
	ld	-8 (ix),e
	ld	-9 (ix),h
	ld	-10 (ix),l
	ld	hl, #41
	add	hl, sp
	ex	de, hl
	ld	hl, #87
	add	hl, sp
	ld	bc, #4
	ldir
;fatFs\ff_funlink.c:92: if (dj.obj.attr & AM_DIR) {			/* Is it a sub-directory? */
	ld	l,-6 (ix)
	ld	h,-5 (ix)
	bit	4,(hl)
	jr	Z,00119$
;fatFs\ff_funlink.c:99: sdj.obj.fs = fs;				/* Open the sub-directory */
	ld	hl,#0x0001
	add	hl,sp
	ld	a,-52 (ix)
	ld	(hl),a
	inc	hl
	ld	a,-51 (ix)
	ld	(hl),a
;fatFs\ff_funlink.c:100: sdj.obj.sclust = dclst;
	ld	bc,#0x0006-1
	add	hl,bc
	ex	de,hl
	ld	hl, #0x0029
	add	hl, sp
	ld	bc, #0x0004
	ldir
;fatFs\ff_funlink.c:107: res = dir_sdi(&sdj, 0);
	ld	hl,#0x0001
	add	hl,sp
	ex	de,hl
	ld	c, e
	ld	b, d
	push	de
	ld	hl,#0x0000
	push	hl
	ld	hl,#0x0000
	push	hl
	push	bc
	call	_dir_sdi
	pop	af
	pop	af
	pop	af
	pop	de
;fatFs\ff_funlink.c:108: if (res == FR_OK) {
	ld	-97 (ix), l
	ld	a, l
	or	a, a
	jr	NZ,00119$
;fatFs\ff_funlink.c:109: res = DIR_READ_FILE(&sdj);			/* Test if the directory is empty */
	ld	hl,#0x0000
	push	hl
	push	de
	call	_dir_read
	pop	af
	pop	af
;fatFs\ff_funlink.c:110: if (res == FR_OK) res = FR_DENIED;	/* Not empty? */
	ld	-97 (ix), l
	ld	a, l
	or	a, a
	jr	NZ,00111$
	ld	-97 (ix),#0x07
00111$:
;fatFs\ff_funlink.c:111: if (res == FR_NO_FILE) res = FR_OK;	/* Empty? */
	ld	a,-97 (ix)
	sub	a, #0x04
	jr	NZ,00119$
	ld	-97 (ix),#0x00
00119$:
;fatFs\ff_funlink.c:116: if (res == FR_OK) {
	ld	a,-97 (ix)
	or	a, a
	jr	NZ,00130$
;fatFs\ff_funlink.c:117: res = dir_remove(&dj);			/* Remove the directory entry */
	ld	l,-4 (ix)
	ld	h,-3 (ix)
	push	hl
	call	_dir_remove
	pop	af
;fatFs\ff_funlink.c:118: if (res == FR_OK && dclst != 0) {	/* Remove the cluster chain if exist */
	ld	-97 (ix), l
	ld	a, l
	or	a, a
	jr	NZ,00121$
	ld	a,-53 (ix)
	or	a, -54 (ix)
	or	a, -55 (ix)
	or	a,-56 (ix)
	jr	Z,00121$
;fatFs\ff_funlink.c:122: res = remove_chain(&dj.obj, dclst, 0);
	ld	e,-4 (ix)
	ld	d,-3 (ix)
	ld	hl,#0x0000
	push	hl
	ld	hl,#0x0000
	push	hl
	ld	l,-54 (ix)
	ld	h,-53 (ix)
	push	hl
	ld	l,-56 (ix)
	ld	h,-55 (ix)
	push	hl
	push	de
	call	_remove_chain
	ld	iy,#10
	add	iy,sp
	ld	sp,iy
	ld	-97 (ix),l
00121$:
;fatFs\ff_funlink.c:125: if (res == FR_OK) res = sync_fs(fs);
	ld	a,-97 (ix)
	or	a, a
	jr	NZ,00130$
	ld	l,-52 (ix)
	ld	h,-51 (ix)
	push	hl
	call	_sync_fs
	pop	af
	ld	-97 (ix),l
00130$:
;fatFs\ff_funlink.c:131: LEAVE_FF(fs, res);
	ld	l,-97 (ix)
	ld	sp, ix
	pop	ix
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
