;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 3.5.0 #9253 (Jun 20 2015) (MINGW64)
; This file was generated Thu Sep 12 23:57:55 2019
;--------------------------------------------------------
	.module ff_putfat
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _st_dword
	.globl _st_word
	.globl _move_window
	.globl _ld_dword
	.globl _put_fat
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\ff_putfat.c:43: FRESULT put_fat (	/* FR_OK(0):succeeded, !=0:error */
;	---------------------------------
; Function put_fat
; ---------------------------------
_put_fat::
	call	___sdcc_enter_ix
	ld	hl,#-9
	add	hl,sp
	ld	sp,hl
;fatFs\ff_putfat.c:53: FRESULT res = FR_INT_ERR;
	ld	-9 (ix),#0x02
;fatFs\ff_putfat.c:55: if (clst >= 2 && clst < fs->n_fatent) {	/* Check if in valid range */
	ld	a,6 (ix)
	sub	a, #0x02
	ld	a,7 (ix)
	sbc	a, #0x00
	ld	a,8 (ix)
	sbc	a, #0x00
	ld	a,9 (ix)
	sbc	a, #0x00
	jp	C,00112$
	ld	e,4 (ix)
	ld	d,5 (ix)
	ld	l, e
	ld	h, d
	ld	bc, #0x0012
	add	hl, bc
	ld	c,(hl)
	inc	hl
	ld	b,(hl)
	inc	hl
	inc	hl
	ld	a,(hl)
	dec	hl
	ld	h,(hl)
	ld	l,a
	ld	a,6 (ix)
	sub	a, c
	ld	a,7 (ix)
	sbc	a, b
	ld	a,8 (ix)
	sbc	a, h
	ld	a,9 (ix)
	sbc	a, l
	jp	NC,00112$
;fatFs\ff_putfat.c:56: switch (fs->fs_type) {
	ld	a,(de)
	ld	c,a
;fatFs\ff_putfat.c:74: res = move_window(fs, fs->fatbase + (clst / (SS(fs) / 2)));
	push	de
	pop	iy
;fatFs\ff_putfat.c:76: st_word(fs->win + clst * 2 % SS(fs), (WORD)val);	/* Simple WORD array */
	ld	hl,#0x002E
	add	hl,de
	ld	-2 (ix),l
	ld	-1 (ix),h
;fatFs\ff_putfat.c:77: fs->wflag = 1;
	ld	hl,#0x0002
	add	hl,de
	ld	-4 (ix),l
	ld	-3 (ix),h
;fatFs\ff_putfat.c:74: res = move_window(fs, fs->fatbase + (clst / (SS(fs) / 2)));
	ld	a,30 (iy)
	ld	-8 (ix),a
	ld	a,31 (iy)
	ld	-7 (ix),a
	ld	a,32 (iy)
	ld	-6 (ix),a
	ld	a,33 (iy)
	ld	-5 (ix),a
;fatFs\ff_putfat.c:56: switch (fs->fs_type) {
	ld	a,c
	sub	a, #0x02
	jr	Z,00101$
	ld	a,c
	sub	a, #0x03
	jr	Z,00104$
	jp	00112$
;fatFs\ff_putfat.c:73: case FS_FAT16 :
00101$:
;fatFs\ff_putfat.c:74: res = move_window(fs, fs->fatbase + (clst / (SS(fs) / 2)));
	push	af
	ld	c,6 (ix)
	ld	b,7 (ix)
	ld	l,8 (ix)
	ld	h,9 (ix)
	pop	af
	ld	a,#0x08
00142$:
	srl	h
	rr	l
	rr	b
	rr	c
	dec	a
	jr	NZ,00142$
	ld	a,-8 (ix)
	add	a, c
	ld	c,a
	ld	a,-7 (ix)
	adc	a, b
	ld	b,a
	ld	a,-6 (ix)
	adc	a, l
	ld	l,a
	ld	a,-5 (ix)
	adc	a, h
	ld	h,a
	push	hl
	push	bc
	push	de
	call	_move_window
	pop	af
	pop	af
	pop	af
;fatFs\ff_putfat.c:75: if (res != FR_OK) break;
	ld	-9 (ix), l
	ld	a, l
	or	a, a
	jp	NZ,00112$
;fatFs\ff_putfat.c:76: st_word(fs->win + clst * 2 % SS(fs), (WORD)val);	/* Simple WORD array */
	ld	e,10 (ix)
	ld	d,11 (ix)
	push	af
	ld	l,6 (ix)
	ld	h,7 (ix)
	ld	c,8 (ix)
	ld	b,9 (ix)
	pop	af
	add	hl, hl
	rl	c
	rl	b
	ld	a,h
	and	a, #0x01
	ld	h,a
	ld	a,-2 (ix)
	add	a, l
	ld	l,a
	ld	a,-1 (ix)
	adc	a, h
	ld	h,a
	push	de
	push	hl
	call	_st_word
	pop	af
	pop	af
;fatFs\ff_putfat.c:77: fs->wflag = 1;
	ld	l,-4 (ix)
	ld	h,-3 (ix)
	ld	(hl),#0x01
;fatFs\ff_putfat.c:78: break;
	jp	00112$
;fatFs\ff_putfat.c:80: case FS_FAT32 :
00104$:
;fatFs\ff_putfat.c:84: res = move_window(fs, fs->fatbase + (clst / (SS(fs) / 4)));
	push	af
	ld	c,6 (ix)
	ld	b,7 (ix)
	ld	l,8 (ix)
	ld	h,9 (ix)
	pop	af
	ld	a,#0x07
00146$:
	srl	h
	rr	l
	rr	b
	rr	c
	dec	a
	jr	NZ,00146$
	ld	a,-8 (ix)
	add	a, c
	ld	c,a
	ld	a,-7 (ix)
	adc	a, b
	ld	b,a
	ld	a,-6 (ix)
	adc	a, l
	ld	l,a
	ld	a,-5 (ix)
	adc	a, h
	ld	h,a
	push	hl
	push	bc
	push	de
	call	_move_window
	pop	af
	pop	af
	pop	af
;fatFs\ff_putfat.c:85: if (res != FR_OK) break;
	ld	-9 (ix), l
	ld	a, l
	or	a, a
	jp	NZ,00112$
;fatFs\ff_putfat.c:87: val = (val & 0x0FFFFFFF) | (ld_dword(fs->win + clst * 4 % SS(fs)) & 0xF0000000);
	ld	a,10 (ix)
	ld	-8 (ix),a
	ld	a,11 (ix)
	ld	-7 (ix),a
	ld	a,12 (ix)
	ld	-6 (ix),a
	ld	a,13 (ix)
	and	a, #0x0F
	ld	-5 (ix),a
	push	af
	ld	l,6 (ix)
	ld	h,7 (ix)
	ld	d,8 (ix)
	ld	c,9 (ix)
	pop	af
	ld	b,#0x02
00148$:
	add	hl, hl
	rl	d
	rl	c
	djnz	00148$
	ld	a,h
	and	a, #0x01
	ld	h,a
	ld	a,-2 (ix)
	add	a, l
	ld	c,a
	ld	a,-1 (ix)
	adc	a, h
	ld	b,a
	push	bc
	push	bc
	call	_ld_dword
	pop	af
	pop	bc
	ld	hl,#0x0000
	ld	e,#0x00
	ld	a,d
	and	a, #0xF0
	ld	d,a
	ld	a,l
	or	a, -8 (ix)
	ld	l,a
	ld	a,h
	or	a, -7 (ix)
	ld	h,a
	ld	a,e
	or	a, -6 (ix)
	ld	e,a
	ld	a,d
	or	a, -5 (ix)
	ld	d,a
	ld	10 (ix),l
	ld	11 (ix),h
	ld	12 (ix),e
	ld	13 (ix),d
;fatFs\ff_putfat.c:89: st_dword(fs->win + clst * 4 % SS(fs), val);
	ld	l,12 (ix)
	ld	h,13 (ix)
	push	hl
	ld	l,10 (ix)
	ld	h,11 (ix)
	push	hl
	push	bc
	call	_st_dword
	pop	af
	pop	af
	pop	af
;fatFs\ff_putfat.c:90: fs->wflag = 1;
	ld	l,-4 (ix)
	ld	h,-3 (ix)
	ld	(hl),#0x01
;fatFs\ff_putfat.c:92: }
00112$:
;fatFs\ff_putfat.c:94: return res;
	ld	l,-9 (ix)
	ld	sp, ix
	pop	ix
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
