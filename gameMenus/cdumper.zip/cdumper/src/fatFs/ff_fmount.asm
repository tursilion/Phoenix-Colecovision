;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 3.5.0 #9253 (Jun 20 2015) (MINGW64)
; This file was generated Thu Sep 12 23:57:37 2019
;--------------------------------------------------------
	.module ff_fmount
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _find_volume
	.globl _f_mount
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\ff_fmount.c:42: FRESULT f_mount (
;	---------------------------------
; Function f_mount
; ---------------------------------
_f_mount::
	call	___sdcc_enter_ix
;fatFs\ff_fmount.c:57: cfs = FatFs[vol];					/* Pointer to fs object */
	ld	hl, (#_FatFs + 0)
	ld	e, l
;fatFs\ff_fmount.c:59: if (cfs) {
	ld	a,h
	ld	d,a
	or	a,l
	jr	Z,00104$
;fatFs\ff_fmount.c:66: cfs->fs_type = 0;				/* Clear old fs object */
	xor	a, a
	ld	(de),a
00104$:
;fatFs\ff_fmount.c:69: if (fs) {
	ld	a,5 (ix)
	or	a,4 (ix)
	jr	Z,00106$
;fatFs\ff_fmount.c:70: fs->fs_type = 0;				/* Clear new fs object */
	ld	l,4 (ix)
	ld	h,5 (ix)
	ld	(hl),#0x00
00106$:
;fatFs\ff_fmount.c:75: FatFs[vol] = fs;					/* Register new fs object */
	ld	hl,#_FatFs
	ld	a,4 (ix)
	ld	(hl),a
	inc	hl
	ld	a,5 (ix)
	ld	(hl),a
;fatFs\ff_fmount.c:77: if (opt == 0) return FR_OK;			/* Do not mount now, it will be mounted later */
	ld	a,8 (ix)
	or	a,a
	jr	NZ,00108$
	ld	l,a
	jr	00109$
00108$:
;fatFs\ff_fmount.c:82: res = find_volume(&fs, 0);	/* Force mounted the volume */
	ld	hl,#0x0004
	add	hl,sp
	ex	de,hl
	xor	a, a
	push	af
	inc	sp
	push	de
	call	_find_volume
	pop	af
	inc	sp
;fatFs\ff_fmount.c:84: LEAVE_FF(fs, res);
00109$:
	pop	ix
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
