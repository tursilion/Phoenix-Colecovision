;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 3.5.0 #9253 (Jun 20 2015) (MINGW64)
; This file was generated Thu Sep 12 23:57:21 2019
;--------------------------------------------------------
	.module diskio_sendcmd
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _select
	.globl _deselect
	.globl _rcvr_mmc
	.globl _xmit_mmc
	.globl _send_cmd
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
_sgmPSGAddressWrite	=	0x0050
_sgmPSGDataWrite	=	0x0051
_sgmPSGDataRead	=	0x0052
_sgmConfig	=	0x0053
_phRAMBankSelect	=	0x0054
_phBankingScheme	=	0x0055
_phSDControl	=	0x0056
_phSDData	=	0x0057
_phMachineID	=	0x0058
_phCartMask	=	0x0059
_sgmBIOSMap	=	0x007f
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\diskio_sendcmd.c:27: BYTE send_cmd (		/* Returns command response (bit7==1:Send failed)*/
;	---------------------------------
; Function send_cmd
; ---------------------------------
_send_cmd::
	call	___sdcc_enter_ix
	ld	hl,#-10
	add	hl,sp
	ld	sp,hl
;fatFs\diskio_sendcmd.c:34: if (cmd & 0x80) {	/* ACMD<n> is the command sequense of CMD55-CMD<n> */
	bit	7, 4 (ix)
	jr	Z,00104$
;fatFs\diskio_sendcmd.c:35: cmd &= 0x7F;
	res	7, 4 (ix)
;fatFs\diskio_sendcmd.c:36: n = send_cmd(CMD55, 0);
	ld	hl,#0x0000
	push	hl
	ld	hl,#0x0000
	push	hl
	ld	a,#0x37
	push	af
	inc	sp
	call	_send_cmd
	pop	af
	pop	af
	inc	sp
;fatFs\diskio_sendcmd.c:37: if (n > 1) return n;
	ld	a,#0x01
	sub	a, l
	jp	C,00119$
00104$:
;fatFs\diskio_sendcmd.c:41: if (cmd != CMD12) {
	ld	a,4 (ix)
	sub	a, #0x0C
	jr	NZ,00159$
	ld	a,#0x01
	jr	00160$
00159$:
	xor	a,a
00160$:
	ld	-1 (ix), a
	or	a, a
	jr	NZ,00108$
;fatFs\diskio_sendcmd.c:42: deselect();
	call	_deselect
;fatFs\diskio_sendcmd.c:43: if (!select()) return 0xFF;
	call	_select
	ld	a,h
	or	a,l
	jr	NZ,00108$
	ld	l,#0xFF
	jp	00119$
00108$:
;fatFs\diskio_sendcmd.c:47: buf[0] = 0x40 | cmd;			/* Start + Command index */
	ld	hl,#0x0001
	add	hl,sp
	ld	b,l
	ld	e,h
	ld	a,4 (ix)
	set	6, a
	ld	l, b
	ld	h, e
	ld	(hl),a
;fatFs\diskio_sendcmd.c:48: buf[1] = (BYTE)(arg >> 24);		/* Argument[31..24] */
	ld	a,b
	add	a, #0x01
	ld	-3 (ix),a
	ld	a,e
	adc	a, #0x00
	ld	-2 (ix),a
	push	af
	ld	d,5 (ix)
	ld	h,6 (ix)
	ld	l,7 (ix)
	ld	c,8 (ix)
	pop	af
	ld	a,#0x18
00161$:
	srl	c
	rr	l
	rr	h
	rr	d
	dec	a
	jr	NZ,00161$
	ld	l,-3 (ix)
	ld	h,-2 (ix)
	ld	(hl),d
;fatFs\diskio_sendcmd.c:49: buf[2] = (BYTE)(arg >> 16);		/* Argument[23..16] */
	ld	a,b
	add	a, #0x02
	ld	-3 (ix),a
	ld	a,e
	adc	a, #0x00
	ld	-2 (ix),a
	push	af
	ld	d,5 (ix)
	ld	h,6 (ix)
	ld	l,7 (ix)
	ld	c,8 (ix)
	pop	af
	ld	a,#0x10
00163$:
	srl	c
	rr	l
	rr	h
	rr	d
	dec	a
	jr	NZ,00163$
	ld	l,-3 (ix)
	ld	h,-2 (ix)
	ld	(hl),d
;fatFs\diskio_sendcmd.c:50: buf[3] = (BYTE)(arg >> 8);		/* Argument[15..8] */
	ld	a,b
	add	a, #0x03
	ld	-3 (ix),a
	ld	a,e
	adc	a, #0x00
	ld	-2 (ix),a
	push	af
	ld	d,5 (ix)
	ld	h,6 (ix)
	ld	l,7 (ix)
	ld	c,8 (ix)
	pop	af
	ld	a,#0x08
00165$:
	srl	c
	rr	l
	rr	h
	rr	d
	dec	a
	jr	NZ,00165$
	ld	l,-3 (ix)
	ld	h,-2 (ix)
	ld	(hl),d
;fatFs\diskio_sendcmd.c:51: buf[4] = (BYTE)arg;				/* Argument[7..0] */
	ld	a,b
	add	a, #0x04
	ld	l,a
	ld	a,e
	adc	a, #0x00
	ld	h,a
	ld	a,5 (ix)
	ld	(hl),a
;fatFs\diskio_sendcmd.c:52: n = 0x01;						/* Dummy CRC + Stop */
	ld	d,#0x01
;fatFs\diskio_sendcmd.c:53: if (cmd == CMD0) n = 0x95;		/* (valid CRC for CMD0(0)) */
	ld	a,4 (ix)
	or	a, a
	jr	NZ,00110$
	ld	d,#0x95
00110$:
;fatFs\diskio_sendcmd.c:54: if (cmd == CMD8) n = 0x87;		/* (valid CRC for CMD8(0x1AA)) */
	ld	a,4 (ix)
	sub	a, #0x08
	jr	NZ,00112$
	ld	d,#0x87
00112$:
;fatFs\diskio_sendcmd.c:55: buf[5] = n;
	ld	a,b
	add	a, #0x05
	ld	l,a
	ld	a,e
	adc	a, #0x00
	ld	h,a
	ld	(hl),d
;fatFs\diskio_sendcmd.c:56: xmit_mmc(buf, 6);
	ld	l, b
	ld	h, e
	ld	bc,#0x0006
	push	bc
	push	hl
	call	_xmit_mmc
	pop	af
	pop	af
;fatFs\diskio_sendcmd.c:59: if (cmd == CMD12) rcvr_mmc(&d, 1);	/* Skip a stuff byte when stop reading */
	ld	a,-1 (ix)
	or	a, a
	jr	Z,00129$
	ld	hl,#0x0000
	add	hl,sp
	ld	bc,#0x0001
	push	bc
	push	hl
	call	_rcvr_mmc
	pop	af
	pop	af
;fatFs\diskio_sendcmd.c:61: do {
00129$:
	ld	d,#0x0A
00116$:
;fatFs\diskio_sendcmd.c:62: rcvr_mmc(&d, 1);
	ld	hl,#0x0000
	add	hl,sp
	push	de
	ld	bc,#0x0001
	push	bc
	push	hl
	call	_rcvr_mmc
	pop	af
	pop	af
	pop	de
;fatFs\diskio_sendcmd.c:63: } while ((d & 0x80) && --n);
	bit	7, -10 (ix)
	jr	Z,00118$
	dec d
	jr	NZ,00116$
00118$:
;fatFs\diskio_sendcmd.c:65: return d;			/* Return with the response value */
	ld	l,-10 (ix)
00119$:
	ld	sp, ix
	pop	ix
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
