;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 3.5.0 #9253 (Jun 20 2015) (MINGW64)
; This file was generated Thu Sep 12 23:57:34 2019
;--------------------------------------------------------
	.module ff_findvolume
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _disk_status
	.globl _disk_initialize
	.globl _check_fs
	.globl _move_window
	.globl _ld_dword
	.globl _find_volume
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\ff_findvolume.c:42: FRESULT find_volume (	    /* FR_OK(0): successful, !=0: an error occurred */
;	---------------------------------
; Function find_volume
; ---------------------------------
_find_volume::
	call	___sdcc_enter_ix
	ld	hl,#-72
	add	hl,sp
	ld	sp,hl
;fatFs\ff_findvolume.c:60: *rfs = 0;
	ld	c,4 (ix)
	ld	b,5 (ix)
	ld	l, c
	ld	h, b
	xor	a, a
	ld	(hl), a
	inc	hl
	ld	(hl), a
;fatFs\ff_findvolume.c:70: fs = FatFs[vol];					/* Get pointer to the filesystem object */
	ld	hl,#_FatFs+0
	ld	a,(hl)
	ld	-72 (ix),a
	inc	hl
	ld	a,(hl)
;fatFs\ff_findvolume.c:71: if (!fs) return FR_NOT_ENABLED;		/* Is the filesystem object available? */
	ld	-71 (ix), a
	or	a,-72 (ix)
	jr	NZ,00104$
	ld	l,#0x0C
	jp	00184$
00104$:
;fatFs\ff_findvolume.c:75: *rfs = fs;							/* Return pointer to the filesystem object */
	ld	a,-72 (ix)
	ld	(bc),a
	inc	bc
	ld	a,-71 (ix)
	ld	(bc),a
;fatFs\ff_findvolume.c:77: mode &= (BYTE)~FA_READ;				/* Desired access mode, write access or not */
	res	0, 6 (ix)
;fatFs\ff_findvolume.c:78: if (fs->fs_type != 0) {				/* If the volume has been mounted */
	pop	hl
	push	hl
	ld	a,(hl)
	or	a, a
	jr	Z,00112$
;fatFs\ff_findvolume.c:82: stat = disk_status();
	call	_disk_status
;fatFs\ff_findvolume.c:84: if (!(stat & STA_NOINIT)) {		/* and the physical drive is kept initialized */
	bit	0, l
	jr	NZ,00112$
;fatFs\ff_findvolume.c:85: if (!FF_FS_READONLY && mode && (stat & STA_PROTECT)) {	/* Check write protection if needed */
	ld	a,6 (ix)
	or	a, a
	jr	Z,00106$
	bit	2, l
	jr	Z,00106$
;fatFs\ff_findvolume.c:86: return FR_WRITE_PROTECTED;
	ld	l,#0x0A
	jp	00184$
00106$:
;fatFs\ff_findvolume.c:88: return FR_OK;				/* The filesystem object is valid */
	ld	l,#0x00
	jp	00184$
00112$:
;fatFs\ff_findvolume.c:95: fs->fs_type = 0;					/* Clear the filesystem object */
	pop	hl
	push	hl
	ld	(hl),#0x00
;fatFs\ff_findvolume.c:100: stat = disk_initialize();	        /* Initialize the physical drive */
	call	_disk_initialize
;fatFs\ff_findvolume.c:102: if (stat & STA_NOINIT) { 			/* Check if the initialization succeeded */
	bit	0, l
	jr	Z,00117$
;fatFs\ff_findvolume.c:103: return FR_NOT_READY;			/* Failed to initialize due to no medium or hard error */
	ld	l,#0x03
	jp	00184$
;fatFs\ff_findvolume.c:105: if (!FF_FS_READONLY && mode && (stat & STA_PROTECT)) { /* Check disk write protection if needed */
00117$:
	ld	a,6 (ix)
	or	a, a
	jr	Z,00116$
	bit	2, l
	jr	Z,00116$
;fatFs\ff_findvolume.c:106: return FR_WRITE_PROTECTED;
	ld	l,#0x0A
	jp	00184$
00116$:
;fatFs\ff_findvolume.c:118: bsect = 0;
	ld	bc,#0x0000
	ld	de,#0x0000
;fatFs\ff_findvolume.c:119: fmt = check_fs(fs, bsect);			/* Load sector 0 and check if it is an FAT-VBR as SFD */
	push	bc
	push	de
	ld	hl,#0x0000
	push	hl
	ld	hl,#0x0000
	push	hl
	ld	l,-72 (ix)
	ld	h,-71 (ix)
	push	hl
	call	_check_fs
	pop	af
	pop	af
	pop	af
	pop	de
	pop	bc
;fatFs\ff_findvolume.c:120: if (fmt == 2 || (fmt < 2 && LD2PT(vol) != 0)) {	/* Not an FAT-VBR or forced partition number */
	ld	-9 (ix), l
	ld	a, l
	sub	a, #0x02
	jp	NZ,00128$
;fatFs\ff_findvolume.c:121: for (i = 0; i < 4; i++) {		/* Get partition offset */
	ld	a,-72 (ix)
	add	a, #0x2E
	ld	c,a
	ld	a,-71 (ix)
	adc	a, #0x00
	ld	b,a
	ld	hl,#0x0008
	add	hl,sp
	ld	-13 (ix),l
	ld	-12 (ix),h
	ld	-35 (ix),#0x00
	ld	-34 (ix),#0x00
00182$:
;fatFs\ff_findvolume.c:122: pt = fs->win + (MBR_Table + i * SZ_PTE);
	ld	l,-35 (ix)
	ld	h,-34 (ix)
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	ld	de,#0x01BE
	add	hl,de
	add	hl,bc
	ld	-70 (ix),l
	ld	-69 (ix),h
;fatFs\ff_findvolume.c:123: br[i] = pt[PTE_System] ? ld_dword(pt + PTE_StLba) : 0;
	ld	l,-35 (ix)
	ld	h,-34 (ix)
	add	hl, hl
	add	hl, hl
	ld	a,-13 (ix)
	add	a, l
	ld	-11 (ix),a
	ld	a,-12 (ix)
	adc	a, h
	ld	-10 (ix),a
	pop	de
	pop	hl
	push	hl
	push	de
	ld	de, #0x0004
	add	hl, de
	ld	a, (hl)
	or	a, a
	jr	Z,00186$
	ld	a,-70 (ix)
	add	a, #0x08
	ld	l,a
	ld	a,-69 (ix)
	adc	a, #0x00
	ld	h,a
	push	bc
	push	hl
	call	_ld_dword
	pop	af
	pop	bc
	ld	-21 (ix),l
	ld	-20 (ix),h
	ld	-19 (ix),e
	ld	-18 (ix),d
	jr	00187$
00186$:
	xor	a, a
	ld	-21 (ix),a
	ld	-20 (ix),a
	ld	-19 (ix),a
	ld	-18 (ix),a
00187$:
	push	bc
	ld	e,-11 (ix)
	ld	d,-10 (ix)
	ld	hl, #0x0035
	add	hl, sp
	ld	bc, #0x0004
	ldir
	pop	bc
;fatFs\ff_findvolume.c:121: for (i = 0; i < 4; i++) {		/* Get partition offset */
	inc	-35 (ix)
	jr	NZ,00369$
	inc	-34 (ix)
00369$:
	ld	a,-35 (ix)
	sub	a, #0x04
	ld	a,-34 (ix)
	sbc	a, #0x00
	jp	C,00182$
;fatFs\ff_findvolume.c:127: do {							/* Find an FAT volume */
	ld	-35 (ix),#0x00
	ld	-34 (ix),#0x00
00124$:
;fatFs\ff_findvolume.c:128: bsect = br[i];
	ld	l,-35 (ix)
	ld	h,-34 (ix)
	add	hl, hl
	add	hl, hl
	ld	e,-13 (ix)
	ld	d,-12 (ix)
	add	hl,de
	ld	c,(hl)
	inc	hl
	ld	b,(hl)
	inc	hl
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
;fatFs\ff_findvolume.c:129: fmt = bsect ? check_fs(fs, bsect) : 3;	/* Check the partition */
	ld	a,d
	or	a, e
	or	a, b
	or	a,c
	jr	Z,00188$
	push	bc
	push	de
	push	de
	push	bc
	ld	l,-72 (ix)
	ld	h,-71 (ix)
	push	hl
	call	_check_fs
	pop	af
	pop	af
	pop	af
	pop	de
	pop	bc
	jr	00189$
00188$:
	ld	l,#0x03
00189$:
;fatFs\ff_findvolume.c:130: } while (LD2PT(vol) == 0 && fmt >= 2 && ++i < 4);
	ld	-9 (ix), l
	ld	a, l
	sub	a, #0x02
	jr	C,00128$
	inc	-35 (ix)
	jr	NZ,00370$
	inc	-34 (ix)
00370$:
	ld	a,-35 (ix)
	sub	a, #0x04
	ld	a,-34 (ix)
	sbc	a, #0x00
	jr	C,00124$
00128$:
;fatFs\ff_findvolume.c:132: if (fmt == 4) {
	ld	a,-9 (ix)
	sub	a, #0x04
	jr	NZ,00132$
;fatFs\ff_findvolume.c:133: return FR_DISK_ERR;		/* An error occured in the disk I/O layer */
	ld	l,#0x01
	jp	00184$
00132$:
;fatFs\ff_findvolume.c:135: if (fmt >= 2) {
	ld	a,-9 (ix)
	sub	a, #0x02
	jr	C,00134$
;fatFs\ff_findvolume.c:136: return FR_NO_FILESYSTEM;	/* No FAT volume is found */
	ld	l,#0x0D
	jp	00184$
00134$:
;fatFs\ff_findvolume.c:205: if (ld_word(fs->win + BPB_BytsPerSec) != SS(fs)) {
	ld	a,-72 (ix)
	add	a, #0x2E
	ld	-21 (ix),a
	ld	a,-71 (ix)
	adc	a, #0x00
	ld	-20 (ix),a
	push	hl
	ld	l,-21 (ix)
	ld	h,-20 (ix)
	push	hl
	pop	iy
	pop	hl
	ld	l,-21 (ix)
	ld	h,-20 (ix)
	push	bc
	ld	bc, #0x000C
	add	hl, bc
	pop	bc
	ld	l,(hl)
	ld	-10 (ix),l
	ld	-11 (ix),#0x00
	ld	a, 11 (iy)
	ld	l, #0x00
	or	a, -11 (ix)
	ld	h,a
	ld	a,l
	or	a, -10 (ix)
	ld	l,a
	ld	a,h
	or	a, a
	jr	NZ,00373$
	ld	a,l
	sub	a, #0x02
	jr	Z,00136$
00373$:
;fatFs\ff_findvolume.c:206: return FR_NO_FILESYSTEM;	/* (BPB_BytsPerSec must be equal to the physical sector size) */
	ld	l,#0x0D
	jp	00184$
00136$:
;fatFs\ff_findvolume.c:209: fasize = ld_word(fs->win + BPB_FATSz16);		/* Number of sectors per FAT */
	push	hl
	ld	l,-21 (ix)
	ld	h,-20 (ix)
	push	hl
	pop	iy
	pop	hl
	ld	l,-21 (ix)
	ld	h,-20 (ix)
	push	bc
	ld	bc, #0x0017
	add	hl, bc
	pop	bc
	ld	h,(hl)
	ld	-10 (ix),h
	ld	-11 (ix),#0x00
	ld	a, 22 (iy)
	ld	l, #0x00
	or	a, -11 (ix)
	ld	h,a
	ld	a,l
	or	a, -10 (ix)
	ld	l,a
	ld	-17 (ix),h
	ld	-16 (ix),l
	ld	a,l
	rla
	sbc	a, a
	ld	-15 (ix),a
;fatFs\ff_findvolume.c:210: if (fasize == 0) fasize = ld_dword(fs->win + BPB_FATSz32);
	ld	-14 (ix), a
	or	a, -15 (ix)
	or	a, -16 (ix)
	or	a,-17 (ix)
	jr	NZ,00138$
	ld	a,-21 (ix)
	add	a, #0x24
	ld	l,a
	ld	a,-20 (ix)
	adc	a, #0x00
	ld	h,a
	push	bc
	push	de
	push	hl
	call	_ld_dword
	pop	af
	ld	-22 (ix),d
	ld	-23 (ix),e
	ld	-24 (ix),h
	ld	-25 (ix),l
	pop	de
	pop	bc
	push	de
	push	bc
	ld	hl, #59
	add	hl, sp
	ex	de, hl
	ld	hl, #51
	add	hl, sp
	ld	bc, #4
	ldir
	pop	bc
	pop	de
00138$:
;fatFs\ff_findvolume.c:211: fs->fsize = fasize;
	ld	a,-72 (ix)
	add	a, #0x16
	ld	-25 (ix),a
	ld	a,-71 (ix)
	adc	a, #0x00
	ld	-24 (ix),a
	push	de
	push	bc
	ld	e,-25 (ix)
	ld	d,-24 (ix)
	ld	hl, #0x003B
	add	hl, sp
	ld	bc, #0x0004
	ldir
	pop	bc
	pop	de
;fatFs\ff_findvolume.c:213: fs->n_fats = fs->win[BPB_NumFATs];				/* Number of FATs */
	pop	iy
	push	iy
	inc	iy
	ld	l,-21 (ix)
	ld	h,-20 (ix)
	push	bc
	ld	bc, #0x0010
	add	hl, bc
	pop	bc
	ld	a,(hl)
	ld	0 (iy), a
;fatFs\ff_findvolume.c:214: if (fs->n_fats != 1 && fs->n_fats != 2) {
	ld	h, 0 (iy)
	dec	a
	jr	Z,00140$
	ld	a,h
	sub	a, #0x02
	jr	Z,00140$
;fatFs\ff_findvolume.c:215: return FR_NO_FILESYSTEM;	/* (Must be 1 or 2) */
	ld	l,#0x0D
	jp	00184$
00140$:
;fatFs\ff_findvolume.c:217: fasize *= fs->n_fats;							/* Number of sectors for FAT area */
	ld	-4 (ix),h
	ld	-3 (ix),#0x00
	ld	-2 (ix),#0x00
	ld	-1 (ix),#0x00
	push	bc
	push	de
	ld	l,-2 (ix)
	ld	h,-1 (ix)
	push	hl
	ld	l,-4 (ix)
	ld	h,-3 (ix)
	push	hl
	ld	l,-15 (ix)
	ld	h,-14 (ix)
	push	hl
	ld	l,-17 (ix)
	ld	h,-16 (ix)
	push	hl
	call	__mullong
	pop	af
	pop	af
	pop	af
	pop	af
	ld	-1 (ix),d
	ld	-2 (ix),e
	ld	-3 (ix),h
	ld	-4 (ix),l
	pop	de
	pop	bc
	push	de
	push	bc
	ld	hl, #37
	add	hl, sp
	ex	de, hl
	ld	hl, #72
	add	hl, sp
	ld	bc, #4
	ldir
	pop	bc
	pop	de
;fatFs\ff_findvolume.c:219: fs->csize = fs->win[BPB_SecPerClus];			/* Cluster size */
	ld	a,-72 (ix)
	add	a, #0x08
	ld	-4 (ix),a
	ld	a,-71 (ix)
	adc	a, #0x00
	ld	-3 (ix),a
	ld	l,-21 (ix)
	ld	h,-20 (ix)
	push	bc
	ld	bc, #0x000D
	add	hl, bc
	pop	bc
	ld	a,(hl)
	ld	-17 (ix),a
	ld	-16 (ix),#0x00
	ld	l,-4 (ix)
	ld	h,-3 (ix)
	ld	a,-17 (ix)
	ld	(hl),a
	inc	hl
	ld	a,-16 (ix)
	ld	(hl),a
;fatFs\ff_findvolume.c:220: if (fs->csize == 0 || (fs->csize & (fs->csize - 1))) {
	ld	l,-4 (ix)
	ld	h,-3 (ix)
	ld	a, (hl)
	inc	hl
	ld	l,(hl)
	ld	h,a
	ld	a,-16 (ix)
	or	a,-17 (ix)
	jr	Z,00142$
	ld	a,h
	add	a,#0xFF
	ld	-17 (ix),a
	ld	a,l
	adc	a,#0xFF
	ld	-16 (ix),a
	ld	a,h
	and	a, -17 (ix)
	ld	h,a
	ld	a,l
	and	a, -16 (ix)
	ld	l,a
	or	a,h
	jr	Z,00143$
00142$:
;fatFs\ff_findvolume.c:221: return FR_NO_FILESYSTEM;	/* (Must be power of 2) */
	ld	l,#0x0D
	jp	00184$
00143$:
;fatFs\ff_findvolume.c:224: fs->n_rootdir = ld_word(fs->win + BPB_RootEntCnt);	/* Number of root directory entries */
	ld	a,-72 (ix)
	add	a, #0x06
	ld	-17 (ix),a
	ld	a,-71 (ix)
	adc	a, #0x00
	ld	-16 (ix),a
	push	hl
	ld	l,-21 (ix)
	ld	h,-20 (ix)
	push	hl
	pop	iy
	pop	hl
	ld	l,-21 (ix)
	ld	h,-20 (ix)
	push	bc
	ld	bc, #0x0012
	add	hl, bc
	pop	bc
	ld	l,(hl)
	ld	-10 (ix),l
	ld	-11 (ix),#0x00
	ld	h,17 (iy)
	ld	l,#0x00
	ld	a,-11 (ix)
	or	a, h
	ld	-11 (ix),a
	ld	a,-10 (ix)
	or	a, l
	ld	-10 (ix),a
	ld	l,-17 (ix)
	ld	h,-16 (ix)
	ld	a,-11 (ix)
	ld	(hl),a
	inc	hl
	ld	a,-10 (ix)
	ld	(hl),a
;fatFs\ff_findvolume.c:225: if (fs->n_rootdir % (SS(fs) / SZDIRE)) {
	ld	l,-17 (ix)
	ld	h,-16 (ix)
	ld	a, (hl)
	inc	hl
	ld	l,(hl)
	ld	h,a
	and	a, #0x0F
	jr	Z,00146$
;fatFs\ff_findvolume.c:226: return FR_NO_FILESYSTEM;	/* (Must be sector aligned) */
	ld	l,#0x0D
	jp	00184$
00146$:
;fatFs\ff_findvolume.c:229: tsect = ld_word(fs->win + BPB_TotSec16);		/* Number of sectors on the volume */
	push	hl
	ld	l,-21 (ix)
	ld	h,-20 (ix)
	push	hl
	pop	iy
	pop	hl
	ld	l,-21 (ix)
	ld	h,-20 (ix)
	push	bc
	ld	bc, #0x0014
	add	hl, bc
	pop	bc
	ld	l,(hl)
	ld	-10 (ix),l
	ld	-11 (ix),#0x00
	ld	a, 19 (iy)
	ld	l, #0x00
	or	a, -11 (ix)
	ld	h,a
	ld	a,l
	or	a, -10 (ix)
	ld	l,a
	ld	-43 (ix),h
	ld	-42 (ix),l
	ld	a,l
	rla
	sbc	a, a
	ld	-41 (ix),a
;fatFs\ff_findvolume.c:230: if (tsect == 0) tsect = ld_dword(fs->win + BPB_TotSec32);
	ld	-40 (ix), a
	or	a, -41 (ix)
	or	a, -42 (ix)
	or	a,-43 (ix)
	jr	NZ,00148$
	ld	a,-21 (ix)
	add	a, #0x20
	ld	l,a
	ld	a,-20 (ix)
	adc	a, #0x00
	ld	h,a
	push	bc
	push	de
	push	hl
	call	_ld_dword
	pop	af
	ld	-26 (ix),d
	ld	-27 (ix),e
	ld	-28 (ix),h
	ld	-29 (ix),l
	pop	de
	pop	bc
	push	de
	push	bc
	ld	hl, #33
	add	hl, sp
	ex	de, hl
	ld	hl, #47
	add	hl, sp
	ld	bc, #4
	ldir
	pop	bc
	pop	de
00148$:
;fatFs\ff_findvolume.c:232: nrsv = ld_word(fs->win + BPB_RsvdSecCnt);		/* Number of reserved sectors */
	push	hl
	ld	l,-21 (ix)
	ld	h,-20 (ix)
	push	hl
	pop	iy
	pop	hl
	ld	l,-21 (ix)
	ld	h,-20 (ix)
	push	bc
	ld	bc, #0x000F
	add	hl, bc
	pop	bc
	ld	h,(hl)
	ld	-28 (ix),h
	ld	-29 (ix),#0x00
	ld	a, 14 (iy)
	ld	l, #0x00
	or	a, -29 (ix)
	ld	h,a
	ld	a,l
	or	a, -28 (ix)
	ld	l,a
	ld	-29 (ix),h
	ld	-28 (ix),l
;fatFs\ff_findvolume.c:233: if (nrsv == 0) {
	ld	a,l
	or	a,h
	jr	NZ,00150$
;fatFs\ff_findvolume.c:234: return FR_NO_FILESYSTEM;			/* (Must not be 0) */
	ld	l,#0x0D
	jp	00184$
00150$:
;fatFs\ff_findvolume.c:238: sysect = nrsv + fasize + fs->n_rootdir / (SS(fs) / SZDIRE);	/* RSV + FAT + DIR */
	ld	a,-29 (ix)
	ld	-29 (ix),a
	ld	a,-28 (ix)
	ld	-28 (ix),a
	ld	-27 (ix),#0x00
	ld	-26 (ix),#0x00
	ld	a,-29 (ix)
	add	a, -39 (ix)
	ld	-8 (ix),a
	ld	a,-28 (ix)
	adc	a, -38 (ix)
	ld	-7 (ix),a
	ld	a,-27 (ix)
	adc	a, -37 (ix)
	ld	-6 (ix),a
	ld	a,-26 (ix)
	adc	a, -36 (ix)
	ld	-5 (ix),a
	ld	l,-17 (ix)
	ld	h,-16 (ix)
	ld	a, (hl)
	inc	hl
	ld	l,(hl)
	ld	h,a
	ld	a,#0x04
00377$:
	srl	l
	rr	h
	dec	a
	jr	NZ,00377$
	ld	-33 (ix),h
	ld	-32 (ix),l
	ld	-31 (ix),#0x00
	ld	-30 (ix),#0x00
	ld	a,-8 (ix)
	add	a, -33 (ix)
	ld	-47 (ix),a
	ld	a,-7 (ix)
	adc	a, -32 (ix)
	ld	-46 (ix),a
	ld	a,-6 (ix)
	adc	a, -31 (ix)
	ld	-45 (ix),a
	ld	a,-5 (ix)
	adc	a, -30 (ix)
	ld	-44 (ix),a
;fatFs\ff_findvolume.c:239: if (tsect < sysect) {
	ld	a,-43 (ix)
	sub	a, -47 (ix)
	ld	a,-42 (ix)
	sbc	a, -46 (ix)
	ld	a,-41 (ix)
	sbc	a, -45 (ix)
	ld	a,-40 (ix)
	sbc	a, -44 (ix)
	jr	NC,00152$
;fatFs\ff_findvolume.c:240: return FR_NO_FILESYSTEM;	/* (Invalid volume size) */
	ld	l,#0x0D
	jp	00184$
00152$:
;fatFs\ff_findvolume.c:242: nclst = (tsect - sysect) / fs->csize;			/* Number of clusters */
	ld	a,-43 (ix)
	sub	a, -47 (ix)
	ld	-33 (ix),a
	ld	a,-42 (ix)
	sbc	a, -46 (ix)
	ld	-32 (ix),a
	ld	a,-41 (ix)
	sbc	a, -45 (ix)
	ld	-31 (ix),a
	ld	a,-40 (ix)
	sbc	a, -44 (ix)
	ld	-30 (ix),a
	ld	l,-4 (ix)
	ld	h,-3 (ix)
	ld	a, (hl)
	inc	hl
	ld	l,(hl)
	ld	-8 (ix), a
	ld	-7 (ix),l
	ld	-6 (ix),#0x00
	ld	-5 (ix),#0x00
	push	bc
	push	de
	ld	l,-6 (ix)
	ld	h,-5 (ix)
	push	hl
	ld	l,-8 (ix)
	ld	h,-7 (ix)
	push	hl
	ld	l,-31 (ix)
	ld	h,-30 (ix)
	push	hl
	ld	l,-33 (ix)
	ld	h,-32 (ix)
	push	hl
	call	__divulong
	pop	af
	pop	af
	pop	af
	pop	af
	ld	-65 (ix),d
	ld	-66 (ix),e
	ld	-67 (ix),h
	ld	-68 (ix),l
	pop	de
	pop	bc
;fatFs\ff_findvolume.c:243: if (nclst == 0) {
	ld	a,-65 (ix)
	or	a, -66 (ix)
	or	a, -67 (ix)
	or	a,-68 (ix)
	jr	NZ,00154$
;fatFs\ff_findvolume.c:244: return FR_NO_FILESYSTEM;		/* (Invalid volume size) */
	ld	l,#0x0D
	jp	00184$
00154$:
;fatFs\ff_findvolume.c:246: fmt = 0;
	ld	-48 (ix),#0x00
;fatFs\ff_findvolume.c:247: if (nclst <= MAX_FAT32) {
	ld	a,#0xF5
	cp	a, -68 (ix)
	ld	a,#0xFF
	sbc	a, -67 (ix)
	ld	a,#0xFF
	sbc	a, -66 (ix)
	ld	a,#0x0F
	sbc	a, -65 (ix)
	jr	C,00156$
;fatFs\ff_findvolume.c:248: fmt = FS_FAT32;
	ld	-48 (ix),#0x03
00156$:
;fatFs\ff_findvolume.c:250: if (nclst <= MAX_FAT16) {
	ld	a,#0xF5
	cp	a, -68 (ix)
	ld	a,#0xFF
	sbc	a, -67 (ix)
	ld	a,#0x00
	sbc	a, -66 (ix)
	ld	a,#0x00
	sbc	a, -65 (ix)
	jr	C,00158$
;fatFs\ff_findvolume.c:251: fmt = FS_FAT16;
	ld	-48 (ix),#0x02
00158$:
;fatFs\ff_findvolume.c:258: if (nclst <= MAX_FAT12) {
	ld	a,#0xF5
	cp	a, -68 (ix)
	ld	a,#0x0F
	sbc	a, -67 (ix)
	ld	a,#0x00
	sbc	a, -66 (ix)
	ld	a,#0x00
	sbc	a, -65 (ix)
	jr	C,00160$
;fatFs\ff_findvolume.c:259: fmt = 0;
	ld	-48 (ix),#0x00
00160$:
;fatFs\ff_findvolume.c:262: if (fmt == 0) {
	ld	a,-48 (ix)
	or	a, a
	jr	NZ,00162$
;fatFs\ff_findvolume.c:263: return FR_NO_FILESYSTEM;
	ld	l,#0x0D
	jp	00184$
00162$:
;fatFs\ff_findvolume.c:267: fs->n_fatent = nclst + 2;						/* Number of FAT entries */
	ld	a,-72 (ix)
	add	a, #0x12
	ld	-33 (ix),a
	ld	a,-71 (ix)
	adc	a, #0x00
	ld	-32 (ix),a
	ld	a,-68 (ix)
	add	a, #0x02
	ld	-8 (ix),a
	ld	a,-67 (ix)
	adc	a, #0x00
	ld	-7 (ix),a
	ld	a,-66 (ix)
	adc	a, #0x00
	ld	-6 (ix),a
	ld	a,-65 (ix)
	adc	a, #0x00
	ld	-5 (ix),a
	push	de
	push	bc
	ld	e,-33 (ix)
	ld	d,-32 (ix)
	ld	hl, #0x0044
	add	hl, sp
	ld	bc, #0x0004
	ldir
	pop	bc
	pop	de
;fatFs\ff_findvolume.c:268: fs->volbase = bsect;							/* Volume start sector */
	ld	a,-72 (ix)
	add	a, #0x1A
	ld	l,a
	ld	a,-71 (ix)
	adc	a, #0x00
	ld	h,a
	ld	(hl),c
	inc	hl
	ld	(hl),b
	inc	hl
	ld	(hl),e
	inc	hl
	ld	(hl),d
;fatFs\ff_findvolume.c:269: fs->fatbase = bsect + nrsv; 					/* FAT start sector */
	ld	iy,#0x001E
	push	bc
	ld	c,-72 (ix)
	ld	b,-71 (ix)
	add	iy, bc
	pop	bc
	ld	a,c
	add	a, -29 (ix)
	ld	-8 (ix),a
	ld	a,b
	adc	a, -28 (ix)
	ld	-7 (ix),a
	ld	a,e
	adc	a, -27 (ix)
	ld	-6 (ix),a
	ld	a,d
	adc	a, -26 (ix)
	ld	-5 (ix),a
	push	de
	push	bc
	push	iy
	pop	de
	ld	hl, #0x0044
	add	hl, sp
	ld	bc, #0x0004
	ldir
	pop	bc
	pop	de
;fatFs\ff_findvolume.c:270: fs->database = bsect + sysect;					/* Data start sector */
	ld	a,-72 (ix)
	add	a, #0x26
	ld	-8 (ix),a
	ld	a,-71 (ix)
	adc	a, #0x00
	ld	-7 (ix),a
	ld	a,c
	add	a, -47 (ix)
	ld	-29 (ix),a
	ld	a,b
	adc	a, -46 (ix)
	ld	-28 (ix),a
	ld	a,e
	adc	a, -45 (ix)
	ld	-27 (ix),a
	ld	a,d
	adc	a, -44 (ix)
	ld	-26 (ix),a
	push	de
	push	bc
	ld	e,-8 (ix)
	ld	d,-7 (ix)
	ld	hl, #0x002F
	add	hl, sp
	ld	bc, #0x0004
	ldir
	pop	bc
	pop	de
;fatFs\ff_findvolume.c:271: if (fmt == FS_FAT32) {
	ld	a,-48 (ix)
	sub	a, #0x03
	jr	NZ,00378$
	ld	a,#0x01
	jr	00379$
00378$:
	xor	a,a
00379$:
	ld	-8 (ix),a
;fatFs\ff_findvolume.c:225: if (fs->n_rootdir % (SS(fs) / SZDIRE)) {
	ld	l,-17 (ix)
	ld	h,-16 (ix)
	ld	a,(hl)
	ld	-29 (ix),a
	inc	hl
	ld	a,(hl)
	ld	-28 (ix),a
;fatFs\ff_findvolume.c:278: fs->dirbase = ld_dword(fs->win + BPB_RootClus32);	/* Root directory start cluster */
	ld	a,-72 (ix)
	add	a, #0x22
	ld	-4 (ix),a
	ld	a,-71 (ix)
	adc	a, #0x00
	ld	-3 (ix),a
;fatFs\ff_findvolume.c:271: if (fmt == FS_FAT32) {
	ld	a,-8 (ix)
	or	a, a
	jp	Z,00170$
;fatFs\ff_findvolume.c:272: if (ld_word(fs->win + BPB_FSVer32) != 0) {
	push	hl
	ld	l,-21 (ix)
	ld	h,-20 (ix)
	push	hl
	pop	iy
	pop	hl
	ld	l,-21 (ix)
	ld	h,-20 (ix)
	push	bc
	ld	bc, #0x002B
	add	hl, bc
	pop	bc
	ld	h,(hl)
	ld	-16 (ix),h
	ld	-17 (ix),#0x00
	ld	a, 42 (iy)
	ld	l, #0x00
	or	a, -17 (ix)
	ld	h,a
	ld	a,l
	or	a, -16 (ix)
	or	a,h
	jr	Z,00164$
;fatFs\ff_findvolume.c:273: return FR_NO_FILESYSTEM;	/* (Must be FAT32 revision 0.0) */
	ld	l,#0x0D
	jp	00184$
00164$:
;fatFs\ff_findvolume.c:275: if (fs->n_rootdir != 0) {
	ld	a,-28 (ix)
	or	a,-29 (ix)
	jr	Z,00166$
;fatFs\ff_findvolume.c:276: return FR_NO_FILESYSTEM;	/* (BPB_RootEntCnt must be 0) */
	ld	l,#0x0D
	jp	00184$
00166$:
;fatFs\ff_findvolume.c:278: fs->dirbase = ld_dword(fs->win + BPB_RootClus32);	/* Root directory start cluster */
	ld	a,-21 (ix)
	add	a, #0x2C
	ld	l,a
	ld	a,-20 (ix)
	adc	a, #0x00
	ld	h,a
	push	bc
	push	de
	push	hl
	call	_ld_dword
	pop	af
	ld	-14 (ix),d
	ld	-15 (ix),e
	ld	-16 (ix),h
	ld	-17 (ix),l
	pop	de
	pop	bc
	push	de
	push	bc
	ld	e,-4 (ix)
	ld	d,-3 (ix)
	ld	hl, #0x003B
	add	hl, sp
	ld	bc, #0x0004
	ldir
	pop	bc
	push	bc
	ld	e,-33 (ix)
	ld	d,-32 (ix)
	ld	hl, #0x003B
	add	hl, sp
	ex	de, hl
	ld	bc, #0x0004
	ldir
	pop	bc
	pop	de
	push	af
	pop	af
	ld	a,#0x02
00380$:
	sla	-17 (ix)
	rl	-16 (ix)
	rl	-15 (ix)
	rl	-14 (ix)
	dec	a
	jr	NZ,00380$
	jp	00171$
00170$:
;fatFs\ff_findvolume.c:281: if (fs->n_rootdir == 0)	{
	ld	a,-28 (ix)
	or	a,-29 (ix)
	jr	NZ,00168$
;fatFs\ff_findvolume.c:282: return FR_NO_FILESYSTEM;	/* (BPB_RootEntCnt must not be 0) */
	ld	l,#0x0D
	jp	00184$
00168$:
;fatFs\ff_findvolume.c:284: fs->dirbase = fs->fatbase + fasize;			/* Root directory start sector */
	ld	a,0 (iy)
	ld	-29 (ix),a
	ld	a,1 (iy)
	ld	-28 (ix),a
	ld	a,2 (iy)
	ld	-27 (ix),a
	ld	a,3 (iy)
	ld	-26 (ix),a
	ld	a,-29 (ix)
	add	a, -39 (ix)
	ld	-29 (ix),a
	ld	a,-28 (ix)
	adc	a, -38 (ix)
	ld	-28 (ix),a
	ld	a,-27 (ix)
	adc	a, -37 (ix)
	ld	-27 (ix),a
	ld	a,-26 (ix)
	adc	a, -36 (ix)
	ld	-26 (ix),a
	push	de
	push	bc
	ld	e,-4 (ix)
	ld	d,-3 (ix)
	ld	hl, #0x002F
	add	hl, sp
	ld	bc, #0x0004
	ldir
	pop	bc
	push	bc
	ld	e,-33 (ix)
	ld	d,-32 (ix)
	ld	hl, #0x002B
	add	hl, sp
	ex	de, hl
	ld	bc, #0x0004
	ldir
	pop	bc
	pop	de
	push	af
	ld	a,-33 (ix)
	ld	-17 (ix),a
	ld	a,-32 (ix)
	ld	-16 (ix),a
	ld	a,-31 (ix)
	ld	-15 (ix),a
	ld	a,-30 (ix)
	ld	-14 (ix),a
	pop	af
	ld	a,#0x01
	sla	-17 (ix)
	rl	-16 (ix)
	rl	-15 (ix)
	rl	-14 (ix)
00171$:
;fatFs\ff_findvolume.c:294: if (fs->fsize < (szbfat + (SS(fs) - 1)) / SS(fs)) {
	push	de
	push	bc
	ld	e,-25 (ix)
	ld	d,-24 (ix)
	ld	hl, #0x002B
	add	hl, sp
	ex	de, hl
	ld	bc, #0x0004
	ldir
	pop	bc
	pop	de
	ld	a,-17 (ix)
	add	a, #0xFF
	ld	-29 (ix),a
	ld	a,-16 (ix)
	adc	a, #0x01
	ld	-28 (ix),a
	ld	a,-15 (ix)
	adc	a, #0x00
	ld	-27 (ix),a
	ld	a,-14 (ix)
	adc	a, #0x00
	ld	-26 (ix),a
	push	af
	pop	af
	ld	a,#0x09
00384$:
	srl	-26 (ix)
	rr	-27 (ix)
	rr	-28 (ix)
	rr	-29 (ix)
	dec	a
	jr	NZ,00384$
	ld	a,-33 (ix)
	sub	a, -29 (ix)
	ld	a,-32 (ix)
	sbc	a, -28 (ix)
	ld	a,-31 (ix)
	sbc	a, -27 (ix)
	ld	a,-30 (ix)
	sbc	a, -26 (ix)
	jr	NC,00173$
;fatFs\ff_findvolume.c:295: return FR_NO_FILESYSTEM;	/* (BPB_FATSz must not be less than the size needed) */
	ld	l,#0x0D
	jp	00184$
00173$:
;fatFs\ff_findvolume.c:300: fs->last_clst = fs->free_clst = 0xFFFFFFFF;		/* Initialize cluster allocation information */
	ld	a,-72 (ix)
	add	a, #0x0A
	ld	-33 (ix),a
	ld	a,-71 (ix)
	adc	a, #0x00
	ld	-32 (ix),a
	ld	a,-72 (ix)
	add	a, #0x0E
	ld	-29 (ix),a
	ld	a,-71 (ix)
	adc	a, #0x00
	ld	-28 (ix),a
	ld	l,-29 (ix)
	ld	h,-28 (ix)
	ld	(hl),#0xFF
	inc	hl
	ld	(hl),#0xFF
	inc	hl
	ld	(hl),#0xFF
	inc	hl
	ld	(hl),#0xFF
	ld	l,-33 (ix)
	ld	h,-32 (ix)
	ld	(hl),#0xFF
	inc	hl
	ld	(hl),#0xFF
	inc	hl
	ld	(hl),#0xFF
	inc	hl
	ld	(hl),#0xFF
;fatFs\ff_findvolume.c:301: fs->fsi_flag = 0x80;
	ld	a,-72 (ix)
	add	a, #0x03
	ld	-4 (ix),a
	ld	a,-71 (ix)
	adc	a, #0x00
	ld	-3 (ix),a
	ld	l,-4 (ix)
	ld	h,-3 (ix)
	ld	(hl),#0x80
;fatFs\ff_findvolume.c:304: && ld_word(fs->win + BPB_FSInfo32) == 1
	ld	a,-8 (ix)
	or	a, a
	jp	Z,00179$
	push	hl
	ld	l,-21 (ix)
	ld	h,-20 (ix)
	push	hl
	pop	iy
	pop	hl
	ld	l,-21 (ix)
	ld	h,-20 (ix)
	push	bc
	ld	bc, #0x0031
	add	hl, bc
	pop	bc
	ld	l,(hl)
	ld	-7 (ix),l
	ld	-8 (ix),#0x00
	ld	a, 48 (iy)
	ld	h, #0x00
	or	a, -8 (ix)
	ld	l,a
	ld	a,h
	or	a, -7 (ix)
	ld	h,a
	dec	l
	jp	NZ,00179$
	ld	a,h
	or	a, a
	jp	NZ,00179$
;fatFs\ff_findvolume.c:305: && move_window(fs, bsect + 1) == FR_OK)
	inc	c
	jr	NZ,00388$
	inc	b
	jr	NZ,00388$
	inc	e
	jr	NZ,00388$
	inc	d
00388$:
	push	de
	push	bc
	ld	l,-72 (ix)
	ld	h,-71 (ix)
	push	hl
	call	_move_window
	pop	af
	pop	af
	pop	af
	ld	a,l
	or	a, a
	jp	NZ,00179$
;fatFs\ff_findvolume.c:307: fs->fsi_flag = 0;
	ld	l,-4 (ix)
	ld	h,-3 (ix)
	ld	(hl),#0x00
;fatFs\ff_findvolume.c:308: if (ld_word(fs->win + BS_55AA) == 0xAA55	/* Load FSInfo data if available */
	ld	c,-21 (ix)
	ld	b,-20 (ix)
	ld	l,-21 (ix)
	ld	h,-20 (ix)
	ld	de, #0x01FF
	add	hl, de
	ld	d, (hl)
	ld	e,#0x00
	ld	l, c
	ld	h, b
	ld	bc, #0x01FE
	add	hl, bc
	ld	l,(hl)
	ld	h,#0x00
	ld	a,l
	or	a, e
	ld	l,a
	ld	a,h
	or	a, d
	ld	h,a
	ld	a,l
	sub	a, #0x55
	jp	NZ,00179$
	ld	a,h
	sub	a, #0xAA
	jp	NZ,00179$
;fatFs\ff_findvolume.c:309: && ld_dword(fs->win + FSI_LeadSig) == 0x41615252
	ld	l,-21 (ix)
	ld	h,-20 (ix)
	push	hl
	call	_ld_dword
	pop	af
	ld	a,l
	sub	a, #0x52
	jr	NZ,00179$
	ld	a,h
	sub	a, #0x52
	jr	NZ,00179$
	ld	a,e
	sub	a, #0x61
	jr	NZ,00179$
	ld	a,d
	sub	a, #0x41
	jr	NZ,00179$
;fatFs\ff_findvolume.c:310: && ld_dword(fs->win + FSI_StrucSig) == 0x61417272)
	ld	a,-21 (ix)
	add	a, #0xE4
	ld	l,a
	ld	a,-20 (ix)
	adc	a, #0x01
	ld	h,a
	push	hl
	call	_ld_dword
	pop	af
	ld	a,l
	sub	a, #0x72
	jr	NZ,00179$
	ld	a,h
	sub	a, #0x72
	jr	NZ,00179$
	ld	a,e
	sub	a, #0x41
	jr	NZ,00179$
	ld	a,d
	sub	a, #0x61
	jr	NZ,00179$
;fatFs\ff_findvolume.c:313: fs->free_clst = ld_dword(fs->win + FSI_Free_Count);
	ld	a,-21 (ix)
	add	a, #0xE8
	ld	l,a
	ld	a,-20 (ix)
	adc	a, #0x01
	ld	h,a
	push	hl
	call	_ld_dword
	pop	af
	ld	c,l
	ld	b,h
	ld	l,-29 (ix)
	ld	h,-28 (ix)
	ld	(hl),c
	inc	hl
	ld	(hl),b
	inc	hl
	ld	(hl),e
	inc	hl
	ld	(hl),d
;fatFs\ff_findvolume.c:316: fs->last_clst = ld_dword(fs->win + FSI_Nxt_Free);
	ld	a,-21 (ix)
	add	a, #0xEC
	ld	l,a
	ld	a,-20 (ix)
	adc	a, #0x01
	ld	h,a
	push	hl
	call	_ld_dword
	pop	af
	ld	c,l
	ld	b,h
	ld	l,-33 (ix)
	ld	h,-32 (ix)
	ld	(hl),c
	inc	hl
	ld	(hl),b
	inc	hl
	ld	(hl),e
	inc	hl
	ld	(hl),d
00179$:
;fatFs\ff_findvolume.c:324: fs->fs_type = fmt;		/* FAT sub-type */
	pop	hl
	push	hl
	ld	a,-48 (ix)
	ld	(hl),a
;fatFs\ff_findvolume.c:325: fs->id = ++Fsid;		/* Volume mount ID */
	ld	a,-72 (ix)
	add	a, #0x04
	ld	e,a
	ld	a,-71 (ix)
	adc	a, #0x00
	ld	d,a
	ld	hl, #_Fsid+0
	inc	(hl)
	jr	NZ,00395$
	ld	hl, #_Fsid+1
	inc	(hl)
00395$:
	ld	a,(#_Fsid + 0)
	ld	(de),a
	inc	de
	ld	a,(#_Fsid + 1)
	ld	(de),a
;fatFs\ff_findvolume.c:339: return FR_OK;
	ld	l,#0x00
00184$:
	ld	sp, ix
	pop	ix
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
