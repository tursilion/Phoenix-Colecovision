;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 3.5.0 #9253 (Jun 20 2015) (MINGW64)
; This file was generated Thu Sep 12 23:58:01 2019
;--------------------------------------------------------
	.module ff_syncwindow
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _disk_write
	.globl _sync_window
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\ff_syncwindow.c:42: FRESULT sync_window (	/* Returns FR_OK or FR_DISK_ERR */
;	---------------------------------
; Function sync_window
; ---------------------------------
_sync_window::
	call	___sdcc_enter_ix
	ld	hl,#-13
	add	hl,sp
	ld	sp,hl
;fatFs\ff_syncwindow.c:46: FRESULT res = FR_OK;
	ld	-13 (ix),#0x00
;fatFs\ff_syncwindow.c:49: if (fs->wflag) {	/* Is the disk access window dirty */
	ld	a,4 (ix)
	ld	-8 (ix),a
	ld	a,5 (ix)
	ld	-7 (ix),a
	ld	c,-8 (ix)
	ld	b,-7 (ix)
	inc	bc
	inc	bc
	ld	a,(bc)
	or	a, a
	jp	Z,00109$
;fatFs\ff_syncwindow.c:51: if (disk_write(fs->win, fs->winsect, 1) == RES_OK) {	/* Write back the window */
	ld	a,-8 (ix)
	add	a, #0x2A
	ld	e,a
	ld	a,-7 (ix)
	adc	a, #0x00
	ld	d,a
	push	de
	push	bc
	ld	hl, #0x0005
	add	hl, sp
	ex	de, hl
	ld	bc, #0x0004
	ldir
	pop	bc
	pop	de
	ld	a,-8 (ix)
	add	a, #0x2E
	ld	-2 (ix),a
	ld	a,-7 (ix)
	adc	a, #0x00
	ld	-1 (ix),a
	push	bc
	push	de
	ld	hl,#0x0001
	push	hl
	ld	l,-10 (ix)
	ld	h,-9 (ix)
	push	hl
	ld	l,-12 (ix)
	ld	h,-11 (ix)
	push	hl
	ld	l,-2 (ix)
	ld	h,-1 (ix)
	push	hl
	call	_disk_write
	pop	af
	pop	af
	pop	af
	pop	af
	ld	a,l
	pop	de
	pop	bc
	or	a, a
	jp	NZ,00106$
;fatFs\ff_syncwindow.c:55: fs->wflag = 0;	/* Clear window dirty flag */
	xor	a, a
	ld	(bc),a
;fatFs\ff_syncwindow.c:56: if (fs->winsect - fs->fatbase < fs->fsize) {	/* Is it in the 1st FAT? */
	ld	hl, #0x0001
	add	hl, sp
	ex	de, hl
	ld	bc, #0x0004
	ldir
	ld	l,-8 (ix)
	ld	h,-7 (ix)
	ld	de, #0x001E
	add	hl, de
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	inc	hl
	ld	c,(hl)
	inc	hl
	ld	b,(hl)
	ld	a,-12 (ix)
	sub	a, e
	ld	-6 (ix),a
	ld	a,-11 (ix)
	sbc	a, d
	ld	-5 (ix),a
	ld	a,-10 (ix)
	sbc	a, c
	ld	-4 (ix),a
	ld	a,-9 (ix)
	sbc	a, b
	ld	-3 (ix),a
	ld	l,-8 (ix)
	ld	h,-7 (ix)
	ld	de, #0x0016
	add	hl, de
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	inc	hl
	ld	c,(hl)
	inc	hl
	ld	b,(hl)
	ld	a,-6 (ix)
	sub	a, e
	ld	a,-5 (ix)
	sbc	a, d
	ld	a,-4 (ix)
	sbc	a, c
	ld	a,-3 (ix)
	sbc	a, b
	jr	NC,00109$
;fatFs\ff_syncwindow.c:58: if (fs->n_fats == 2) disk_write(fs->win, fs->winsect + fs->fsize, 1);	/* Reflect it to
	ld	l,-8 (ix)
	ld	h,-7 (ix)
	inc	hl
	ld	a,(hl)
	sub	a, #0x02
	jr	NZ,00109$
	ld	a,-12 (ix)
	add	a, e
	ld	e,a
	ld	a,-11 (ix)
	adc	a, d
	ld	d,a
	ld	a,-10 (ix)
	adc	a, c
	ld	l,a
	ld	a,-9 (ix)
	adc	a, b
	ld	h,a
	ld	bc,#0x0001
	push	bc
	push	hl
	push	de
	ld	l,-2 (ix)
	ld	h,-1 (ix)
	push	hl
	call	_disk_write
	pop	af
	pop	af
	pop	af
	pop	af
	jr	00109$
00106$:
;fatFs\ff_syncwindow.c:66: res = FR_DISK_ERR;
	ld	-13 (ix),#0x01
00109$:
;fatFs\ff_syncwindow.c:69: return res;
	ld	l,-13 (ix)
	ld	sp, ix
	pop	ix
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
