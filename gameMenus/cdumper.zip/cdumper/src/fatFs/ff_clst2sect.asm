;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 3.5.0 #9253 (Jun 20 2015) (MINGW64)
; This file was generated Thu Sep 12 23:57:25 2019
;--------------------------------------------------------
	.module ff_clst2sect
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _clst2sect
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\ff_clst2sect.c:42: DWORD clst2sect (	/* !=0:Sector number, 0:Failed (invalid cluster#) */
;	---------------------------------
; Function clst2sect
; ---------------------------------
_clst2sect::
	call	___sdcc_enter_ix
	push	af
	push	af
;fatFs\ff_clst2sect.c:47: clst -= 2;		/* Cluster number is origin from 2 */
	ld	a,6 (ix)
	add	a,#0xFE
	ld	6 (ix),a
	ld	a,7 (ix)
	adc	a,#0xFF
	ld	7 (ix),a
	ld	a,8 (ix)
	adc	a,#0xFF
	ld	8 (ix),a
	ld	a,9 (ix)
	adc	a,#0xFF
	ld	9 (ix),a
;fatFs\ff_clst2sect.c:48: if (clst >= fs->n_fatent - 2) return 0;		/* Is it invalid cluster number? */
	ld	c,4 (ix)
	ld	b,5 (ix)
	push	bc
	pop	iy
	ld	l,18 (iy)
	ld	h,19 (iy)
	ld	e,20 (iy)
	ld	d,21 (iy)
	ld	a,l
	add	a,#0xFE
	ld	l,a
	ld	a,h
	adc	a,#0xFF
	ld	h,a
	ld	a,e
	adc	a,#0xFF
	ld	e,a
	ld	a,d
	adc	a,#0xFF
	ld	d,a
	ld	a,6 (ix)
	sub	a, l
	ld	a,7 (ix)
	sbc	a, h
	ld	a,8 (ix)
	sbc	a, e
	ld	a,9 (ix)
	sbc	a, d
	jr	C,00102$
	ld	hl,#0x0000
	ld	e,l
	ld	d,h
	jr	00103$
00102$:
;fatFs\ff_clst2sect.c:49: return fs->database + fs->csize * clst;		/* Start sector number of the cluster */
	push	bc
	pop	iy
	ld	a,38 (iy)
	ld	-4 (ix),a
	ld	a,39 (iy)
	ld	-3 (ix),a
	ld	a,40 (iy)
	ld	-2 (ix),a
	ld	a,41 (iy)
	ld	-1 (ix),a
	push	bc
	pop	iy
	ld	e,8 (iy)
	ld	d,9 (iy)
	ld	bc,#0x0000
	ld	l,8 (ix)
	ld	h,9 (ix)
	push	hl
	ld	l,6 (ix)
	ld	h,7 (ix)
	push	hl
	push	bc
	push	de
	call	__mullong
	pop	af
	pop	af
	pop	af
	pop	af
	ld	a,-4 (ix)
	add	a, l
	ld	l,a
	ld	a,-3 (ix)
	adc	a, h
	ld	h,a
	ld	a,-2 (ix)
	adc	a, e
	ld	e,a
	ld	a,-1 (ix)
	adc	a, d
	ld	d,a
00103$:
	ld	sp, ix
	pop	ix
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
