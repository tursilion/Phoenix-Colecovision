;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 3.5.0 #9253 (Jun 20 2015) (MINGW64)
; This file was generated Thu Sep 12 23:57:43 2019
;--------------------------------------------------------
	.module ff_fsync
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _disk_write
	.globl _st_dword
	.globl _st_word
	.globl _st_clust
	.globl _sync_fs
	.globl _validate
	.globl _move_window
	.globl _f_sync
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\ff_fsync.c:43: FRESULT f_sync (
;	---------------------------------
; Function f_sync
; ---------------------------------
_f_sync::
	call	___sdcc_enter_ix
	ld	hl,#-10
	add	hl,sp
	ld	sp,hl
;fatFs\ff_fsync.c:53: res = validate(&fp->obj, &fs);	/* Check validity of the file object */
	ld	hl,#0x0000
	add	hl,sp
	ld	e,4 (ix)
	ld	d,5 (ix)
	push	de
	push	hl
	push	de
	call	_validate
	pop	af
	pop	af
	pop	de
	ld	b,l
;fatFs\ff_fsync.c:54: if (res == FR_OK) {
	ld	a,b
	or	a, a
	jp	NZ,00110$
;fatFs\ff_fsync.c:55: if (fp->flag & FA_MODIFIED) {	/* Is there any change to the file? */
	ld	hl,#0x000E
	add	hl,de
	ld	-8 (ix),l
	ld	-7 (ix),h
	ld	l,-8 (ix)
	ld	h,-7 (ix)
	ld	a,(hl)
	bit	6, a
	jp	Z,00110$
;fatFs\ff_fsync.c:57: if (fp->flag & FA_DIRTY) {	/* Write-back cached data if needed */
	rlca
	jr	NC,00104$
;fatFs\ff_fsync.c:61: if (disk_write(fp->buf, fp->sect, 1) != RES_OK) LEAVE_FF(fs, FR_DISK_ERR);
	ld	l, e
	ld	h, d
	ld	bc, #0x0018
	add	hl, bc
	ld	a,(hl)
	ld	-4 (ix),a
	inc	hl
	ld	a,(hl)
	ld	-3 (ix),a
	inc	hl
	ld	a,(hl)
	ld	-2 (ix),a
	inc	hl
	ld	a,(hl)
	ld	-1 (ix),a
	ld	hl,#0x0022
	add	hl,de
	ld	c,l
	ld	b,h
	push	de
	ld	hl,#0x0001
	push	hl
	ld	l,-2 (ix)
	ld	h,-1 (ix)
	push	hl
	ld	l,-4 (ix)
	ld	h,-3 (ix)
	push	hl
	push	bc
	call	_disk_write
	pop	af
	pop	af
	pop	af
	pop	af
	ld	a,l
	pop	de
	or	a, a
	jr	Z,00102$
	ld	l,#0x01
	jp	00111$
00102$:
;fatFs\ff_fsync.c:63: fp->flag &= (BYTE)~FA_DIRTY;
	ld	l,-8 (ix)
	ld	h,-7 (ix)
	ld	a,(hl)
	and	a, #0x7F
	ld	l,-8 (ix)
	ld	h,-7 (ix)
	ld	(hl),a
00104$:
;fatFs\ff_fsync.c:100: res = move_window(fs, fp->dir_sect);
	push	de
	pop	iy
	ld	c,28 (iy)
	ld	b,29 (iy)
	ld	l,30 (iy)
	ld	h,31 (iy)
	push	de
	push	hl
	push	bc
	ld	l,-10 (ix)
	ld	h,-9 (ix)
	push	hl
	call	_move_window
	pop	af
	pop	af
	pop	af
	pop	de
	ld	b,l
;fatFs\ff_fsync.c:101: if (res == FR_OK) {
	ld	a,b
	or	a, a
	jp	NZ,00110$
;fatFs\ff_fsync.c:102: dir = fp->dir_ptr;
	push	de
	pop	iy
	ld	c,32 (iy)
	ld	b,33 (iy)
;fatFs\ff_fsync.c:103: dir[DIR_Attr] |= AM_ARC;						/* Set archive attribute to indicate that the file has been changed */
	ld	hl,#0x000B
	add	hl,bc
	set	5, (hl)
	ld	a, (hl)
;fatFs\ff_fsync.c:104: st_clust(fp->obj.fs, dir, fp->obj.sclust);		/* Update file allocation information  */
	push	de
	pop	iy
	ld	a,6 (iy)
	ld	-4 (ix),a
	ld	a,7 (iy)
	ld	-3 (ix),a
	ld	a,8 (iy)
	ld	-2 (ix),a
	ld	a,9 (iy)
	ld	-1 (ix),a
	ld	a,(de)
	ld	-6 (ix),a
	inc	de
	ld	a,(de)
	ld	-5 (ix),a
	dec	de
	push	bc
	push	de
	ld	l,-2 (ix)
	ld	h,-1 (ix)
	push	hl
	ld	l,-4 (ix)
	ld	h,-3 (ix)
	push	hl
	push	bc
	ld	l,-6 (ix)
	ld	h,-5 (ix)
	push	hl
	call	_st_clust
	pop	af
	pop	af
	pop	af
	pop	af
	pop	de
	pop	bc
;fatFs\ff_fsync.c:105: st_dword(dir + DIR_FileSize, (DWORD)fp->obj.objsize);	/* Update file size */
	push	de
	pop	iy
	ld	e,10 (iy)
	ld	d,11 (iy)
	ld	l,12 (iy)
	ld	h,13 (iy)
	ld	iy,#0x001C
	add	iy, bc
	push	bc
	push	hl
	push	de
	push	iy
	call	_st_dword
	pop	af
	pop	af
	pop	af
	pop	bc
;fatFs\ff_fsync.c:106: st_dword(dir + DIR_ModTime, tm);				/* Update modified time */
	ld	hl,#0x0016
	add	hl,bc
	ex	de,hl
	push	bc
	ld	hl,#0x4E21
	push	hl
	ld	hl,#0x0000
	push	hl
	push	de
	call	_st_dword
	pop	af
	pop	af
	pop	af
	pop	bc
;fatFs\ff_fsync.c:107: st_word(dir + DIR_LstAccDate, 0);
	ld	hl,#0x0012
	add	hl,bc
	ld	bc,#0x0000
	push	bc
	push	hl
	call	_st_word
	pop	af
	pop	af
;fatFs\ff_fsync.c:108: fs->wflag = 1;
	pop	hl
	push	hl
	inc	hl
	inc	hl
	ld	(hl),#0x01
;fatFs\ff_fsync.c:109: res = sync_fs(fs);					/* Restore it to the directory */
	pop	hl
	push	hl
	push	hl
	call	_sync_fs
	pop	af
	ld	b,l
;fatFs\ff_fsync.c:110: fp->flag &= (BYTE)~FA_MODIFIED;
	ld	l,-8 (ix)
	ld	h,-7 (ix)
	ld	a,(hl)
	and	a, #0xBF
	ld	l,-8 (ix)
	ld	h,-7 (ix)
	ld	(hl),a
00110$:
;fatFs\ff_fsync.c:116: LEAVE_FF(fs, res);
	ld	l,b
00111$:
	ld	sp, ix
	pop	ix
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
