;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 3.5.0 #9253 (Jun 20 2015) (MINGW64)
; This file was generated Thu Sep 12 23:57:35 2019
;--------------------------------------------------------
	.module ff_fgetfree
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _find_volume
	.globl _get_fat
	.globl _move_window
	.globl _ld_dword
	.globl _f_getfree
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\ff_fgetfree.c:43: FRESULT f_getfree (
;	---------------------------------
; Function f_getfree
; ---------------------------------
_f_getfree::
	call	___sdcc_enter_ix
	ld	hl,#-47
	add	hl,sp
	ld	sp,hl
;fatFs\ff_fgetfree.c:60: res = find_volume(&fs, 0);
	ld	hl,#0x0019
	add	hl,sp
	ex	de,hl
	xor	a, a
	push	af
	inc	sp
	push	de
	call	_find_volume
	pop	af
	inc	sp
;fatFs\ff_fgetfree.c:62: if (res == FR_OK) {
	ld	-47 (ix), l
	ld	a, l
	or	a, a
	jp	NZ,00131$
;fatFs\ff_fgetfree.c:63: *fatfs = fs;				/* Return ptr to the fs object */
	ld	l,8 (ix)
	ld	h,9 (ix)
	ld	a,-22 (ix)
	ld	(hl),a
	inc	hl
	ld	a,-21 (ix)
	ld	(hl),a
;fatFs\ff_fgetfree.c:65: if (fs->free_clst <= fs->n_fatent - 2) {
	ld	c,-22 (ix)
	ld	b,-21 (ix)
	push	bc
	pop	iy
	ld	a,14 (iy)
	ld	-10 (ix),a
	ld	a,15 (iy)
	ld	-9 (ix),a
	ld	a,16 (iy)
	ld	-8 (ix),a
	ld	a,17 (iy)
	ld	-7 (ix),a
	push	bc
	pop	iy
	ld	a,18 (iy)
	ld	-14 (ix),a
	ld	a,19 (iy)
	ld	-13 (ix),a
	ld	a,20 (iy)
	ld	-12 (ix),a
	ld	a,21 (iy)
	ld	-11 (ix),a
	ld	a,-14 (ix)
	add	a,#0xFE
	ld	h,a
	ld	a,-13 (ix)
	adc	a,#0xFF
	ld	l,a
	ld	a,-12 (ix)
	adc	a,#0xFF
	ld	d,a
	ld	a,-11 (ix)
	adc	a,#0xFF
	ld	e,a
;fatFs\ff_fgetfree.c:66: *nclst = fs->free_clst;
	ld	a,6 (ix)
	ld	-20 (ix),a
	ld	a,7 (ix)
	ld	-19 (ix),a
;fatFs\ff_fgetfree.c:65: if (fs->free_clst <= fs->n_fatent - 2) {
	ld	a,h
	sub	a, -10 (ix)
	ld	a,l
	sbc	a, -9 (ix)
	ld	a,d
	sbc	a, -8 (ix)
	ld	a,e
	sbc	a, -7 (ix)
	jr	C,00128$
;fatFs\ff_fgetfree.c:66: *nclst = fs->free_clst;
	ld	e,-20 (ix)
	ld	d,-19 (ix)
	ld	hl, #0x0025
	add	hl, sp
	ld	bc, #0x0004
	ldir
	jp	00131$
00128$:
;fatFs\ff_fgetfree.c:69: nfree = 0;
	xor	a, a
	ld	-26 (ix),a
	ld	-25 (ix),a
	ld	-24 (ix),a
	ld	-23 (ix),a
;fatFs\ff_fgetfree.c:70: if (fs->fs_type == FS_FAT12) {	/* FAT12: Scan bit field FAT entries */
	ld	a,(bc)
	dec	a
	jp	NZ,00125$
;fatFs\ff_fgetfree.c:71: clst = 2; obj.fs = fs;
	ld	hl,#0x0001
	add	hl,sp
	ld	(hl),c
	inc	hl
	ld	(hl),b
;fatFs\ff_fgetfree.c:72: do {
	ld	hl,#0x0001
	add	hl,sp
	ld	-10 (ix),l
	ld	-9 (ix),h
	xor	a, a
	ld	-4 (ix),a
	ld	-3 (ix),a
	ld	-2 (ix),a
	ld	-1 (ix),a
	ld	-30 (ix),#0x02
	xor	a, a
	ld	-29 (ix),a
	ld	-28 (ix),a
	ld	-27 (ix),a
00107$:
;fatFs\ff_fgetfree.c:73: stat = get_fat(&obj, clst);
	ld	e,-10 (ix)
	ld	d,-9 (ix)
	ld	l,-28 (ix)
	ld	h,-27 (ix)
	push	hl
	ld	l,-30 (ix)
	ld	h,-29 (ix)
	push	hl
	push	de
	call	_get_fat
	pop	af
	pop	af
	pop	af
	ld	c,l
	ld	b,h
;fatFs\ff_fgetfree.c:74: if (stat == 0xFFFFFFFF) { res = FR_DISK_ERR; break; }
	ld	a,c
	inc	a
	jr	NZ,00102$
	ld	a,b
	inc	a
	jr	NZ,00102$
	ld	a,e
	inc	a
	jr	NZ,00102$
	ld	a,d
	inc	a
	jr	NZ,00102$
	ld	-47 (ix),#0x01
	jp	00126$
00102$:
;fatFs\ff_fgetfree.c:75: if (stat == 1) { res = FR_INT_ERR; break; }
	ld	a,c
	dec	a
	jr	NZ,00104$
	ld	a,b
	or	a,a
	jr	NZ,00104$
	or	a,e
	jr	NZ,00104$
	or	a,d
	jr	NZ,00104$
	ld	-47 (ix),#0x02
	jp	00126$
00104$:
;fatFs\ff_fgetfree.c:76: if (stat == 0) nfree++;
	ld	a,d
	or	a, e
	or	a, b
	or	a,c
	jr	NZ,00108$
	inc	-4 (ix)
	jr	NZ,00193$
	inc	-3 (ix)
	jr	NZ,00193$
	inc	-2 (ix)
	jr	NZ,00193$
	inc	-1 (ix)
00193$:
	ld	hl, #21
	add	hl, sp
	ex	de, hl
	ld	hl, #43
	add	hl, sp
	ld	bc, #4
	ldir
00108$:
;fatFs\ff_fgetfree.c:77: } while (++clst < fs->n_fatent);
	inc	-30 (ix)
	jr	NZ,00194$
	inc	-29 (ix)
	jr	NZ,00194$
	inc	-28 (ix)
	jr	NZ,00194$
	inc	-27 (ix)
00194$:
	ld	l,-22 (ix)
	ld	h,-21 (ix)
	ld	de, #0x0012
	add	hl, de
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	inc	hl
	ld	b,(hl)
	inc	hl
	ld	h,(hl)
	ld	a,-30 (ix)
	sub	a, e
	ld	a,-29 (ix)
	sbc	a, d
	ld	a,-28 (ix)
	sbc	a, b
	ld	a,-27 (ix)
	sbc	a, h
	jp	C,00107$
	jp	00126$
00125$:
;fatFs\ff_fgetfree.c:101: clst = fs->n_fatent;	/* Number of entries */
	push	bc
	ld	hl, #45
	add	hl, sp
	ex	de, hl
	ld	hl, #35
	add	hl, sp
	ld	bc, #4
	ldir
	pop	iy
	ld	a,30 (iy)
	ld	-14 (ix),a
	ld	a,31 (iy)
	ld	-13 (ix),a
	ld	a,32 (iy)
	ld	-12 (ix),a
	ld	a,33 (iy)
	ld	-11 (ix),a
;fatFs\ff_fgetfree.c:103: i = 0;					/* Offset in the sector */
	ld	-10 (ix),#0x00
	ld	-9 (ix),#0x00
;fatFs\ff_fgetfree.c:104: do {	/* Counts numbuer of entries with zero in the FAT */
00121$:
;fatFs\ff_fgetfree.c:105: if (i == 0) {
	ld	a,-9 (ix)
	or	a,-10 (ix)
	jr	NZ,00113$
;fatFs\ff_fgetfree.c:106: res = move_window(fs, sect++);
	ld	e,-14 (ix)
	ld	d,-13 (ix)
	ld	c,-12 (ix)
	ld	b,-11 (ix)
	inc	-14 (ix)
	jr	NZ,00195$
	inc	-13 (ix)
	jr	NZ,00195$
	inc	-12 (ix)
	jr	NZ,00195$
	inc	-11 (ix)
00195$:
	push	bc
	push	de
	ld	l,-22 (ix)
	ld	h,-21 (ix)
	push	hl
	call	_move_window
	pop	af
	pop	af
	pop	af
;fatFs\ff_fgetfree.c:107: if (res != FR_OK) break;
	ld	-47 (ix), l
	ld	a, l
	or	a, a
	jp	NZ,00126$
00113$:
;fatFs\ff_fgetfree.c:109: if (fs->fs_type == FS_FAT16) {
	ld	a,-22 (ix)
	ld	-6 (ix),a
	ld	a,-21 (ix)
	ld	-5 (ix),a
	ld	l,-6 (ix)
	ld	h,-5 (ix)
	ld	d,(hl)
;fatFs\ff_fgetfree.c:110: if (ld_word(fs->win + i) == 0) nfree++;
	ld	a,-26 (ix)
	add	a, #0x01
	ld	-18 (ix),a
	ld	a,-25 (ix)
	adc	a, #0x00
	ld	-17 (ix),a
	ld	a,-24 (ix)
	adc	a, #0x00
	ld	-16 (ix),a
	ld	a,-23 (ix)
	adc	a, #0x00
	ld	-15 (ix),a
;fatFs\ff_fgetfree.c:109: if (fs->fs_type == FS_FAT16) {
	ld	a,d
	sub	a, #0x02
	jr	NZ,00119$
;fatFs\ff_fgetfree.c:110: if (ld_word(fs->win + i) == 0) nfree++;
	ld	a,-6 (ix)
	add	a, #0x2E
	ld	l,a
	ld	a,-5 (ix)
	adc	a, #0x00
	ld	h,a
	ld	a,-10 (ix)
	add	a, l
	ld	c,a
	ld	a,-9 (ix)
	adc	a, h
	ld	b,a
	ld	l, c
	ld	h, b
	inc	hl
	ld	d, (hl)
	ld	e,#0x00
	ld	a,(bc)
	ld	l,a
	ld	h,#0x00
	ld	a,l
	or	a, e
	ld	l,a
	ld	a,h
	or	a, d
	or	a,l
	jr	NZ,00115$
	ld	hl, #21
	add	hl, sp
	ex	de, hl
	ld	hl, #29
	add	hl, sp
	ld	bc, #4
	ldir
00115$:
;fatFs\ff_fgetfree.c:111: i += 2;
	ld	a,-10 (ix)
	add	a, #0x02
	ld	-32 (ix),a
	ld	a,-9 (ix)
	adc	a, #0x00
	ld	-31 (ix),a
	jr	00120$
00119$:
;fatFs\ff_fgetfree.c:113: if ((ld_dword(fs->win + i) & 0x0FFFFFFF) == 0) nfree++;
	ld	a,-6 (ix)
	add	a, #0x2E
	ld	l,a
	ld	a,-5 (ix)
	adc	a, #0x00
	ld	h,a
	ld	e,-10 (ix)
	ld	d,-9 (ix)
	add	hl,de
	push	hl
	call	_ld_dword
	pop	af
	ld	a,l
	or	a,a
	jr	NZ,00117$
	or	a,h
	jr	NZ,00117$
	or	a,e
	jr	NZ,00117$
	ld	a,d
	and	a, #0x0F
	jr	NZ,00117$
	ld	hl, #21
	add	hl, sp
	ex	de, hl
	ld	hl, #29
	add	hl, sp
	ld	bc, #4
	ldir
00117$:
;fatFs\ff_fgetfree.c:114: i += 4;
	ld	a,-10 (ix)
	add	a, #0x04
	ld	-32 (ix),a
	ld	a,-9 (ix)
	adc	a, #0x00
	ld	-31 (ix),a
00120$:
;fatFs\ff_fgetfree.c:116: i %= SS(fs);
	ld	a,-32 (ix)
	ld	-10 (ix),a
	ld	a,-31 (ix)
	and	a, #0x01
	ld	-9 (ix),a
;fatFs\ff_fgetfree.c:117: } while (--clst);
	ld	a,-4 (ix)
	add	a,#0xFF
	ld	-4 (ix),a
	ld	a,-3 (ix)
	adc	a,#0xFF
	ld	-3 (ix),a
	ld	a,-2 (ix)
	adc	a,#0xFF
	ld	-2 (ix),a
	ld	a,-1 (ix)
	adc	a,#0xFF
	ld	-1 (ix), a
	or	a, -2 (ix)
	or	a, -3 (ix)
	or	a,-4 (ix)
	jp	NZ,00121$
00126$:
;fatFs\ff_fgetfree.c:120: *nclst = nfree;			/* Return the free clusters */
	ld	e,-20 (ix)
	ld	d,-19 (ix)
	ld	hl, #0x0015
	add	hl, sp
	ld	bc, #0x0004
	ldir
;fatFs\ff_fgetfree.c:121: fs->free_clst = nfree;	/* Now free_clst is valid */
	ld	l,-22 (ix)
	ld	h,-21 (ix)
	ld	bc,#0x000E
	add	hl,bc
	ex	de,hl
	ld	hl, #0x0015
	add	hl, sp
	ld	bc, #0x0004
	ldir
;fatFs\ff_fgetfree.c:122: fs->fsi_flag |= 1;		/* FAT32: FSInfo is to be updated */
	ld	l,-22 (ix)
	ld	h,-21 (ix)
	inc	hl
	inc	hl
	inc	hl
	set	0, (hl)
	ld	a, (hl)
00131$:
;fatFs\ff_fgetfree.c:126: LEAVE_FF(fs, res);
	ld	l,-47 (ix)
	ld	sp, ix
	pop	ix
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
