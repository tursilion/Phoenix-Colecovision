;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 3.5.0 #9253 (Jun 20 2015) (MINGW64)
; This file was generated Thu Sep 12 23:57:53 2019
;--------------------------------------------------------
	.module ff_lseek
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _disk_write
	.globl _disk_read
	.globl _create_chain
	.globl _validate
	.globl _get_fat
	.globl _clst2sect
	.globl _f_lseek
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\ff_lseek.c:43: FRESULT f_lseek (
;	---------------------------------
; Function f_lseek
; ---------------------------------
_f_lseek::
	call	___sdcc_enter_ix
	ld	hl,#-41
	add	hl,sp
	ld	sp,hl
;fatFs\ff_lseek.c:56: res = validate(&fp->obj, &fs);		/* Check validity of the file object */
	ld	hl,#0x0001
	add	hl,sp
	ld	a,4 (ix)
	ld	-16 (ix),a
	ld	a,5 (ix)
	ld	-15 (ix),a
	push	hl
	ld	l,-16 (ix)
	ld	h,-15 (ix)
	push	hl
	call	_validate
	pop	af
	pop	af
	ld	-41 (ix),l
;fatFs\ff_lseek.c:57: if (res == FR_OK) res = (FRESULT)fp->err;
	ld	a,-16 (ix)
	add	a, #0x0F
	ld	-2 (ix),a
	ld	a,-15 (ix)
	adc	a, #0x00
	ld	-1 (ix),a
	ld	a,-41 (ix)
	or	a, a
	jr	NZ,00102$
	ld	l,-2 (ix)
	ld	h,-1 (ix)
	ld	a,(hl)
	ld	-41 (ix),a
00102$:
;fatFs\ff_lseek.c:63: if (res != FR_OK) LEAVE_FF(fs, res);
	ld	a,-41 (ix)
	or	a, a
	jr	Z,00104$
	ld	l,-41 (ix)
	jp	00155$
00104$:
;fatFs\ff_lseek.c:130: if (ofs > fp->obj.objsize && (FF_FS_READONLY || !(fp->flag & FA_WRITE))) {	/* In read-only mode, clip offset with the file size */
	ld	a,-16 (ix)
	add	a, #0x0A
	ld	-18 (ix),a
	ld	a,-15 (ix)
	adc	a, #0x00
	ld	-17 (ix),a
	ld	e,-18 (ix)
	ld	d,-17 (ix)
	ld	hl, #0x0023
	add	hl, sp
	ex	de, hl
	ld	bc, #0x0004
	ldir
	ld	a,-16 (ix)
	add	a, #0x0E
	ld	-8 (ix),a
	ld	a,-15 (ix)
	adc	a, #0x00
	ld	-7 (ix),a
	ld	a,-6 (ix)
	sub	a, 6 (ix)
	ld	a,-5 (ix)
	sbc	a, 7 (ix)
	ld	a,-4 (ix)
	sbc	a, 8 (ix)
	ld	a,-3 (ix)
	sbc	a, 9 (ix)
	jr	NC,00106$
	ld	l,-8 (ix)
	ld	h,-7 (ix)
	ld	a,(hl)
	bit	1, a
	jr	NZ,00106$
;fatFs\ff_lseek.c:131: ofs = fp->obj.objsize;
	ld	hl, #47
	add	hl, sp
	ex	de, hl
	ld	hl, #35
	add	hl, sp
	ld	bc, #4
	ldir
00106$:
;fatFs\ff_lseek.c:133: ifptr = fp->fptr;
	ld	a,-16 (ix)
	add	a, #0x10
	ld	-6 (ix),a
	ld	a,-15 (ix)
	adc	a, #0x00
	ld	-5 (ix),a
	ld	e,-6 (ix)
	ld	d,-5 (ix)
	ld	hl, #0x0003
	add	hl, sp
	ex	de, hl
	ld	bc, #0x0004
	ldir
;fatFs\ff_lseek.c:134: fp->fptr = nsect = 0;
	xor	a, a
	ld	-12 (ix),a
	ld	-11 (ix),a
	ld	-10 (ix),a
	ld	-9 (ix),a
	ld	l,-6 (ix)
	ld	h,-5 (ix)
	xor	a, a
	ld	(hl), a
	inc	hl
	ld	(hl), a
	inc	hl
	xor	a, a
	ld	(hl), a
	inc	hl
	ld	(hl), a
;fatFs\ff_lseek.c:135: if (ofs > 0) {
	ld	a,9 (ix)
	or	a, 8 (ix)
	or	a, 7 (ix)
	or	a,6 (ix)
	jp	Z,00145$
;fatFs\ff_lseek.c:136: bcs = (DWORD)fs->csize * SS(fs);	/* Cluster size (byte) */
	ld	l,-40 (ix)
	ld	h,-39 (ix)
	ld	de, #0x0008
	add	hl, de
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	hl,#0x0000
	push	af
	ld	-30 (ix),e
	ld	-29 (ix),d
	ld	-28 (ix),l
	ld	-27 (ix),h
	pop	af
	ld	a,#0x09
00258$:
	sla	-30 (ix)
	rl	-29 (ix)
	rl	-28 (ix)
	rl	-27 (ix)
	dec	a
	jr	NZ,00258$
;fatFs\ff_lseek.c:141: clst = fp->clust;
	ld	a,-16 (ix)
	add	a, #0x14
	ld	-14 (ix),a
	ld	a,-15 (ix)
	adc	a, #0x00
	ld	-13 (ix),a
;fatFs\ff_lseek.c:137: if (ifptr > 0 &&
	ld	a,-35 (ix)
	or	a, -36 (ix)
	or	a, -37 (ix)
	or	a,-38 (ix)
	jp	Z,00116$
;fatFs\ff_lseek.c:138: (ofs - 1) / bcs >= (ifptr - 1) / bcs) {	/* When seek to same or following cluster, */
	ld	a,6 (ix)
	add	a,#0xFF
	ld	e,a
	ld	a,7 (ix)
	adc	a,#0xFF
	ld	d,a
	ld	a,8 (ix)
	adc	a,#0xFF
	ld	c,a
	ld	a,9 (ix)
	adc	a,#0xFF
	ld	b,a
	ld	l,-28 (ix)
	ld	h,-27 (ix)
	push	hl
	ld	l,-30 (ix)
	ld	h,-29 (ix)
	push	hl
	push	bc
	push	de
	call	__divulong
	pop	af
	pop	af
	pop	af
	pop	af
	ld	-23 (ix),d
	ld	-24 (ix),e
	ld	-25 (ix),h
	ld	-26 (ix),l
	ld	a,-38 (ix)
	add	a,#0xFF
	ld	-22 (ix),a
	ld	a,-37 (ix)
	adc	a,#0xFF
	ld	-21 (ix),a
	ld	a,-36 (ix)
	adc	a,#0xFF
	ld	-20 (ix),a
	ld	a,-35 (ix)
	adc	a,#0xFF
	ld	-19 (ix),a
	ld	l,-28 (ix)
	ld	h,-27 (ix)
	push	hl
	ld	l,-30 (ix)
	ld	h,-29 (ix)
	push	hl
	ld	l,-20 (ix)
	ld	h,-19 (ix)
	push	hl
	ld	l,-22 (ix)
	ld	h,-21 (ix)
	push	hl
	call	__divulong
	pop	af
	pop	af
	pop	af
	pop	af
	ld	a,-26 (ix)
	sub	a, l
	ld	a,-25 (ix)
	sbc	a, h
	ld	a,-24 (ix)
	sbc	a, e
	ld	a,-23 (ix)
	sbc	a, d
	jr	C,00116$
;fatFs\ff_lseek.c:139: fp->fptr = (ifptr - 1) & ~(FSIZE_t)(bcs - 1);	/* start from the current cluster */
	ld	a,-30 (ix)
	add	a,#0xFF
	ld	e,a
	ld	a,-29 (ix)
	adc	a,#0xFF
	ld	d,a
	ld	a,-28 (ix)
	adc	a,#0xFF
	ld	c,a
	ld	a,-27 (ix)
	adc	a,#0xFF
	ld	b,a
	ld	a,e
	cpl
	ld	e,a
	ld	a,d
	cpl
	ld	d,a
	ld	a,c
	cpl
	ld	c,a
	ld	a,b
	cpl
	ld	b,a
	ld	a,e
	and	a, -22 (ix)
	ld	e,a
	ld	a,d
	and	a, -21 (ix)
	ld	d,a
	ld	a,c
	and	a, -20 (ix)
	ld	c,a
	ld	a,b
	and	a, -19 (ix)
	ld	b,a
	ld	l,-6 (ix)
	ld	h,-5 (ix)
	ld	(hl),e
	inc	hl
	ld	(hl),d
	inc	hl
	ld	(hl),c
	inc	hl
	ld	(hl),b
;fatFs\ff_lseek.c:140: ofs -= fp->fptr;
	ld	a,6 (ix)
	sub	a, e
	ld	6 (ix),a
	ld	a,7 (ix)
	sbc	a, d
	ld	7 (ix),a
	ld	a,8 (ix)
	sbc	a, c
	ld	8 (ix),a
	ld	a,9 (ix)
	sbc	a, b
	ld	9 (ix),a
;fatFs\ff_lseek.c:141: clst = fp->clust;
	ld	l,-14 (ix)
	ld	h,-13 (ix)
	ld	c,(hl)
	inc	hl
	ld	b,(hl)
	inc	hl
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	jp	00117$
00116$:
;fatFs\ff_lseek.c:143: clst = fp->obj.sclust;					/* start from the first cluster */
	ld	a,-16 (ix)
	add	a, #0x06
	ld	-22 (ix),a
	ld	a,-15 (ix)
	adc	a, #0x00
	ld	-21 (ix),a
	ld	l,-22 (ix)
	ld	h,-21 (ix)
	ld	c,(hl)
	inc	hl
	ld	b,(hl)
	inc	hl
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
;fatFs\ff_lseek.c:145: if (clst == 0) {						/* If no cluster chain, create a new chain */
	ld	a,d
	or	a, e
	or	a, b
	or	a,c
	jr	NZ,00114$
;fatFs\ff_lseek.c:146: clst = create_chain(&fp->obj, 0);
	ld	hl,#0x0000
	push	hl
	ld	hl,#0x0000
	push	hl
	ld	l,-16 (ix)
	ld	h,-15 (ix)
	push	hl
	call	_create_chain
	pop	af
	pop	af
	pop	af
	ld	c,l
	ld	b,h
;fatFs\ff_lseek.c:147: if (clst == 1) ABORT(fs, FR_INT_ERR);
	ld	a,c
	dec	a
	jr	NZ,00110$
	ld	a,b
	or	a,a
	jr	NZ,00110$
	or	a,e
	jr	NZ,00110$
	or	a,d
	jr	NZ,00110$
	ld	l,-2 (ix)
	ld	h,-1 (ix)
	ld	(hl),#0x02
	ld	l,#0x02
	jp	00155$
00110$:
;fatFs\ff_lseek.c:148: if (clst == 0xFFFFFFFF) ABORT(fs, FR_DISK_ERR);
	ld	a,c
	inc	a
	jr	NZ,00112$
	ld	a,b
	inc	a
	jr	NZ,00112$
	ld	a,e
	inc	a
	jr	NZ,00112$
	ld	a,d
	inc	a
	jr	NZ,00112$
	ld	l,-2 (ix)
	ld	h,-1 (ix)
	ld	(hl),#0x01
	ld	l,#0x01
	jp	00155$
00112$:
;fatFs\ff_lseek.c:149: fp->obj.sclust = clst;
	ld	l,-22 (ix)
	ld	h,-21 (ix)
	ld	(hl),c
	inc	hl
	ld	(hl),b
	inc	hl
	ld	(hl),e
	inc	hl
	ld	(hl),d
00114$:
;fatFs\ff_lseek.c:152: fp->clust = clst;
	ld	l,-14 (ix)
	ld	h,-13 (ix)
	ld	(hl),c
	inc	hl
	ld	(hl),b
	inc	hl
	ld	(hl),e
	inc	hl
	ld	(hl),d
00117$:
;fatFs\ff_lseek.c:154: if (clst != 0) {
	ld	a,d
	or	a, e
	or	a, b
	or	a,c
	jp	Z,00145$
;fatFs\ff_lseek.c:155: while (ofs > bcs) {						/* Cluster following loop */
	ld	a,-8 (ix)
	ld	-22 (ix),a
	ld	a,-7 (ix)
	ld	-21 (ix),a
00132$:
	ld	a,-30 (ix)
	sub	a, 6 (ix)
	ld	a,-29 (ix)
	sbc	a, 7 (ix)
	ld	a,-28 (ix)
	sbc	a, 8 (ix)
	ld	a,-27 (ix)
	sbc	a, 9 (ix)
	jp	NC,00134$
;fatFs\ff_lseek.c:156: ofs -= bcs; fp->fptr += bcs;
	ld	a,6 (ix)
	sub	a, -30 (ix)
	ld	6 (ix),a
	ld	a,7 (ix)
	sbc	a, -29 (ix)
	ld	7 (ix),a
	ld	a,8 (ix)
	sbc	a, -28 (ix)
	ld	8 (ix),a
	ld	a,9 (ix)
	sbc	a, -27 (ix)
	ld	9 (ix),a
	push	de
	push	bc
	ld	e,-6 (ix)
	ld	d,-5 (ix)
	ld	hl, #0x0013
	add	hl, sp
	ex	de, hl
	ld	bc, #0x0004
	ldir
	pop	bc
	pop	de
	ld	a,-26 (ix)
	add	a, -30 (ix)
	ld	-26 (ix),a
	ld	a,-25 (ix)
	adc	a, -29 (ix)
	ld	-25 (ix),a
	ld	a,-24 (ix)
	adc	a, -28 (ix)
	ld	-24 (ix),a
	ld	a,-23 (ix)
	adc	a, -27 (ix)
	ld	-23 (ix),a
	push	de
	push	bc
	ld	e,-6 (ix)
	ld	d,-5 (ix)
	ld	hl, #0x0013
	add	hl, sp
	ld	bc, #0x0004
	ldir
	pop	bc
	pop	de
;fatFs\ff_lseek.c:158: if (fp->flag & FA_WRITE) {			/* Check if in write mode or not */
	ld	l,-22 (ix)
	ld	h,-21 (ix)
	bit	1,(hl)
	jr	Z,00125$
;fatFs\ff_lseek.c:163: clst = create_chain(&fp->obj, clst);	/* Follow chain with forceed stretch */
	push	de
	push	bc
	ld	l,-16 (ix)
	ld	h,-15 (ix)
	push	hl
	call	_create_chain
	pop	af
	pop	af
	pop	af
	ld	c,l
	ld	b,h
;fatFs\ff_lseek.c:164: if (clst == 0) {				/* Clip file size in case of disk full */
	ld	a,d
	or	a, e
	or	a, b
	or	a,c
	jr	NZ,00126$
;fatFs\ff_lseek.c:165: ofs = 0; break;
	xor	a, a
	ld	6 (ix),a
	ld	7 (ix),a
	ld	8 (ix),a
	ld	9 (ix),a
	jp	00134$
00125$:
;fatFs\ff_lseek.c:170: clst = get_fat(&fp->obj, clst);	/* Follow cluster chain if not in write mode */
	push	de
	push	bc
	ld	l,-16 (ix)
	ld	h,-15 (ix)
	push	hl
	call	_get_fat
	pop	af
	pop	af
	pop	af
	ld	c,l
	ld	b,h
00126$:
;fatFs\ff_lseek.c:172: if (clst == 0xFFFFFFFF) ABORT(fs, FR_DISK_ERR);
	ld	a,c
	inc	a
	jr	NZ,00128$
	ld	a,b
	inc	a
	jr	NZ,00128$
	ld	a,e
	inc	a
	jr	NZ,00128$
	ld	a,d
	inc	a
	jr	NZ,00128$
	ld	l,-2 (ix)
	ld	h,-1 (ix)
	ld	(hl),#0x01
	ld	l,#0x01
	jp	00155$
00128$:
;fatFs\ff_lseek.c:173: if (clst <= 1 || clst >= fs->n_fatent) ABORT(fs, FR_INT_ERR);
	ld	a,#0x01
	cp	a, c
	ld	a,#0x00
	sbc	a, b
	ld	a,#0x00
	sbc	a, e
	ld	a,#0x00
	sbc	a, d
	jr	NC,00129$
	push	hl
	ld	l,-40 (ix)
	ld	h,-39 (ix)
	push	hl
	pop	iy
	pop	hl
	ld	a,18 (iy)
	ld	-26 (ix),a
	ld	a,19 (iy)
	ld	-25 (ix),a
	ld	a,20 (iy)
	ld	-24 (ix),a
	ld	a,21 (iy)
	ld	-23 (ix),a
	ld	a,c
	sub	a, -26 (ix)
	ld	a,b
	sbc	a, -25 (ix)
	ld	a,e
	sbc	a, -24 (ix)
	ld	a,d
	sbc	a, -23 (ix)
	jr	C,00130$
00129$:
	ld	l,-2 (ix)
	ld	h,-1 (ix)
	ld	(hl),#0x02
	ld	l,#0x02
	jp	00155$
00130$:
;fatFs\ff_lseek.c:174: fp->clust = clst;
	ld	l,-14 (ix)
	ld	h,-13 (ix)
	ld	(hl),c
	inc	hl
	ld	(hl),b
	inc	hl
	ld	(hl),e
	inc	hl
	ld	(hl),d
	jp	00132$
00134$:
;fatFs\ff_lseek.c:176: fp->fptr += ofs;
	push	de
	push	bc
	ld	e,-6 (ix)
	ld	d,-5 (ix)
	ld	hl, #0x0017
	add	hl, sp
	ex	de, hl
	ld	bc, #0x0004
	ldir
	pop	bc
	pop	de
	ld	a,-22 (ix)
	add	a, 6 (ix)
	ld	-22 (ix),a
	ld	a,-21 (ix)
	adc	a, 7 (ix)
	ld	-21 (ix),a
	ld	a,-20 (ix)
	adc	a, 8 (ix)
	ld	-20 (ix),a
	ld	a,-19 (ix)
	adc	a, 9 (ix)
	ld	-19 (ix),a
	push	de
	push	bc
	ld	e,-6 (ix)
	ld	d,-5 (ix)
	ld	hl, #0x0017
	add	hl, sp
	ld	bc, #0x0004
	ldir
	pop	bc
	pop	de
;fatFs\ff_lseek.c:177: if (ofs % SS(fs)) {
	ld	a,6 (ix)
	or	a, a
	jr	NZ,00267$
	bit	0, 7 (ix)
	jr	Z,00145$
00267$:
;fatFs\ff_lseek.c:178: nsect = clst2sect(fs, clst);	/* Current sector */
	push	de
	push	bc
	ld	l,-40 (ix)
	ld	h,-39 (ix)
	push	hl
	call	_clst2sect
	pop	af
	pop	af
	pop	af
	ld	-34 (ix),l
	ld	-33 (ix),h
	ld	-32 (ix),e
;fatFs\ff_lseek.c:179: if (nsect == 0) ABORT(fs, FR_INT_ERR);
	ld	-31 (ix), d
	ld	a, d
	or	a, -32 (ix)
	or	a, -33 (ix)
	or	a,-34 (ix)
	jr	NZ,00136$
	ld	l,-2 (ix)
	ld	h,-1 (ix)
	ld	(hl),#0x02
	ld	l,#0x02
	jp	00155$
00136$:
;fatFs\ff_lseek.c:180: nsect += (DWORD)(ofs / SS(fs));
	push	af
	ld	h,6 (ix)
	ld	l,7 (ix)
	ld	e,8 (ix)
	ld	d,9 (ix)
	pop	af
	ld	b,#0x09
00268$:
	srl	d
	rr	e
	rr	l
	rr	h
	djnz	00268$
	ld	a,-34 (ix)
	add	a, h
	ld	-12 (ix),a
	ld	a,-33 (ix)
	adc	a, l
	ld	-11 (ix),a
	ld	a,-32 (ix)
	adc	a, e
	ld	-10 (ix),a
	ld	a,-31 (ix)
	adc	a, d
	ld	-9 (ix),a
;fatFs\ff_lseek.c:184: if (!FF_FS_READONLY && fp->fptr > fp->obj.objsize) {	/* Set file change flag if the file size is extended */
00145$:
	ld	e,-6 (ix)
	ld	d,-5 (ix)
	ld	hl, #0x0013
	add	hl, sp
	ex	de, hl
	ld	bc, #0x0004
	ldir
	ld	l,-18 (ix)
	ld	h,-17 (ix)
	ld	d,(hl)
	inc	hl
	ld	e,(hl)
	inc	hl
	ld	c,(hl)
	inc	hl
	ld	h,(hl)
	ld	a,d
	sub	a, -22 (ix)
	ld	a,e
	sbc	a, -21 (ix)
	ld	a,c
	sbc	a, -20 (ix)
	ld	a,h
	sbc	a, -19 (ix)
	jr	NC,00144$
;fatFs\ff_lseek.c:185: fp->obj.objsize = fp->fptr;
	ld	e,-18 (ix)
	ld	d,-17 (ix)
	ld	hl, #0x0013
	add	hl, sp
	ld	bc, #0x0004
	ldir
;fatFs\ff_lseek.c:186: fp->flag |= FA_MODIFIED;
	ld	l,-8 (ix)
	ld	h,-7 (ix)
	ld	a,(hl)
	set	6, a
	ld	l,-8 (ix)
	ld	h,-7 (ix)
	ld	(hl),a
00144$:
;fatFs\ff_lseek.c:188: if (fp->fptr % SS(fs) && nsect != fp->sect) {	/* Fill sector cache if needed */
	ld	l,-6 (ix)
	ld	h,-5 (ix)
	ld	d,(hl)
	inc	hl
	ld	e,(hl)
	inc	hl
	ld	b,(hl)
	inc	hl
	ld	h,(hl)
	ld	a,d
	or	a, a
	jr	NZ,00270$
	bit	0, e
	jp	Z,00153$
00270$:
	ld	a,-16 (ix)
	add	a, #0x18
	ld	e,a
	ld	a,-15 (ix)
	adc	a, #0x00
	ld	d,a
	push	de
	ld	hl, #0x0015
	add	hl, sp
	ex	de, hl
	ld	bc, #0x0004
	ldir
	pop	de
	ld	a,-12 (ix)
	sub	a, -22 (ix)
	jr	NZ,00271$
	ld	a,-11 (ix)
	sub	a, -21 (ix)
	jr	NZ,00271$
	ld	a,-10 (ix)
	sub	a, -20 (ix)
	jr	NZ,00271$
	ld	a,-9 (ix)
	sub	a, -19 (ix)
	jp	Z,00153$
00271$:
;fatFs\ff_lseek.c:191: if (fp->flag & FA_DIRTY) {			/* Write-back dirty sector cache */
	ld	l,-8 (ix)
	ld	h,-7 (ix)
	ld	h,(hl)
;fatFs\ff_lseek.c:195: if (disk_write(fp->buf, fp->sect, 1) != RES_OK) ABORT(fs, FR_DISK_ERR);
	ld	a,-16 (ix)
	add	a, #0x22
	ld	c,a
	ld	a,-15 (ix)
	adc	a, #0x00
	ld	b,a
;fatFs\ff_lseek.c:191: if (fp->flag & FA_DIRTY) {			/* Write-back dirty sector cache */
	add	hl, hl
	jr	NC,00149$
;fatFs\ff_lseek.c:195: if (disk_write(fp->buf, fp->sect, 1) != RES_OK) ABORT(fs, FR_DISK_ERR);
	push	bc
	push	de
	ld	hl,#0x0001
	push	hl
	ld	l,-20 (ix)
	ld	h,-19 (ix)
	push	hl
	ld	l,-22 (ix)
	ld	h,-21 (ix)
	push	hl
	push	bc
	call	_disk_write
	pop	af
	pop	af
	pop	af
	pop	af
	ld	a,l
	pop	de
	pop	bc
	or	a, a
	jr	Z,00147$
	ld	l,-2 (ix)
	ld	h,-1 (ix)
	ld	(hl),#0x01
	ld	l,#0x01
	jr	00155$
00147$:
;fatFs\ff_lseek.c:197: fp->flag &= (BYTE)~FA_DIRTY;
	ld	l,-8 (ix)
	ld	h,-7 (ix)
	ld	a,(hl)
	and	a, #0x7F
	ld	l,-8 (ix)
	ld	h,-7 (ix)
	ld	(hl),a
00149$:
;fatFs\ff_lseek.c:203: if (disk_read(fp->buf, nsect, 1) != RES_OK) ABORT(fs, FR_DISK_ERR);	/* Fill sector cache */
	push	de
	ld	hl,#0x0001
	push	hl
	ld	l,-10 (ix)
	ld	h,-9 (ix)
	push	hl
	ld	l,-12 (ix)
	ld	h,-11 (ix)
	push	hl
	push	bc
	call	_disk_read
	pop	af
	pop	af
	pop	af
	pop	af
	ld	a,l
	pop	de
	or	a, a
	jr	Z,00151$
	ld	l,-2 (ix)
	ld	h,-1 (ix)
	ld	(hl),#0x01
	ld	l,#0x01
	jr	00155$
00151$:
;fatFs\ff_lseek.c:206: fp->sect = nsect;
	ld	hl, #0x001D
	add	hl, sp
	ld	bc, #0x0004
	ldir
00153$:
;fatFs\ff_lseek.c:210: LEAVE_FF(fs, res);
	ld	l,-41 (ix)
00155$:
	ld	sp, ix
	pop	ix
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
